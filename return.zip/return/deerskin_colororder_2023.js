jQuery(function () {
    jQuery('[data-browse-mode="P"] #js-slideSecret').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        infinite: false,
        variableWidth: true
    });
});
