// Adobe font
(function(d) {
    var config = {
        kitId: 'msu7rfo',
        scriptTimeout: 3000,
        async: true
    },
    h=d.documentElement,t=setTimeout(function(){h.className=h.className.replace(/\bwf-loading\b/g,"")+" wf-inactive";},config.scriptTimeout),tk=d.createElement("script"),f=false,s=d.getElementsByTagName("script")[0],a;h.className+=" wf-loading";tk.src='https://use.typekit.net/'+config.kitId+'.js';tk.async=true;tk.onload=tk.onreadystatechange=function(){a=this.readyState;if(f||a&&a!="complete"&&a!="loaded")return;f=true;clearTimeout(t);try{Typekit.load(config)}catch(e){}};s.parentNode.insertBefore(tk,s)
})(document);

// Animation Trigger
window.addEventListener('DOMContentLoaded', function(){
    const targetElements = document.querySelectorAll('.js-ani');
    const options = {
        root: null,
        rootMargin: '0px 0px 50px 0px',
        threshold: 0
    };
    const observer = new IntersectionObserver(action, options);

    function action(entries) {
        entries.forEach(function (entry) {
            if (entry.isIntersecting && (entry.target.classList.contains('is-active') !== true)) {
                entry.target.classList.add('is-active');
            }
        });
    };
    targetElements.forEach(targetElem => {
        observer.observe(targetElem);
    });
});

// YouTube
jQuery(function() {
    'use strict';

    const $body = jQuery('body');
    const ua = navigator.userAgent;
    const ytApiTag = jQuery('\<script\>');
    let $this;

    ytApiTag.attr('src', 'https://www.youtube.com/iframe_api');
    $body.append(ytApiTag);

    jQuery('.js-video-intrablock').on('click', function (e) {
        e.preventDefault();

        $this = jQuery(this);
        const intraBlockMovieId = $this.data('id');
        const $intraBlockMovie = jQuery('\<div\>').attr({
            'id': intraBlockMovieId,
            'class': 'movie-frame'
        });
        const $intraBlockMovieTag = jQuery('\<div\>').attr('class', 'movie-wrap').append($intraBlockMovie);

        $this.children('.movie-thum').hide();
        $this.append($intraBlockMovieTag).addClass('is-play');

        let intraBlockPlayer = new YT.Player(intraBlockMovieId, {
            width: '100%',
            height: '100%',
            videoId: intraBlockMovieId,
            events: {
                'onReady': onPlayerReady
            }
        });
    });

    function onPlayerReady(event) {
        event.target.mute();
        // event.target.playVideo();
    }
});


jQuery(function() {
    if(jQuery('[data-browse-mode="P"]').length) {
        jQuery('#js-news-slider').slick({
            infinite: true,
            slidesToShow: 2,
            slidesToScroll: 1
        });

        jQuery('#js-specification-slider').slick({
            infinite: true,
            dots: true,
            arrows: false,
            autoplay: true,
            speed: 1500,
            autoplaySpeed: 4500
        });

        jQuery('#js-trivia-slider').slick({
            infinite: false,
            arrows: true,
            centerMode: true,
            centerPadding: "15%"
        });
    } else {
        jQuery('#js-news-slider').slick({
            infinite: true,
            centerMode: true,
            centerPadding: "10%"
        });

        jQuery('#js-specification-slider').slick({
            infinite: true,
            dots: true,
            arrows: false,
            autoplay: true,
            speed: 1500,
            autoplaySpeed: 4500
        });

        jQuery('#js-trivia-slider').slick({
            infinite: false,
            arrows: true,
            centerMode: true,
            centerPadding: "10%"
        });
    }
});





/* ---------------------
	　YouTube動画モーダル
-------------------- */
jQuery(function() {
    'use strict';

    const $body = jQuery('body');
    const mqlPc = window.matchMedia('(min-width:769px)');
    let $this;

    jQuery('.js-metainsole-modal').on('click', function (e) {
        e.preventDefault();

        $this = jQuery(this);
        const $modalCloseBtn = jQuery('\<button\>').attr({
            'type': 'button',
            'id': 'js-metainsole-modal-btn',
            'class': 'free-video-modal-btn'
        }).html('close');
        const $movieInnerTag = jQuery('\<div\>').attr('class', 'free-video-wrap-inner').append($modalCloseBtn);
        const $movieTag = jQuery('\<div\>').attr('class', 'free-video-wrap').append($movieInnerTag);
        const $modalOverlay = jQuery('\<div\>').attr({
            'id': 'js-modal-overlay',
            'class': 'free-modal-overlay'
        }).append($movieTag);
        const clientWidth = $body[0].clientWidth;

        $body.addClass('is-modal-open').after($modalOverlay);

        // スクロールバーのズレ対策
        // if(!mobile && !tablet) {
        //     const noScrollbarWidth = $body.clientWidth;
        //     const difference = noScrollbarWidth - clientWidth;
        //     if (difference > 0) {
        //         $body.css('padding-right', difference + 'px');

        //         if(!mqlPc.matches) {
        //             $header.css('padding-right', difference + 'px');
        //         }
        //     }
        // }
    });

    jQuery(document).on('click', '#js-modal-overlay, .js-video-modal-btn', function() {
        closeModal();
    });

    function closeModal() {
        jQuery('.free-modal-overlay').remove();
        $body.removeClass('is-modal-open');

        // スクロールバーのズレ対策
        // if(!mobile && !tablet) {
        //     $body.css('padding-right', '');

        //     if(!mqlPc.matches) {
        //         jQuery('header').css('padding-right', '');
        //     }
        // }
    }
});