﻿var ecblib = ecblib || {};
ecblib.customize = ecblib.customize || {};
ecblib.customize.genre = ecblib.customize.genre || {};

(function () {
    'use strict';

    var _genre = ecblib.customize.genre;

    jQuery(function () {
        const $currentTarget = jQuery('.block-genre-tree--item').find('.block-genre-tree--items .block-genre-tree--item__open');
        const $currentTargetBody = $currentTarget.closest('.block-genre-tree--items');
        const openClass = 'is-open';
        let $accLink = jQuery('.js-genre-accordion');

        if ($accLink.length) {
            $accLink.each(function () {
                jQuery(this).after('\<span class="genre-accordion-trigger"\>');
            });

            if ($currentTarget.length) {
                $currentTargetBody.css('display', 'block');
                $currentTargetBody.siblings('.js-genre-accordion').addClass(openClass);
            }
        }

        jQuery(document).on('click', '.genre-accordion-trigger', function(e) {
            e.preventDefault();

            let $targetBody = jQuery(this).next('.block-genre-tree--items');
            $targetBody.slideToggle();
            $targetBody.prev('.js-genre-accordion').toggleClass(openClass);
        });
    });

}());
