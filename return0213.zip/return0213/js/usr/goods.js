﻿var ecblib = ecblib || {};
ecblib.customize = ecblib.customize || {};
ecblib.customize.goods = ecblib.customize.goods || {};

(function () {
    'use strict';

    var _goods = ecblib.customize.goods;

    jQuery(function () {
        const openClass = 'is-open';

        jQuery('.block-goods-compatible-model dt').on('click', function () {
            jQuery(this).next('dd').slideToggle();
            jQuery(this).closest('.block-goods-compatible-model').toggleClass(openClass);
        });

        jQuery('.block-variation--selected-item').on('click', function () {
            jQuery(this).next('.block-variation--item-list').slideToggle();
            jQuery(this).toggleClass(openClass);
        });

        //-- 高さ調整
        if (jQuery('.page-goods').length) {
            const $thumbnailParent = jQuery('.pane-goods-footer .block-thumbnail-t--items');
            if ($thumbnailParent.length) {
                $thumbnailParent.find('.block-icon').tile(5);
                $thumbnailParent.find('.block-thumbnail-t--goods-name').tile(5);
                $thumbnailParent.find('.variation-name').tile(5);
                $thumbnailParent.find('.block-thumbnail-t--price-infos').tile(5);
            }
        }
    });

    jQuery(function () {
        //-- タブ
        let $tab = jQuery('.js-goodsdetail-tab');
        let $tabLength = $tab.length;

        if ($tabLength <= 0) {return;}

        const currentClass = 'is-current';
        let $tabList = $tab.children('.goodsdetail-tab-list');
        let $tabItem = $tabList.children('.goodsdetail-tab-list-item');
        let $defaltTabItemCurrent;
        let $tabItemAnchor = $tabItem.children('a');
        let $tabContents = $tab.children('.goodsdetail-tab-contents');
        let $defaltTabContentsCurrent;
        let i;
        let identifier;

        $tabList.attr('role', 'tablist');
        $tabItem.attr({
            role: 'tab',
            tabindex: -1,
            'aria-selected': false,
            'aria-expanded': false
        });
        $tabItemAnchor.attr({
            role: 'presentation',
            tabindex: -1
        });
        $tabContents.attr('role', 'tabpanel');

        for (i = 0; i < $tabItem.length; i++) {
            identifier = $tabItem.eq(i).children('a').attr('href').slice(1);
            $tabItem.eq(i).attr({
                'aria-controls': identifier,
                'aria-labelledby': 'ui-id-' + identifier
            });
        }

        for (i = 0; i < $tabContents.length; i++) {
            identifier = $tabContents.eq(i).attr('id');
            $tabContents.eq(i).attr('aria-labelledby', 'ui-id-' + identifier);
        }

        $tabList.each(function () {
            $defaltTabItemCurrent = jQuery(this).children('.goodsdetail-tab-list-item').eq(0);
            $defaltTabItemCurrent.addClass(currentClass).attr({
                tabindex: '0',
                'aria-selected': true,
                'aria-expanded': true
            });
        });

        $tab.each(function () {
            $defaltTabContentsCurrent = jQuery(this).children('.goodsdetail-tab-contents').eq(0);
            $defaltTabContentsCurrent.addClass(currentClass).attr('aria-hidden', 'false');
        });

        $tabItem.on('click', function (e) {
            $tabItem = jQuery(this).closest('.goodsdetail-tab-list').children('.goodsdetail-tab-list-item.is-current');
            $tabItemAnchor = $tabItem.children('a');
            identifier = $tabItemAnchor.attr('href');
            jQuery(identifier).removeClass(currentClass).attr('aria-hidden', 'true');
            $tabItem.removeClass(currentClass).attr({
                tabindex: -1,
                'aria-selected': false,
                'aria-expanded': false
            });

            $tabItemAnchor = jQuery(this).children('a');
            identifier = $tabItemAnchor.attr('href');
            jQuery(identifier).addClass(currentClass).attr('aria-hidden', 'false');

            for (i = 0; i < $tabItem.length; i++) {
                jQuery(this).eq(i).addClass(currentClass).attr({
                    tabindex: 0,
                    'aria-selected': true,
                    'aria-expanded': true
                });
            }

            e.preventDefault();
        });

        jQuery(window).on('load', function () {
            $tab.addClass('is-load');
        });
    });

}());
