﻿var ecblib = ecblib || {};

jQuery(document).ready(function() {
	jQuery('[data-tooltip-compatible-model]').each(function () {
		var tooltipData = [];
		var modelValues = jQuery(this).attr('data-tooltip-compatible-model').split(' ');
		modelValues.forEach(function (model) {
			tooltipData.push(model);
		});

		var tooltip = '<ul class="tooltip-contents-list"><li>' + tooltipData.join('</li><li>') + '</li></ul>';
		var position = jQuery(this).data('tooltip-position');
		if (!position) {
			position = 'bottom';
		}

		jQuery(this).on({
			'mouseenter': function () {
				jQuery(this).hideBalloon()
					.showBalloon({
						classname: 'balloontip',
						contents: tooltip,
						position: position,
						html: true,
						css: {
							color: "#fff",
							backgroundColor: "#555"
						}
					});
			},
			'mouseleave': function () {
				jQuery(this).hideBalloon();
			}
		});
	});
});