﻿var ecblib = ecblib || {};
ecblib.customize = ecblib.customize || {};
ecblib.customize.user_sb = ecblib.customize.user_sb || {};

(function () {
    'use strict';
    // copyright
    document.getElementById('js-thisYear').textContent = new Date().getFullYear().toString();
}());

jQuery(function () {
    var _user_sb = ecblib.customize.user_sb;

    //-- トップページへ戻る初期値
    jQuery('#footer_pagetop').hide();

    //--- スムーススクロール
    jQuery('a[href="#header"], [href^="#anc-"]').click(function () {
        var speed = 500;
        var headerH = jQuery('#gNav').height();
        var href = jQuery(this).attr("href");
        var target = jQuery(href == "#" || href == "" ? 'html' : href);
        var position = target.offset().top - headerH;
        jQuery('body,html').animate({ scrollTop: position }, speed, 'swing');
        return false;
    });
    var scrollpos;
    jQuery('#js-header-menu').click(function(){
        jQuery("#search_view").fadeOut(200);
        jQuery("#js-header-search").removeClass("active");
        jQuery('#search_view').removeClass('current');
        if (jQuery(this).hasClass('is-active')){
            close();
        } else {
            scrollpos = jQuery(window).scrollTop();
            jQuery('body').addClass('body-fixed').css({'top': -scrollpos});
            jQuery("#menu_view").fadeIn(300);
            jQuery('#menu_view').addClass('current');
        }
    });
    jQuery('#js-header-menu-close').click(function(){
        close();
    });
    function close() {
        jQuery('body').removeClass('body-fixed').css({'top': 0});
        window.scrollTo(0,scrollpos);
        jQuery("#menu_view").fadeOut(200);
        jQuery('#menu_view').removeClass('current');
    }

    jQuery('#js-header-search').click(function(){
        jQuery("#menu_view").fadeOut(200);
        // jQuery("#js-header-menu").removeClass("is-active");
        jQuery('#menu_view').removeClass('current');

        if (jQuery(this).hasClass('active')){
            jQuery('body').removeClass('body-fixed').css({'top': 0});
            window.scrollTo(0,scrollpos);
            jQuery("#search_view").fadeOut(200);
            jQuery(this).removeClass("active");
            jQuery('#search_view').removeClass('current');
        } else {
            scrollpos = jQuery(window).scrollTop();
            jQuery('body').addClass('body-fixed').css({'top': -scrollpos});
            jQuery("#search_view").fadeIn(300);
            jQuery(this).addClass("active");
            jQuery('#search_view').addClass('current');
        }
    });
    jQuery('#search_view .search_bg ,#search_view .block-header-search--close-button').click(function(){
        jQuery('body').removeClass('body-fixed').css({'top': 0});
        window.scrollTo(0,scrollpos);
        jQuery("#search_view").fadeOut(200);
        jQuery("#js-header-search").removeClass("active");
        jQuery('#search_view').removeClass('current');

        return false;
    });

    jQuery('#brand_header_menu').click(function(){
        jQuery("#search_view").fadeOut(200);
        jQuery("#brand_header_search").removeClass("active");
        jQuery('#search_view').removeClass('current');
        
        if (jQuery(this).hasClass('active')){
            jQuery('body').removeClass('body-fixed').css({'top': 0});
            window.scrollTo(0,scrollpos);
            jQuery("#menu_view").fadeOut(200);
            jQuery(this).removeClass("active");
            jQuery('#menu_view').removeClass('current');
        } else {
            scrollpos = jQuery(window).scrollTop();
            jQuery('body').addClass('body-fixed').css({'top': -scrollpos});
            jQuery("#menu_view").fadeIn(300);
            jQuery(this).addClass("active");
            jQuery('#menu_view').addClass('current');
        }
    });
    jQuery('#brand_header_search').click(function(){
        jQuery("#menu_view").fadeOut(200);
        jQuery("#brand_header_menu").removeClass("active");
        jQuery('#menu_view').removeClass('current');
        
        if (jQuery(this).hasClass('active')){
            jQuery('body').removeClass('body-fixed').css({'top': 0});
            window.scrollTo(0,scrollpos);
            jQuery("#search_view").fadeOut(200);
            jQuery(this).removeClass("active");
            jQuery('#search_view').removeClass('current');
        } else {
            scrollpos = jQuery(window).scrollTop();
            jQuery('body').addClass('body-fixed').css({'top': -scrollpos});
            jQuery("#search_view").fadeIn(300);
            jQuery(this).addClass("active");
            jQuery('#search_view').addClass('current');
        }
    });
    jQuery('#search_view .search_bg ,#search_view .block-header-search--close-button').click(function(){
        jQuery('body').removeClass('body-fixed').css({'top': 0});
        window.scrollTo(0,scrollpos);
        jQuery("#search_view").fadeOut(200);
        jQuery("#brand_header_search").removeClass("active");
        jQuery('#search_view').removeClass('current');
        
        return false;
    });
});

jQuery(function() {
    // ヘッダースライド
    const $subNavSlides = $('#js-subnav-slide');
    const slideLen = $subNavSlides.children().length;
    let slideItems = [];
    let slideOrder = [];
    let slideIndex = 0;
    let running = false;
    let i;
    let offset;
    let orderI;

    for(i = 0; i < slideLen; i++) {
        slideItems.push($subNavSlides.children().eq(i));
        slideOrder.push(i);
        slideItems[i].css('order', i);
    }

    function slider(prev) {
        running = true;
        offset = prev ? 0 : '-100%';
        $subNavSlides.animate({left: offset}, 1000, 'swing', function() {
            ordering(prev);
            running = false;
        });
    }

    function ordering(prev) {
        if(prev) {
            orderI = slideIndex > 0 ? slideIndex - 1 : slideLen - 1;
            slideItems[orderI].css('order', slideOrder[orderI]-=slideLen);
            slideIndex = orderI;
        } else {
            slideItems[slideIndex].css('order', slideOrder[slideIndex]+=slideLen);
            slideIndex = slideIndex < slideLen - 1 ? slideIndex + 1 : 0;
        }
        $subNavSlides.css('left', '0');
    }

    setInterval(slider, 5000);
});

jQuery(window).on('scroll resize', function () {
    var _user_sb = ecblib.customize.user_sb;

    var scrollHeight = jQuery(document).height();
    var scrollPosition = jQuery(window).height() + jQuery(window).scrollTop();
    var footHeight = jQuery('footer').height();

    if (jQuery(this).scrollTop() > 120) {
        jQuery('#footer_pagetop').show();
    } else if (jQuery(this).scrollTop() < 80) {
        jQuery('#footer_pagetop').hide();
    }

    if (scrollHeight - scrollPosition <= footHeight) {
        jQuery('#footer_pagetop').css({ 'opacity': '0.2' });
    } else {
        jQuery('#footer_pagetop').css({ 'opacity': '1' });
    }

});

window.lazySizesConfig = window.lazySizesConfig || {};
/* lazysizesの設定の変更はここから記述してください
・lazySizesConfig.expandは、大きな画像を早めに読み込み開始させたい場合などに使用してください
    正の値を指定すると読み込み開始スクロール位置が上に（早く）なります
    負の値を設定すると読み込み開始スクロール位置が下に（遅く）なります
    ※lazySizesConfig.expandを指定しない場合、画像の読み込み状況やブラウザのアイドリング状況に応じて動的に最適化されますが
    指定すると動的な最適化が無効になることに注意してください
*/