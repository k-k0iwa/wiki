﻿var ecblib = ecblib || {};
ecblib.customize = ecblib.customize || {};
ecblib.customize.top = ecblib.customize.top || {};

(function () {
    'use strict';

    var _top = ecblib.customize.top;

    function ApplySwriper(target_selector, wrapper_selector , options) {
        const target = typeof target_selector === "string" ? document.querySelector(target_selector) : target_selector;
        if (!target || target.childElementCount === 0) return;
        target.classList.add('swiper');
        const child = wrapper_selector ? target.querySelector(wrapper_selector) : target.firstElementChild; 
        if (!child || child.childElementCount ===0) return;
        child.classList.add('swiper-wrapper');
        for (const grandchild of child.children) {
            grandchild.classList.add('swiper-slide');
        }

        if(options.pagination && !options.pagination.el) {
            const pagination = document.createElement('div');
            pagination.classList.add('swiper-pagination');
            target.append(pagination);
            options.pagination.el = pagination;
        }

        if (options.navigation) {
            if (!options.navigation.nextEl && !options.navigation.prevEl) {
                const navigation_prev = document.createElement('div');
                const navigation_next = document.createElement('div');
                navigation_prev.classList.add('swiper-button-prev');
                navigation_next.classList.add('swiper-button-next');
                if (options.navigation._custom_target){
                    options.navigation._custom_target.append(navigation_prev);
                    options.navigation._custom_target.append(navigation_next);
                } else
                {
                    target.append(navigation_prev);
                    target.append(navigation_next);
                }
                options.navigation.nextEl = navigation_next;
                options.navigation.prevEl = navigation_prev;
            }
        }

        new Swiper(target_selector, options);
    };

    ApplySwriper('#js-top-kv-slider', null, {
        loop: true,
        // slidesPerView: 2,
        slidesPerView: 'auto',
        loopedSlides: 2,
        spaceBetween: 12,
        initialSlide: 0,
        centeredSlides: true,
        pagination: {
            clickable: true,
        },
        preloadImages: false,
        lazy: {
            enabled: true,
            loadOnTransitionStart: true,
            loadPrevNext: true
        },
        navigation: {},
        on: {
            sliderFirstMove: function(s){
                s.slides.forEach(elm => elm.classList.remove('swiper-slide-lazy'));
            }
        }
    });

    setTimeout(() => {
        document.querySelectorAll(
            '.top-layout1 .block-ranking-r .block-ranking-r--items'
            + ', .top-layout2 .block-ranking-r .block-ranking-r--items'
            + ', .top-layout3 .block-ranking-r .block-ranking-r--items'
            + ', .top-layout4 .block-ranking-r .block-ranking-r--items'
            + ', .top-layout5 .block-ranking-r .block-ranking-r--items')
            .forEach((elm) => {
                if (elm.querySelectorAll("div dl").length <= 4) return;

                ApplySwriper(elm, null, {
                    slidesPerView: 4,
                    loop: true,
                    navigation: {}
                });
            });
    }, 0);

    setTimeout(() => {
        document.querySelectorAll(
            '.top-layout1 div.block-thumbnail-t'
            + ', .top-layout2 div.block-thumbnail-t'
            + ', .top-layout3 div.block-thumbnail-t'
            + ', .top-layout4 div.block-thumbnail-t'
            + ', .top-layout5 div.block-thumbnail-t')
            .forEach((elm) => {
                if (elm.querySelectorAll("div dl").length <= 4) return;
                elm.parentElement.style.position = 'relative';

                ApplySwriper(elm, null, {
                    slidesPerView: 4,
                    loop: true,
                    navigation: {}
                });
            });
    }, 0);

    // カテゴリツールチップ
    jQuery(document).ready(function() {
        jQuery('.js-top-cate-tooltip').each(function () {
            let tooltip = jQuery(this).next('.tooltip-contents-list');
            let position = jQuery(this).data('tooltip-position');
            if (!position) {
                position = 'bottom';
            }

            jQuery(this).on({
                'mouseenter': function () {
                    jQuery(this).hideBalloon()
                        .showBalloon({
                            classname: 'block-top-cate-balloontip',
                            contents: tooltip,
                            position: position,
                            offsetY: '12',
                            html: true,
                            css: {
                                color: "#fff",
                                backgroundColor: "#555"
                            }
                        });
                },
                'mouseleave': function () {
                    jQuery(this).hideBalloon();
                }
            });
        });
    });
}());
