﻿var ecblib = ecblib || {};
ecblib.customize = ecblib.customize || {};
ecblib.customize.genre_sb = ecblib.customize.genre_sb || {};

(function () {
    'use strict';

    var _genre_sb = ecblib.customize.genre_sb;

    jQuery(function () {
        jQuery('.js-genre-category').on('click', function() {
            jQuery(this).next('.block-genre-style').slideToggle();
            jQuery(this).toggleClass('is-open');
        });

        //-- 高さ調整
        if (jQuery('.page-genre').length) {
            const $thumbnailParent = jQuery('.block-thumbnail-t--items');
            if ($thumbnailParent.length) {
                $thumbnailParent.find('.block-icon').tile(2);
                $thumbnailParent.find('.block-thumbnail-t--goods-name').tile(2);
                $thumbnailParent.find('.variation-size').tile(2);
                $thumbnailParent.find('.variation-name').tile(2);
                $thumbnailParent.find('.block-thumbnail-t--price-infos').tile(2);
            }
        }
    });
}());