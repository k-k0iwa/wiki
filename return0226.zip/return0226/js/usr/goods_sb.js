﻿var ecblib = ecblib || {};
ecblib.customize = ecblib.customize || {};
ecblib.customize.goods_sb = ecblib.customize.goods_sb || {};

(function () {
    'use strict';

    var _goods_sb = ecblib.customize.goods_sb;

    jQuery(function () {
        const openClass = 'is-open';

        //-- 対応機種
        jQuery('.block-goods-compatible-model dt').on('click', function () {
            jQuery(this).next('dd').slideToggle();
            jQuery(this).closest('.block-goods-compatible-model').toggleClass(openClass);
        });

        //-- 商品コメント
        jQuery('.js-goodsdetail-acc').on('click', function() {
            jQuery(this).next('.goodsdetail-acc--item-detail').slideToggle();
            jQuery(this).toggleClass(openClass);
        });

        //-- 高さ調整
        if (jQuery('.page-goods').length) {
            const $thumbnailParent = jQuery('.block-thumbnail-t--item');
            if ($thumbnailParent.length) {
                // $thumbnailParent.find('.block-icon').tile();
                $thumbnailParent.find('.block-thumbnail-t--goods-name').tile();
                $thumbnailParent.find('.variation-name').tile();
                $thumbnailParent.find('.block-thumbnail-t--price-infos').tile();
            }
        }
    });
}());
