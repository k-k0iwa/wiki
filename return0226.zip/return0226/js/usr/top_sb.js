﻿var ecblib = ecblib || {};
ecblib.customize = ecblib.customize || {};
ecblib.customize.top_sb = ecblib.customize.top_sb || {};

(function () {
    'use strict';

    var _top_sb = ecblib.customize.top_sb;

    function ApplySwriper(target_selector, wrapper_selector , options) {
        const target = typeof target_selector === "string" ? document.querySelector(target_selector) : target_selector;
        if (!target || target.childElementCount === 0) return;
        target.classList.add('swiper');
        const child = wrapper_selector ? target.querySelector(wrapper_selector) : target.firstElementChild; 
        if (!child || child.childElementCount ===0) return;
        child.classList.add('swiper-wrapper');
        for (const grandchild of child.children) {
            grandchild.classList.add('swiper-slide');
        }

        if(options.pagination && !options.pagination.el) {
            const pagination = document.createElement('div');
            pagination.classList.add('swiper-pagination');
            target.append(pagination);
            options.pagination.el = pagination;
        }

        if (options.navigation) {
            if (!options.navigation.nextEl && !options.navigation.prevEl) {
                const navigation_prev = document.createElement('div');
                const navigation_next = document.createElement('div');
                navigation_prev.classList.add('swiper-button-prev');
                navigation_next.classList.add('swiper-button-next');
                if (options.navigation._custom_target){
                    options.navigation._custom_target.append(navigation_prev);
                    options.navigation._custom_target.append(navigation_next);
                } else
                {
                    target.append(navigation_prev);
                    target.append(navigation_next);
                }
                options.navigation.nextEl = navigation_next;
                options.navigation.prevEl = navigation_prev;
            }
        }

        new Swiper(target_selector, options);
    };

    ApplySwriper('#js-top-kv-slider', null, {
        loop: true,
        pagination: {
            clickable: true,
        },
        lazy: {
            enabled: true,
            loadOnTransitionStart: true,
            loadPrevNext: true
        },
        navigation: {},
        on: {
            sliderFirstMove: (s) => {
                s.slides.forEach(elm => elm.classList.remove('swiper-slide-lazy'));
            }
        }
    });

    ApplySwriper('.block-campaign-banner', '.block-campaign-banner--list', {
        loop: true,
        lazy: {
            enabled: true,
            loadOnTransitionStart: true,
        },
        navigation: {
            _custom_target: document.querySelector('.block-campaign-banner') ? document.querySelector('.block-campaign-banner').parentElement : null
        },
        on: {
            sliderFirstMove: (s) => {
                s.slides.forEach(elm => elm.classList.remove('swiper-slide-lazy'));
            }
        }
    });

    setTimeout(() => {
        document.querySelectorAll('.block-ranking-r').forEach((elm) => {
            if(elm.querySelectorAll(".block-ranking-r--items > li").length <= 2) return;
    
            ApplySwriper(elm, '.block-ranking-r--items', {
                loop: true,
                navigation: {
                    _custom_target: elm.parentElement
                }
            });
        });
    }, 0);
}());
