/* ==============================
		TOP用
============================= */
jQuery(function(){
	
	jQuery(document).on('click', '.page-menu .block-mypage--update-address-book-model', function(){
		jQuery('body').addClass('book-model-open');
		jQuery('#destnav').show();
	});	
	jQuery(document).on('click', '.page-menu .destnav-overlay', function(){
		jQuery('body').removeClass('book-model-open');
	});	
	
	if(jQuery('.lt_gnavi--inner').length){
		var scrollLeftWidth = jQuery('.lt_gnavi--inner').width();
		jQuery('.lt_gnavi--inner').scrollLeft(scrollLeftWidth);
	}

	if(jQuery('.page-category .block-category-list--sub').length){
		jQuery('.block-category-list--sub .block-category-style-d').each(function() {
			jQuery(this).find('a').tile(2);
			jQuery(this).find('h3').tile(2);
			jQuery(this).find('.block-category-style-d--item').tile(2);		
		});
	}	
	
	/* カテゴリ（絞り込み） */
	jQuery(document).on('click', '.page-category .block-filter--header', function(){
		if(jQuery('.block-filter--close').length){
			jQuery('.follow-filter-btn').removeClass('follow-filter-btn-close');
		}else{
			jQuery('.follow-filter-btn').addClass('follow-filter-btn-close');
		}
	});
	
	jQuery(document).on('click', '.follow-filter-btn', function(){
		if(jQuery('#block_of_filter').hasClass('block_of_filter-model')){
			jQuery('#block_of_filter').removeClass('block_of_filter-model');
		}else{
			jQuery('#block_of_filter').addClass('block_of_filter-model');
			jQuery('#block_of_filter').fadeIn();
			jQuery('#block_of_filter .block-filter--header').addClass('block-filter--header-model-close');
		}
	});
	
	jQuery(document).on('click', '.block-filter--header-model-close', function(){
		jQuery('#block_of_filter').removeClass('block_of_filter-model');
		jQuery('#block_of_filter .block-filter--header').removeClass('block-filter--header-model-close');
		jQuery('.block-filter--list-item').css('display', 'none');
		jQuery('.block-filter--header').addClass('block-filter--close');
		jQuery('.follow-filter-btn').removeClass('follow-filter-btn-close');
	});
	
	if(jQuery('.page-category .block-thumbnail-t li').length){
		jQuery('.block-thumbnail-t').each(function() {
			jQuery(this).find('.block-thumbnail-t--goods-name').tile(2);
			//jQuery(this).find('.block-thumbnail-t--price-infos').tile(2);
			jQuery(this).find('.block-model-num').tile(2);
			jQuery(this).find('.block-icon').tile(2);
			//jQuery(this).find('.block-thumbnail-t--goods-description').tile(2);
			//jQuery(this).find('.block-perf-icon').tile(2);
			jQuery(this).find('li').tile(2);
		});
	}
	
	//リサイクル券のチェックボックス処理
	if(jQuery('.page-goods .recycling-ticket').length) {
		jQuery('.recycling-ticket .block-filter input[type=checkbox]').change(function() {
			if(jQuery(this).prop('checked')){
				var goods_page_url = jQuery('.block-goods-detail-cart-follow-cart-btn').children('a').attr('href');
				var checked_on_set = '&' + jQuery(this).attr('name') + '=' + jQuery(this).val(); 
				var recycling_check_set = goods_page_url + checked_on_set;
				jQuery('.block-goods-detail-cart-follow-cart-btn').children('a').attr('href', recycling_check_set);
			}else{
				var goods_page_url = jQuery('.block-goods-detail-cart-follow-cart-btn').children('a').attr('href');
				var checked_on_set = '&' + jQuery(this).attr('name') + '=' + jQuery(this).val();
				var checked_off_set = goods_page_url.replace(checked_on_set, '');
				jQuery('.block-goods-detail-cart-follow-cart-btn').children('a').attr('href', checked_off_set);
			}
		});
	}	
	
	if(jQuery('.page-top .block-thumbnail-t li').length){
		/*jQuery('.block-thumbnail-t li').each(function() {
			jQuery(this).find('.block-thumbnail-t--goods-name').tile();
			jQuery(this).find('.block-thumbnail-t--price-infos').tile();
			jQuery(this).find('.block-model-num').tile();
			jQuery(this).find('.block-icon').tile();
			jQuery(this).find('.block-thumbnail-t--goods-description').tile();
			jQuery(this).find('.block-perf-icon').tile();
			jQuery(this).find('dl').tile();
		});*/

		jQuery(function () {
			jQuery(".page-top .block-thumbnail-t").each(function () { 
				jQuery(this).find('dl:gt(7)').remove();
			});
			jQuery('.block-thumbnail-t').each(function () {
				do {
					jQuery(this).find('li').children('dl:lt(2)').wrapAll('<div class="block-thumbnail-t-line"></div>');
				} while (jQuery(this).find('li').children('dl').length);
			});
			
			jQuery(".page-top .block-thumbnail-t li").slick({
				slidesToShow: 2,
				slidesToScroll:2,
				dots: false,
				pauseOnHover: true,
				infinite: true,
				speed: 1000,
				easing: 'ease',
				arrows: true,
				autoplay: true,
				variableWidth: true,
				prevArrow: '<a class="slick-prev" href="#"><img src="../img/usr/pc/pickup_slider_prev.png" alt="prev slide"></a>',
				nextArrow: '<a class="slick-next" href="#"><img src="../img/usr/pc/pickup_slider_next.png" alt="next slide"></a>',
				customPaging: function(slick,index) {
				// スライダーのインデックス番号に対応した画像のsrcを取得
				var targetImage = slick.$slides.eq(index).find('img').attr('src');
				// slick-dots > li　の中に上記で取得した画像を設定
				return '<img src=" ' + targetImage + ' "/>';
				}
			});
		});
		
		jQuery(function(){
		
			var slider_num_new = jQuery('.block-recommend-new-item .block-thumbnail-t > li').length;

			/* ===========================================
						  個別に高さを揃えるjs
			=========================================== */			
			jQuery(function(){
				var elm = jQuery('.block-thumbnail-t > li');
				var elm_height = {};
				elm_height.brand1 = 0;
				elm_height.brand2 = 0;
				elm_height.name1 = 0;
				elm_height.name2 = 0;
				var count = {};
				count.num = 0;
				var list = jQuery('.block-thumbnail-t > li').length;

				//ループで高さを取得して最後に高さを設定
				elm.each(function (i) {

					//ブランド名1つ目の高さ
					if (elm_height.brand1 < elm.eq(count.num).find('dl:nth-child(1) .block-thumbnail-t--goods-description .block-thumbnail-t--brand-name').height()){

						elm_height.brand1 = elm.eq(count.num).find('dl:nth-child(1) .block-thumbnail-t--goods-description .block-thumbnail-t--goods-name').height();
					}

					//ブランド名2つ目の高さ
					if (elm_height.brand2 < elm.eq(count.num).find('dl:nth-child(2) .block-thumbnail-t--goods-description .block-thumbnail-t--goods-name').height()){
						elm_height.brand2 = elm.eq(count.num).find('dl:nth-child(2) .block-thumbnail-t--goods-description .block-thumbnail-t--goods-name').height();
					}

					//商品名1つ目の高さ
					if (elm_height.name1 < elm.eq(count.num).find('dl:nth-child(1) .block-thumbnail-t--goods-description .block-thumbnail-t--goods-name').height()){
						elm_height.name1 = elm.eq(count.num).find('dl:nth-child(1) .block-thumbnail-t--goods-description .block-thumbnail-t--goods-name').height();
					}

					//商品名2つ目の高さ
					if (elm_height.name2 < elm.eq(count.num).find('dl:nth-child(2) .block-thumbnail-t--goods-description .block-thumbnail-t--goods-name').height()){
						elm_height.name2 = elm.eq(count.num).find('dl:nth-child(2) .block-thumbnail-t--goods-description .block-thumbnail-t--goods-name').height();
					}

					//カウント
					count.num;
					count.num ++;

					//処理の最後に高さセット
					if(count.num == list){
						//ブランド高さ1
						jQuery('.block-thumbnail-t li dl:nth-child(1) .block-thumbnail-t--goods-description .block-thumbnail-t--goods-name').css('height', elm_height.brand1 + "px");
						//ブランド高さ1
						jQuery('.block-thumbnail-t li dl:nth-child(2) .block-thumbnail-t--goods-description .block-thumbnail-t--goods-name').css('height', elm_height.brand2 + "px");
						//商品名高さ1
						jQuery('.block-thumbnail-t li dl:nth-child(1) .block-thumbnail-t--goods-description .block-thumbnail-t--goods-name').css('height', elm_height.name1 + "px");
						//商品名高さ2
						jQuery('.block-thumbnail-t li dl:nth-child(2) .block-thumbnail-t--goods-description .block-thumbnail-t--goods-name').css('height', elm_height.name2 + "px");

						elm_height.brand1 = 0;
						elm_height.brand2 = 0;
						elm_height.name1 = 0;
						elm_height.name2 = 0;
						count.num = 0;
					}
				});
			});
			
			//外側の高さを揃える
			jQuery('.block-recommend-new-item-inner ul').each(function(a) {

				jQuery(this).find('li dl').tile();
				jQuery(this).find('li').tile();
			});
			jQuery('.block-thumbnail-t').css('opacity', '1');
		});
	}
});





var ecblib = ecblib || {};
ecblib.customize = ecblib.customize || {};
ecblib.customize.user_sb = ecblib.customize.user_sb || {};

jQuery(function () {
	var _user_sb = ecblib.customize.user_sb;

	//-- トップページへ戻る初期値
	//jQuery('#footer_pagetop').hide();

	//--- スムーススクロール
	jQuery('a[href="#header"]').click(function () {
		var speed = 500;
		var headerH;
		if (jQuery('#header').height() > 200) {
			headerH = (jQuery('#header').height() + jQuery('#header_pickup_banner').height()) + 30;
		} else {
			headerH = jQuery('#header').height();
		};
		var href = jQuery(this).attr("href");
		var target = jQuery(href == "#" || href == "" ? 'html' : href);
		var position = target.offset().top - headerH;
		jQuery('body,html').animate({ scrollTop: position }, speed, 'swing');
		return false;
	});

	var scrollpos;
	jQuery('#header_menu').click(function(){
		if (jQuery(this).hasClass('active')){
			jQuery('body').removeClass('body-fixed').css({'top': 0});
			window.scrollTo(0,scrollpos);
			jQuery("#menu_view").fadeOut(200);
			jQuery(this).removeClass("active");
			jQuery('#menu_view').removeClass('current');
		} else {
			scrollpos = jQuery(window).scrollTop();
			jQuery('body').addClass('body-fixed').css({'top': -scrollpos});
			jQuery("#menu_view").fadeIn(300);
			jQuery(this).addClass("active");
			jQuery('#menu_view').addClass('current');
		}
	});
});


/*if(jQuery('#footer_pagetop').length) {
	var g_footerPagetop_offset = 80;
	jQuery(window).on('scroll resize', function () {
		var scrollHeight = jQuery(document).height();
		var scrollPosition = jQuery(window).height() + jQuery(window).scrollTop();
		var footHeight = jQuery('footer').height();

		if (jQuery(this).scrollTop() > g_footerPagetop_offset && scrollHeight - scrollPosition > footHeight) {
			jQuery('#footer_pagetop').addClass('show');
		} else if (jQuery(this).scrollTop() > g_footerPagetop_offset && scrollHeight - scrollPosition > footHeight) {
			jQuery('#footer_pagetop').addClass('show');
		} else if (jQuery(this).scrollTop() < g_footerPagetop_offset || scrollHeight - scrollPosition <= footHeight) {
			jQuery('#footer_pagetop').removeClass('show');
		}
	});
}*/

/* Change effect */
jQuery(window).on('scroll resize', function () {
	// var _user_sb = ecblib.customize.user_sb;

	// var scrollHeight = jQuery(document).height();
	// var scrollPosition = jQuery(window).height() + jQuery(window).scrollTop();
	// var footHeight = jQuery('footer').height();

	// if (jQuery(this).scrollTop() > 120) {
	// 	jQuery('#footer_pagetop').fadeIn(300);
	// 	jQuery('#footer_pagetop').addClass('lt_show');
	// } else if (jQuery(this).scrollTop() < 80) {
	// 	jQuery('#footer_pagetop').fadeOut(300);
	// 	jQuery('#footer_pagetop').removeClass('lt_show');
	// }

	// if (scrollHeight - scrollPosition <= footHeight) {
	// 	jQuery('#footer_pagetop').animate({opacity: 0.2}, 200);
	// } else {
	// 	jQuery('#footer_pagetop').animate({opacity: 1}, 300);
	// }

	let scrollHeight = jQuery(document).height();
	let scrollPosition = jQuery(window).height() + jQuery(window).scrollTop();
	let footHeight = jQuery(".pane-footer").height();
	
	if (scrollHeight - scrollPosition  <= footHeight) {
		jQuery('#footer_pagetop').fadeOut();
	} else if (jQuery(this).scrollTop() < 80){
		jQuery('#footer_pagetop').fadeOut();
	} else {
		jQuery('#footer_pagetop').fadeIn();
	}
});

jQuery(window).on('scroll resize', function () {
	let scrollHeight1 = jQuery(document).height();
	let scrollPosition1 = jQuery(window).height() + jQuery(window).scrollTop();
	let footHeight1 = jQuery(".pane-footer").height();
	
	if (scrollHeight1 - scrollPosition1  <= footHeight1) {
		jQuery('.follow-filter-btn').fadeOut();
	} else if (jQuery(this).scrollTop() < 80){
		jQuery('.follow-filter-btn').fadeOut();
	} else {
		jQuery('.follow-filter-btn').fadeIn();
	}
});


window.lazySizesConfig = window.lazySizesConfig || {};
/* lazysizesの設定の変更はここから記述してください
  ・lazySizesConfig.expandは、大きな画像を早めに読み込み開始させたい場合などに使用してください
    正の値を指定すると読み込み開始スクロール位置が上に（早く）なります
    負の値を設定すると読み込み開始スクロール位置が下に（遅く）なります
    ※lazySizesConfig.expandを指定しない場合、画像の読み込み状況やブラウザのアイドリング状況に応じて動的に最適化されますが
      指定すると動的な最適化が無効になることに注意してください
*/


jQuery(function(){
	var $targetCloseBtn = jQuery('#js-online_bnr_btn');

	if ($targetCloseBtn.length <= 0) {
		return;
	}

	$targetCloseBtn.on('click', function () {
		jQuery('#js-online_bnr').fadeOut();
	});
});

/* アウトレット在庫 */
jQuery(function(){
	if(document.URL.match(/outlet/)) {
		var numKeep = jQuery('.goods-detail-desc-cont .goods-detail-description.block-goods-stock dd').text();
		jQuery('.goods-detail-desc-cont .goods-detail-description.block-goods-stock dt').html('\u6B8B\u308A\u53F0\u6570'); //残り台数
		jQuery('.goods-detail-desc-cont .goods-detail-description.block-goods-stock dd').text('\u3042\u3068' + numKeep); //あと
		jQuery('.goods-detail-desc-cont .goods-detail-description.block-goods-stock').addClass('outlet');
	}
});

//20220414 社販対応変更
jQuery(function () {
	const productCode = ['g184113', 'g184114', 'g184876', 'g184877', 'g184112', 'g184874', 'g184875', 'g184878', 'g184115', 'g184116', 'g184879', 'g184880', 'g184883', 'g184884', 'g184881', 'g184882', 'g183457', 'g183458', 'g183459', 'g183460', 'g183847', 'g183848', 'g183849', 'g183850', 'g184871', 'g184872', 'g184873', 'g183839', 'g183840', 'g183841', 'g183842', 'g183843', 'g183844', 'g183845', 'g183846', 'g184526', 'g184527', 'g183838', 'g182181', 'g182182', 'g182184outlet', 'g181336outlet', 'g181340outlet', 'g181341outlet', 'g181416outlet', 'g181992outlet', 'g184112monitor', 'g184874monitor', 'g184875monitor', 'g184881monitor', 'g184882monitor', 'g182667gentei', 'g182668gentei', 'g182663gentei', 'g182664gentei', 'g183461gentei', 'g183462gentei'];
	const path = location.pathname.split('/')[3];

	var $targetElem = jQuery('#block-company-sales-area');
	var $targetParentElem = jQuery('.block-goods-detail');
	var $targetParentComment3 = $targetParentElem.find('.block-goods-comment3');
	var $targetParentComment4 = $targetParentElem.find('.block-goods-comment4');
	var $txtCheckElem = jQuery('#lt_global_nav .lt_gnavi_link');
	var txtCheck = $txtCheckElem.text();

	// txt = 社販
	if (txtCheck.indexOf('\u793E\u8CA9') >= 0 && productCode.indexOf(path) >= 0) {
		$targetElem.addClass('is-active');

		if($targetParentComment3.length === 1) {
			$targetParentComment3.append($targetElem);
		} else if ($targetParentComment4.length === 1) {
			$targetParentComment4.prepend($targetElem);
		} else {
			$targetElem.addClass('block-goods-comment3');
			jQuery('#goodsdetail_itemhistory').before($targetElem);
		}
		
		//ログイン画面の文言（社販）
		if(jQuery('.page-login').length) {
			jQuery('.block-login-company-sales').show();
		}	
	}
});

// 積水ハウス：IHCH非表示
jQuery(function() {
	var $targetElem = jQuery('.js-ihch-hide');
	var $txtCheckElem = jQuery('#lt_global_nav .lt_gnavi_link');
	var txtCheck = $txtCheckElem.text();

	// txt = シャーメゾンライフCLUB様
	if (txtCheck.indexOf('\u30B7\u30E3\u30FC\u30E1\u30BE\u30F3\u30E9\u30A4\u30D5\u0043\u004C\u0055\u0042\u69D8') >= 0) {
		$targetElem.remove();
       	// txt = すまいーだPLUS様
	}else if(txtCheck.indexOf('\u3059\u307e\u3044\u30fc\u3060PLUS\u4f1a\u54e1\u69d8') >= 0) {
		$targetElem.remove();
	}
});

// すまいーだ：LED非表示
jQuery(function() {
	var $targetElem = jQuery('.js-led-hide');
	var $txtCheckElem = jQuery('#lt_global_nav .lt_gnavi_link');
	var txtCheck = $txtCheckElem.text();

	// txt = すまいーだPLUS様
	if(txtCheck.indexOf('\u3059\u307e\u3044\u30fc\u3060PLUS\u4f1a\u54e1\u69d8') >= 0) {
		$targetElem.remove();
	}
});

/* ストア名称（Unicode変換） */
jQuery(function() {
	var $storeTxtNameElem = jQuery('#header .lt_gnavi_link');
	var $storeTxtNameElemWrap = jQuery('#header .lt_menu_root--inner > p');	
	var storeTxtNameCheck = $storeTxtNameElem.text();
	if(storeTxtNameCheck.indexOf('\u793e\u8ca9') >= 0) {
		//社販
		$storeTxtNameElemWrap.addClass('block-header-logo--link-company-sales');
	}else if(storeTxtNameCheck.indexOf('\u65E5\u7ACB\u95A2\u9023\u4F1A\u793E\u004F\u0042\u30FB\u004F\u0047') >= 0){
		//日立関連会社OB・OG
		$storeTxtNameElemWrap.addClass('block-header-logo--link-obog');	
	}else if(storeTxtNameCheck.indexOf('\u5927\u585a\u30b0\u30eb\u30fc\u30d7\u793e\u54e1\u69d8') >= 0){
		//大塚グループ社員様
		$storeTxtNameElemWrap.addClass('block-header-logo--link-otsuka');	
	}else if(storeTxtNameCheck.indexOf('\u30b7\u30e3\u30fc\u30e1\u30be\u30f3\u30e9\u30a4\u30d5CLUB\u69d8') >= 0){
		//シャーメゾンライフCLUB様
		$storeTxtNameElemWrap.addClass('block-header-logo--link-sekisui');	
	}else if(storeTxtNameCheck.indexOf('\u65e5\u7acb\u88fd\u54c1\u3054\u611b\u9867\u7d99\u7d9a\u304a\u5ba2\u69d8\u30b5\u30fc\u30d3\u30b9') >= 0){
		//日立製品ご愛顧継続お客様サービス
		$storeTxtNameElemWrap.addClass('block-header-logo--link-sales-service');		
	}else if(storeTxtNameCheck.indexOf('\u30ea\u30b3\u30fc\u30b0\u30eb\u30fc\u30d7\u793e\u54e1\u69d8') >= 0){
		//リコーグループ社員様
		$storeTxtNameElemWrap.addClass('block-header-logo--link-ricoh');		
	}else if(storeTxtNameCheck.indexOf('\u3059\u307e\u3044\u30fc\u3060PLUS\u4f1a\u54e1\u69d8') >= 0){
		//すまいーだPLUS会員様
		$storeTxtNameElemWrap.addClass('block-header-logo--link-iid-hd');		
	}else if(storeTxtNameCheck.indexOf('\u0053\u0043\u0053\u004B\u793E\u54E1\u69D8\u5C02\u7528') >= 0){
		//SCSK社員様専用
		$storeTxtNameElemWrap.addClass('block-header-logo--link-iid-scsk');		
	}else if(storeTxtNameCheck.indexOf('\u0041\u004E\u0041\u30B0\u30EB\u30FC\u30D7\u793E\u54E1\u69D8') >= 0){
		//ANAグループ社員様
		$storeTxtNameElemWrap.addClass('block-header-logo--link-iid-ana');		
	}else if(storeTxtNameCheck.indexOf('\u30b5\u30f3\u30c8\u30ea\u30fc\u30b0\u30eb\u30fc\u30d7\u793e\u54e1\u69d8') >= 0){
		//サントリー社員様
		$storeTxtNameElemWrap.addClass('block-header-logo--link-suntry');
	}else if(storeTxtNameCheck.indexOf('NID-Net\u52a0\u76df\u793e\u5f93\u696d\u54e1\u69d8') >= 0){
		//NID-Net加盟社従業員様
		$storeTxtNameElemWrap.addClass('block-header-logo--link-nid');
	}else if(storeTxtNameCheck.indexOf('\u307f\u3069\u308a\u4f1a\u30e1\u30f3\u30d0\u30fc\u4f1a\u793e\u5f93\u696d\u54e1\u69d8') >= 0){
		//みどり会メンバー会社従業員様
		$storeTxtNameElemWrap.addClass('block-header-logo--link-midori');
	}else if(storeTxtNameCheck.indexOf('\u7279\u7d04\u5e97\u5f93\u696d\u54e1\u69d8') >= 0){
		//特約店従業員様
		$storeTxtNameElemWrap.addClass('block-header-logo--link-tokuyaku');
	}else if(storeTxtNameCheck.indexOf('NICS PORT\u4f1a\u54e1\u3055\u307e') >= 0){
		//NICS PORT会員さま様
		$storeTxtNameElemWrap.addClass('block-header-logo--link-nissan');
	}else if(storeTxtNameCheck.indexOf('ENEOS\u30b0\u30eb\u30fc\u30d7\u5f93\u696d\u54e1\u69d8') >= 0){
		//ENEOSグループ従業員様
		$storeTxtNameElemWrap.addClass('block-header-logo--link-eneos');
	}else if(storeTxtNameCheck.indexOf('\u4e00\u6761\u5de5\u52d9\u5e97\u30b0\u30eb\u30fc\u30d7\u5f93\u696d\u54e1\u69d8') >= 0){
		//一条工務店グループ従業員様
		$storeTxtNameElemWrap.addClass('block-header-logo--link-ichizyo');
	}else if(storeTxtNameCheck.indexOf('\u30ea\u30f3\u30ca\u30a4\u30b0\u30eb\u30fc\u30d7\u5f93\u696d\u54e1\u69d8') >= 0){
		//リンナイグループ従業員様
		$storeTxtNameElemWrap.addClass('block-header-logo--link-rinnai');
	}else if(storeTxtNameCheck.indexOf('\uff2a\uff34\u30b0\u30eb\u30fc\u30d7\u5f93\u696d\u54e1\u69d8') >= 0){
		//JTグループ従業員様
		$storeTxtNameElemWrap.addClass('block-header-logo--link-jt');
	}else if(storeTxtNameCheck.indexOf('\u30d5\u30af\u30c0\u96fb\u5b50\u30b0\u30eb\u30fc\u30d7\u5f93\u696d\u54e1\u69d8') >= 0){
		//フクダ電子グループ従業員様
		$storeTxtNameElemWrap.addClass('block-header-logo--link-fukuda');
	}else if(storeTxtNameCheck.indexOf('\u30c8\u30e9\u30b9\u30b3\u4e2d\u5c71(\u682a)\u5f93\u696d\u54e1\u69d8') >= 0){
		//トラスコ中山(株)従業員様
		$storeTxtNameElemWrap.addClass('block-header-logo--link-trusco');
	}else if(storeTxtNameCheck.indexOf('\u30e6\u30cb\u30fb\u30c1\u30e3\u30fc\u30e0\u30b0\u30eb\u30fc\u30d7') >= 0){
		//ユニチャームグループ従業員様
		$storeTxtNameElemWrap.addClass('block-header-logo--link-uni');
	}else if(storeTxtNameCheck.indexOf('JAL\u30b0\u30eb\u30fc\u30d7') >= 0){
		//JALグループ従業員様
		$storeTxtNameElemWrap.addClass('block-header-logo--link-jal');
	}else if(storeTxtNameCheck.indexOf('\u30AA\u30EA\u30A8\u30F3\u30BF\u30EB\u30E9\u30F3\u30C9\u5171\u6E08\u4F1A') >= 0){
		//オリエンタルランド共済会従業員様
		$storeTxtNameElemWrap.addClass('block-header-logo--link-olc');
	}else if(storeTxtNameCheck.indexOf('\u4E2D\u592E\u65E5\u571F\u5730') >= 0){
		//中央日土地ソリューションズ従業員様
		$storeTxtNameElemWrap.addClass('block-header-logo--link-cns');
	}else if(storeTxtNameCheck.indexOf('HK net service') >= 0){
		//ホンダ開発従業員様
		$storeTxtNameElemWrap.addClass('block-header-logo--link-hondakaihatsu');
	}else if(storeTxtNameCheck.indexOf('NTT\u30B3\u30DF\u30E5\u30CB\u30B1\u30FC\u30B7\u30E7\u30F3\u30BA') >= 0){
		//NTTコミュニケーションズ従業員様
		$storeTxtNameElemWrap.addClass('block-header-logo--link-nttcom');
	}else if(storeTxtNameCheck.indexOf('\u4E09\u4FE1\u96FB\u6C17') >= 0){
		//三信電気従業員様
		$storeTxtNameElemWrap.addClass('block-header-logo--link-sanshin');
	}else if(storeTxtNameCheck.indexOf('\u304D\u3093\u3067\u3093') >= 0){
		//きんでん従業員様
		$storeTxtNameElemWrap.addClass('block-header-logo--link-kinden');
	}else if(storeTxtNameCheck.indexOf('\u5357\u6771\u5317\u30B0\u30EB\u30FC\u30D7') >= 0){
		//脳神経疾患研究所(南東北グループ)従業員様
		$storeTxtNameElemWrap.addClass('block-header-logo--link-minamitohoku');
	}else if(storeTxtNameCheck.indexOf('\u3042\u3044\u304A\u3044\u30CB\u30C3\u30BB\u30A4\u540C\u548C') >= 0){
		//あいおいニッセイ同和損害保険従業員様
		$storeTxtNameElemWrap.addClass('block-header-logo--link-aioinissaydowa');
	}else if(storeTxtNameCheck.indexOf('\u30ED\u30FC\u30E0') >= 0){
		//ローム従業員様
		$storeTxtNameElemWrap.addClass('block-header-logo--link-rohm');
	}else if(storeTxtNameCheck.indexOf('\u30A4\u30EF\u30BF\u30CB\u30B0\u30EB\u30FC\u30D7') >= 0){
		//岩谷産業従業員様
		$storeTxtNameElemWrap.addClass('block-header-logo--link-iwatani');
	}else if(storeTxtNameCheck.indexOf('\u307F\u305A\u307B\u8A3C\u5238') >= 0){
		//みずほ証券従業員様
		$storeTxtNameElemWrap.addClass('block-header-logo--link-mizuhosc');
	}
});




/* ============================================================================================================================================
		★ここからテンプレート★　※使用しなければ削除する
=============================================================================================================================================*/

/* ===========================================================
		ロード時読み込み
============================================================*/
jQuery(window).on('load',function(){
	
	//チェックした製品
	if(jQuery('#itemHistory').length) {
		jQuery('#itemHistory .block-thumbnail-h').each(function() {
			jQuery(this).find('dd .block-thumbnail-h--goods-name a').tile();
			jQuery(this).find('dd .block-thumbnail-h--goods-name').tile();
			jQuery(this).find('li').tile();
		});	
	}	
	
	if(jQuery('.page-top').length) {
		if(jQuery('.block-top-topic').length) {
			jQuery('.block-top-topic').prependTo('.pane-main');			
		}
	}
	
	
	//ロード時にハッシュ値があればページ内スクロール	
	function scrollToAnker(hash) {
		var head_part_height = jQuery('.pane-header').innerHeight();
		var link_target = jQuery(hash);
		var link_position = link_target.offset().top - head_part_height;
		jQuery('body,html').stop().animate({scrollTop:link_position}, 400);
	}

	if(jQuery('.page-contentspages').length){
	}else{
		var urlHash = location.hash;
		if(urlHash) {
			jQuery('body,html').stop().scrollTop(0);
			setTimeout(function () {
			  scrollToAnker(urlHash);
			}, 100);
		}	
	}

	//関数呼び出し
	windows_change_adjustment();
	
	//4列一覧
	if(jQuery('.page-category .block-thumbnail-t ul li, .page-search .block-thumbnail-t ul li, .page-event .block-thumbnail-t ul li').length) {
		jQuery('.block-thumbnail-t ul li').each(function() {
			jQuery(this).find('.block-thumbnail-t--goods-image').tile(2);
			jQuery(this).find('.block-thumbnail-t--goods-description .block-thumbnail-t--goods-name').tile(2);
			jQuery(this).find('.block-thumbnail-t--goods-description').tile(2);
		});
	}
	
	//4列一覧
	if(jQuery('.page-category .block-pickup-list-p ul li, .page-search .block-pickup-list-p ul li, .page-event .block-pickup-list-p ul li').length) {
		jQuery('.block-pickup-list-p ul li').each(function() {
			jQuery(this).find('.block-pickup-list-p--goods-image').tile(2);
			jQuery(this).find('.block-pickup-list-p--goods-description .block-pickup-list-p--goods-name').tile(2);
			jQuery(this).find('.block-pickup-list-p--goods-description').tile(2);
		});
	}
	
	//新規会員登録のチェックボックス処理	
	if(jQuery('.page-entry #agree_checkbox').length){
		let terms_input_num = jQuery('.page-entry .block-member-info--items-use-spoofing-protection input[type=checkbox]').length;
		let terms_input_checked_num = jQuery('.page-entry .block-member-info--items-use-spoofing-protection input[type=checkbox]:checked').length;
		if(terms_input_num == terms_input_checked_num){
			jQuery('.page-entry .action-buttons .block-member-info--forward').prop('disabled', false);
		}else{
			jQuery('.page-entry .action-buttons .block-member-info--forward').prop('disabled', true);
		}
	}
});

/* ====================================
		スマホ縦横対応
=====================================*/
jQuery(function(){
	jQuery(window).resize(function() {
		windows_change_adjustment();	
	});
});

/* ============================================================
					関数
==============================================================*/
function windows_change_adjustment(){
	
	//サムネイル
	if(jQuery('.block-thumbnail-t').length) {
		jQuery('.block-thumbnail-t').each(function() {
		});	
	}
	
	//ピックアップ
	if(jQuery('.block-pickup-list-p').length) {
		jQuery('.block-pickup-list-p--items').each(function() {
			//jQuery(this).find('.block-pickup-list-p--goods-image').tile(2);
			//jQuery(this).find('.block-pickup-list-p--goods-description').tile(2);
			//jQuery(this).find('.block-pickup-list-p--item').tile(2);
		});	
	}
	
	//ランキング
	if(jQuery('.block-ranking-r').length) {
		jQuery('.block-pickup-list-p--items').each(function() {
			jQuery(this).find('.block-ranking-r--goods-name').tile(4);
			jQuery(this).find('dl').tile(4);
		});	
	}	
	
}







/* =============================================================================
					★スマホ機能★
===============================================================================*/


jQuery(function() {
	
/* ====================================
			追従メニュー
=====================================*/	
	//ヘッダーの高さ取得
	var head_part_height = jQuery('.pane-header').innerHeight();
	
	if(jQuery('.pane-header').length){
		var nav = jQuery('.pane-header'), offset = nav.offset();
		
		jQuery(window).scroll(function () {
			if(jQuery(window).scrollTop() > offset.top + head_part_height) {
				jQuery('.pane-header-inner').addClass('pane-globalnav-fixd');
				jQuery('.pane-header').css('height', head_part_height);

			} else {
				jQuery('.pane-header-inner').removeClass('pane-globalnav-fixd');
			}
		});
	}

/* ====================================
			スムーススクロール
=====================================*/	
  jQuery('a[href^="#"]').click(function(){
    var speed = 500;
    var href= jQuery(this).attr("href");
    var target = jQuery(href == "#" || href == "" ? 'html' : href);
    var position = target.offset().top - head_part_height; //追従分の高さを調整
    jQuery("html, body").animate({scrollTop:position}, speed, "swing");
    return false;
  });	
	

/* ====================================
			タブ
=====================================*/	
	//クリックしたときのファンクションをまとめて指定
    jQuery('.tab-box > div').eq(0).css('display','block');
	
	jQuery('.tab-scroll-inner ul.tab li').click(function() {
		var index = jQuery('.tab-scroll-inner ul.tab li').index(this);
		jQuery('.tab-box > div').hide();
		jQuery('.tab-box > div').eq(index).show();
		jQuery('.tab-scroll-inner ul.tab li').removeClass('tab-on');
		jQuery(this).addClass('tab-on');
	});
	
	
});


/* ====================================
			モーダル
=====================================*/
jQuery(function(){
	//モーダル表示
	jQuery(document).on('click', '.modal-btn', function(){
		jQuery('body').addClass('modal-window-active');
	});
	//背景クリック
	jQuery(document).on('click', '.modal-window-active .overlay', function(){
		jQuery('body').removeClass('modal-window-active');
	});
	//閉じるボタンクリック
	jQuery(document).on('click', '.modal-window-close', function(){
		jQuery('body').removeClass('modal-window-active');
	});
});

/* ====================================
	新規会員登録のチェックボックス処理
=====================================*/
jQuery(function(){
	if(jQuery('.page-entry #agree_checkbox').length){
		jQuery('.page-entry .block-member-info--items-use-spoofing-protection input[type=checkbox]').change(function(){
			let terms_input_num = jQuery('.page-entry .block-member-info--items-use-spoofing-protection input[type=checkbox]').length;
			let terms_input_checked_num = jQuery('.page-entry .block-member-info--items-use-spoofing-protection input[type=checkbox]:checked').length;
			if(terms_input_num == terms_input_checked_num){
				jQuery('.page-entry .action-buttons .block-member-info--forward').prop('disabled', false);
			}else{
				jQuery('.page-entry .action-buttons .block-member-info--forward').prop('disabled', true);
			}
		});
	}	
});

/* ====================================
	同意画面のスクロール処理
=====================================*/
jQuery(function(){
	if(jQuery('.page-agree .block-member-terms').length){
		jQuery('.block-member-terms--body').scroll(function(){
			//スクロールを含めた高さ
			var agree_textarea_scroll = jQuery(this).get(0).scrollHeight;

			//表示されている高さ
			var agree_textarea_ht = jQuery(this).get(0).offsetHeight;
			var agree_textarea_move = jQuery(this).scrollTop();
			var agree_scroll_diff = agree_textarea_move + agree_textarea_ht;

			if(agree_textarea_scroll <= agree_scroll_diff){
				jQuery('input.block-member-terms--agree').prop('disabled', false);
			}
		});
	}
});

/* ====================================
	202203 社販対応
=====================================*/
jQuery(function() {
	var $txtCheckElem = jQuery('#lt_global_nav .lt_gnavi_link');
	var txtCheck = $txtCheckElem.text();

	// txt = 社販、OB・OG
	if ((txtCheck.indexOf('\u793E\u8CA9') >= 0) || (txtCheck.indexOf('\u004F\u0042\u30FB\u004F\u0047') >= 0)) {
		if(jQuery('.page-top').length){
			//「購入前に知っておきたいこと」のエアコン
			jQuery('.block-top-free-2--howto > ul > li dl#howto_7').show();
			//「製品カテゴリから探す」のエアコン
			jQuery('.block-top-free1-category--item.block-top-free1-category--item-ac').show();
		}

		if(jQuery('.lt_submenu--item-ac').length){
			//ナビゲーション
			jQuery('.lt_submenu--item-ac').css('display', 'table');
		}
	}else{
		jQuery('.lt_submenu--item-ac').remove();
	}
});

/* ====================================
	202209 社販MV・おすすめ特集対応
=====================================*/
jQuery(function () {
  // 社販用バナー制御
  var $targetElem = jQuery('.js-company-sales');
  var $targetParentElem = jQuery('.js-company-sales-wrapper > #top-slider').find('li');
  var $txtCheckElem = jQuery('#lt_global_nav .lt_gnavi_link');
  var txtCheck = $txtCheckElem.text();

  // txt = 社販
  if (txtCheck.indexOf('\u793E\u8CA9') >= 0) {
  jQuery('#top-slider-warp:not(.js-rank-c)').remove();
  jQuery('.top-features-list-wrap:not(.js-rank-c)').remove();
  jQuery('.js-rank-c').css('display', 'block');
  $targetParentElem.each(function () {
    if (jQuery(this).hasClass('js-company-sales')) {
      jQuery(this).css('display', 'block');
    }
  });
  if($txtCheckElem.find('.huid-none').length === 1) {
    jQuery('[data-huid]').each(function () {
      if(jQuery(this).data('huid') === 'yes') {
        jQuery(this).remove();
      }
    });
    } else {
    jQuery('[data-huid]').each(function () {
      if(jQuery(this).data('huid') === 'no') {
        jQuery(this).remove();
      }
    });
  }
  }else if(txtCheck.indexOf('\u004F\u0042\u30FB\u004F\u0047') >= 0){
    // txt = OB・OG
    jQuery('#top-slider-warp:not(.js-rank-ob)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-ob)').remove();
    jQuery('.js-rank-ob').css('display', 'block');
  }else if(txtCheck.indexOf('\u5927\u585A') >= 0){
    // txt = 大塚
    jQuery('#top-slider-warp:not(.js-rank-o)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-o)').remove();
    jQuery('.js-rank-o').css('display', 'block');
  }else if(txtCheck.indexOf('\u30B7\u30E3\u30FC\u30E1\u30BE\u30F3') >= 0){
    // txt = シャーメゾン
    jQuery('#top-slider-warp:not(.js-rank-s)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-s)').remove();
    jQuery('.js-rank-s').css('display', 'block');
  }else if(txtCheck.indexOf('\u30ea\u30b3\u30fc') >= 0){
    // txt = リコー
    jQuery('#top-slider-warp:not(.js-rank-r)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-r)').remove();
    jQuery('.js-rank-r').css('display', 'block');
}else if(txtCheck.indexOf('\u65e5\u7acb\u88fd\u54c1\u3054\u611b\u9867\u7d99\u7d9a\u304a\u5ba2\u69d8\u30b5\u30fc\u30d3\u30b9') >= 0){
    // txt = 日立製品
    jQuery('#top-slider-warp:not(.js-rank-h)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-h)').remove();
    jQuery('.js-rank-h').css('display', 'block');
  }else if(txtCheck.indexOf('\u3059\u307e\u3044\u30fc\u3060') >= 0){
    // txt = すまいーだ
    jQuery('#top-slider-warp:not(.js-rank-i)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-i)').remove();
    jQuery('.js-rank-i').css('display', 'block');
  }else if(txtCheck.indexOf('\u30b5\u30f3\u30c8\u30ea\u30fc') >= 0){
    // txt = サントリー
    jQuery('#top-slider-warp:not(.js-rank-u)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-u)').remove();
    jQuery('.js-rank-u').css('display', 'block');
  }else if(txtCheck.indexOf('SCSK\u793e\u54e1') >= 0){
    // txt = SCSK
    jQuery('#top-slider-warp:not(.js-rank-k)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-k)').remove();
    jQuery('.js-rank-k').css('display', 'block');
  }else if(txtCheck.indexOf('ANA\u30b0\u30eb\u30fc\u30d7') >= 0){
    // txt = ANA
    jQuery('#top-slider-warp:not(.js-rank-a)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-a)').remove();
    jQuery('.js-rank-a').css('display', 'block');
  }else if(txtCheck.indexOf('NID-Net\u52a0\u76df\u793e') >= 0){
    // txt = NID
    jQuery('#top-slider-warp:not(.js-rank-n)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-n)').remove();
    jQuery('.js-rank-n').css('display', 'block');
  }else if(txtCheck.indexOf('\u307f\u3069\u308a\u4f1a') >= 0){
    // txt = みどり会
    jQuery('#top-slider-warp:not(.js-rank-m)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-m)').remove();
    jQuery('.js-rank-m').css('display', 'block');
}else if(txtCheck.indexOf('\u7279\u7d04\u5e97\u5f93\u696d\u54e1\u69d8') >= 0){
    // txt = 特約店
    jQuery('#top-slider-warp:not(.js-rank-t)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-t)').remove();
    jQuery('.js-rank-t').css('display', 'block');
}else if(txtCheck.indexOf('\NICS PORT\u4f1a\u54e1\u3055\u307e') >= 0){
    // txt = 日産
    jQuery('#top-slider-warp:not(.js-rank-ns)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-ns)').remove();
    jQuery('.js-rank-ns').css('display', 'block');
}else if(txtCheck.indexOf('ENEOS\u30b0\u30eb\u30fc\u30d7\u5f93\u696d\u54e1\u69d8') >= 0){
    // txt = ENEOS
    jQuery('#top-slider-warp:not(.js-rank-en)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-en)').remove();
    jQuery('.js-rank-en').css('display', 'block');
}else if(txtCheck.indexOf('\u4e00\u6761\u5de5\u52d9\u5e97\u30b0\u30eb\u30fc\u30d7\u5f93\u696d\u54e1\u69d8') >= 0){
    // txt = 一条工務店
    jQuery('#top-slider-warp:not(.js-rank-ic)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-ic)').remove();
    jQuery('.js-rank-ic').css('display', 'block');
}else if(txtCheck.indexOf('\u30ea\u30f3\u30ca\u30a4\u30b0\u30eb\u30fc\u30d7\u5f93\u696d\u54e1\u69d8') >= 0){
    // txt = リンナイ
    jQuery('#top-slider-warp:not(.js-rank-rn)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-rn)').remove();
    jQuery('.js-rank-rn').css('display', 'block');
}else if(txtCheck.indexOf('\uff2a\uff34\u30b0\u30eb\u30fc\u30d7\u5f93\u696d\u54e1\u69d8') >= 0){
    // txt = JT
    jQuery('#top-slider-warp:not(.js-rank-jt)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-jt)').remove();
    jQuery('.js-rank-jt').css('display', 'block');
}else if(txtCheck.indexOf('\u30d5\u30af\u30c0\u96fb\u5b50\u30b0\u30eb\u30fc\u30d7\u5f93\u696d\u54e1\u69d8') >= 0){
    // txt = フクダ電子
    jQuery('#top-slider-warp:not(.js-rank-fd)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-fd)').remove();
    jQuery('.js-rank-fd').css('display', 'block');
}else if(txtCheck.indexOf('\u30c8\u30e9\u30b9\u30b3\u4e2d\u5c71(\u682a)\u5f93\u696d\u54e1\u69d8') >= 0){
    // txt = トラスコ中山
    jQuery('#top-slider-warp:not(.js-rank-tr)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-tr)').remove();
    jQuery('.js-rank-tr').css('display', 'block');
}else if(txtCheck.indexOf('\u30e6\u30cb\u30fb\u30c1\u30e3\u30fc\u30e0\u30b0\u30eb\u30fc\u30d7') >= 0){
    // txt = ユニチャーム
    jQuery('#top-slider-warp:not(.js-rank-un)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-un)').remove();
    jQuery('.js-rank-un').css('display', 'block');
}else if(txtCheck.indexOf('JAL\u30b0\u30eb\u30fc\u30d7') >= 0){
    // txt = JAL
    jQuery('#top-slider-warp:not(.js-rank-j)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-j)').remove();
    jQuery('.js-rank-j').css('display', 'block');
}else if(txtCheck.indexOf('\u30AA\u30EA\u30A8\u30F3\u30BF\u30EB\u30E9\u30F3\u30C9\u5171\u6E08\u4F1A') >= 0){
  // txt = オリエンタルランド共済会
  jQuery('#top-slider-warp:not(.js-rank-ori)').remove();
  jQuery('.top-features-list-wrap:not(.js-rank-ori)').remove();
  jQuery('.js-rank-ori').css('display', 'block');
}else if(txtCheck.indexOf('\u4E2D\u592E\u65E5\u571F\u5730') >= 0){
  // txt = 中央日土地
  jQuery('#top-slider-warp:not(.js-rank-chu)').remove();
  jQuery('.top-features-list-wrap:not(.js-rank-chu)').remove();
  jQuery('.js-rank-chu').css('display', 'block');
}else if(txtCheck.indexOf('HK net service') >= 0){
  // txt = HK net service（ホンダ開発）
  jQuery('#top-slider-warp:not(.js-rank-hon)').remove();
  jQuery('.top-features-list-wrap:not(.js-rank-hon)').remove();
  jQuery('.js-rank-hon').css('display', 'block');
}else if(txtCheck.indexOf('NTT\u30B3\u30DF\u30E5\u30CB\u30B1\u30FC\u30B7\u30E7\u30F3\u30BA') >= 0){
  // txt = NTTコミュニケーションズ
  jQuery('#top-slider-warp:not(.js-rank-ntt)').remove();
  jQuery('.top-features-list-wrap:not(.js-rank-ntt)').remove();
  jQuery('.js-rank-ntt').css('display', 'block');
}else if(txtCheck.indexOf('\u4E09\u4FE1\u96FB\u6C17') >= 0){
  // txt = 三信電気
  jQuery('#top-slider-warp:not(.js-rank-san)').remove();
  jQuery('.top-features-list-wrap:not(.js-rank-san)').remove();
  jQuery('.js-rank-san').css('display', 'block');
}else if(txtCheck.indexOf('\u304D\u3093\u3067\u3093') >= 0){
  // txt = きんでん
  jQuery('#top-slider-warp:not(.js-rank-kin)').remove();
  jQuery('.top-features-list-wrap:not(.js-rank-kin)').remove();
  jQuery('.js-rank-kin').css('display', 'block');
}else if(txtCheck.indexOf('\u5357\u6771\u5317\u30B0\u30EB\u30FC\u30D7') >= 0){
  // txt = 南東北グループ（脳神経疾患研究所）
  jQuery('#top-slider-warp:not(.js-rank-min)').remove();
  jQuery('.top-features-list-wrap:not(.js-rank-min)').remove();
  jQuery('.js-rank-min').css('display', 'block');
}else if(txtCheck.indexOf('\u3042\u3044\u304A\u3044\u30CB\u30C3\u30BB\u30A4\u540C\u548C') >= 0){
  // txt = あいおいニッセイ同和
  jQuery('#top-slider-warp:not(.js-rank-aioi)').remove();
  jQuery('.top-features-list-wrap:not(.js-rank-aioi)').remove();
  jQuery('.js-rank-aioi').css('display', 'block');
}else if(txtCheck.indexOf('\u30ED\u30FC\u30E0') >= 0){
  // txt = ローム
  jQuery('#top-slider-warp:not(.js-rank-roh)').remove();
  jQuery('.top-features-list-wrap:not(.js-rank-roh)').remove();
  jQuery('.js-rank-roh').css('display', 'block');
}else if(txtCheck.indexOf('\u30A4\u30EF\u30BF\u30CB\u30B0\u30EB\u30FC\u30D7') >= 0){
  // txt = イワタニグループ（岩谷産業）
  jQuery('#top-slider-warp:not(.js-rank-iwa)').remove();
  jQuery('.top-features-list-wrap:not(.js-rank-iwa)').remove();
  jQuery('.js-rank-iwa').css('display', 'block');
}else if(txtCheck.indexOf('\u307F\u305A\u307B\u8A3C\u5238') >= 0){
  // txt = みずほ証券
  jQuery('#top-slider-warp:not(.js-rank-msh)').remove();
  jQuery('.top-features-list-wrap:not(.js-rank-msh)').remove();
  jQuery('.js-rank-msh').css('display', 'block');
}else{
    jQuery('.js-company-sales-wrapper').remove();
    jQuery('.js-top-features-list-wrap').remove();
  }
});

/* ====================================
	注文
=====================================*/
/*
jQuery(function(){
	if(jQuery('.page-estimate .block-order-estimate--agreebody').length){
		jQuery('.block-order-estimate--commit p input[type=checkbox]').change(function(){
			var agree_order_input_num = jQuery('.block-order-estimate--commit p input[type=checkbox]').length;
			var now_check_id = jQuery(this).attr('id');
			if(jQuery(this).prop('checked')){
				jQuery('.block-order-estimate--commit p #' + now_check_id).prop("checked", true);
			}else{
				jQuery('.block-order-estimate--commit p #' + now_check_id).prop("checked", false);
			}
			var agree_order_check_num = jQuery('.block-order-estimate--commit p input[type=checkbox]:checked').length;
			if(agree_order_input_num == agree_order_check_num){
				jQuery('input.block-order-estimate--commit-btn').prop('disabled', false);
			}
 		});
	}
});
*/
jQuery(function () {
	var _user_sb = ecblib.customize.user_sb;
	
	if(jQuery('.page-estimate .block-order-estimate--agreebody').length){
		jQuery('.block-order-estimate--commit p input[type=checkbox]').change(function(){
			var agree_order_input_num = jQuery('.block-order-estimate--commit p input[type=checkbox]').length;
			var now_check_id = jQuery(this).attr('id');
			if(jQuery(this).prop('checked')){
				jQuery('.block-order-estimate--commit p #' + now_check_id).prop("checked", true);
			}else{
				jQuery('.block-order-estimate--commit p #' + now_check_id).prop("checked", false);
			}

			if (_user_sb.checkOrderEstimateCommit()) {
				if (typeof ecblib.order_ajax_id_file_upload === 'undefined') {
					jQuery('input.block-order-estimate--commit-btn').prop('disabled', false);
				} else {
					if ( ecblib.order_ajax_id_file_upload.checkEnableEstimateCommitBtn() ) {
						jQuery('input.block-order-estimate--commit-btn').prop('disabled', false);
					} else {
						jQuery('input.block-order-estimate--commit-btn').prop('disabled', true);
					}
				}
			} else {
				jQuery('input.block-order-estimate--commit-btn').prop('disabled', true);
			}
 		});
	}
	_user_sb.checkOrderEstimateCommit = function checkOrderEstimateCommit(){
		var agree_order_input_num = jQuery('.block-order-estimate--commit p input[type=checkbox]').length;
		var agree_order_check_num = jQuery('.block-order-estimate--commit p input[type=checkbox]:checked').length;
		if(agree_order_input_num == agree_order_check_num){
			return true;
		} else {
			return false;
		}
	}
});


jQuery(document).ready(function($) {
	/***** Start jQuery Extension */
	/** LT MENU jQuery extension v5
	 * -----
	 * Quick setup:
	 * div.lt_menu_root (*)
	 * 	|- ul
	 * 	|	|- li
	 *	|	|	|- a.lt_open_submenu_btn[href="#sample_1"]{open menu 1} (**)
	 *	|	|	|- div.lt_submenu#sample_id1>p{menu1} (***)
	 * 	|	|		|- a.lt_close_submenu_btn[href="#sample_1"]{close menu 1}
	 *	|	|
	 *	|	|- li
	 *	|		|- a.lt_open_submenu_btn[href="#sample_2"]{open menu 2}
	 *	|		|- div.lt_submenu#sample_2>p{menu2}
	 *	|			|- a.lt_close_submenu_btn[href="#sample_2"]{close menu 2}
	 *	|
	 *	|- div.lt_submenu_loader>.lt_submenu_loader--inner (****)
	 * -----	
     * Remark: *, **, ***, **** class name is important required
	 */
	$.fn.lt_menu = function(options) {
		let self = jQuery(this);
		options = options || {};
		self.options = {};
		self.onOpenMenu = 0;
		self.onOpenSubmenu = 0;
		self.timer = null;
		self.lastMenu = null;

		self.Init = function() {
			self.options.openBtn = options.openBtn || '.lt_open_submenu_btn';
			self.options.closeBtn = options.closeBtn || '.lt_close_submenu_btn';
			self.options.rootMenu = options.rootMenu || '.lt_menu_root';
			self.options.submenu = options.submenu || '.lt_submenu';
			self.options.submenuLoader = options.submenuLoader || '.lt_submenu_loader';
			self.options.openTime = options.openTime || 300;
			self.options.closeTime = options.closeTime || 200;
			self.options.currentClass = options.currentClass || 'lt_current';
			self.options.currentSubmenuClass = options.currentSubmenuClass || 'lt_current_submenu';
			self.options.menuAction = options.menuAction || 'click';
			self.options.beforeMenuOpen = options.beforeMenuOpen || null;
			self.options.beforeMenuClose = options.beforeMenuClose || null;
			self.options.afterMenuOpen = options.afterMenuOpen || null;
			self.options.afterMenuClose = options.afterMenuClose || null;
			self.options.debug = options.debug || false;
	
			if (self.options.menuAction == 'click') {
				self.find(self.options.openBtn).unbind();
				self.find(self.options.closeBtn).unbind();
	
				// 追加
				// var $targetLink = jQuery('#js-productCate');
				var setTop;
				var count = 0;
				// $targetLink.off('click');
				self.find(self.options.openBtn).off('click');

				self.find(self.options.openBtn).on('click', function() {
					if (jQuery(this).hasClass(self.options.currentClass)) {
						closeMenu(jQuery(this));
					} 
					else {
						openMenu(jQuery(this));
						// 追加
						if(jQuery(this).attr('id') === 'js-productCate') {
							var $closeBtn = jQuery('\<button\>').attr({
								'id': 'js-productCateClose',
								'class': 'productCateClose',
								type: 'button'
							});
							var $closeBtnInner = jQuery('\<span\>').html('\u9589\u3058\u308B');//閉じる;
							$closeBtn.html($closeBtnInner);
							jQuery('.productCate').append($closeBtn.clone());
	
							if (count === 0) {
								count = 1;
								setTop = jQuery(window).scrollTop();
							}
							jQuery('body').addClass('is-gNavMenuActive');
							jQuery('body > .wrapper').css({'top': -setTop});
							var scrollAreaH = jQuery('#lt_global_nav .productCate .lt_submenu_loader--inner').outerHeight();
							var displayMaximumH = jQuery(window).height() - (60 + jQuery('#lt_global_nav .productCate .lt_submenu_loader--header').height());
							if (scrollAreaH < displayMaximumH) {
								jQuery('#lt_global_nav .productCate .lt_submenu_loader--inner').addClass('is-heightFixed');
							} else {
								jQuery('#lt_global_nav .productCate .lt_submenu_loader--inner').removeClass('is-heightFixed');
							}
						}
					}
					return false;
				})

				// 追加
				jQuery(document).on('click', '#js-productCateClose', function () {
					jQuery('body').removeClass('is-gNavMenuActive');
					jQuery('body > .wrapper').css({'top': 0});
					if (setTop !== undefined) {
						window.scrollTo(0 , setTop);
					}
					count = 0;
					jQuery('#lt_global_nav .productCate .lt_submenu_loader--inner').removeClass('is-heightFixed');
					closeMenu(self.find(self.options.openBtn));
					return false;
				});
			}
			else 
			{
				self.find(self.options.submenuLoader).on('mouseenter', function() {
					self.onOpenSubmenu = 1;
				}).on('mouseleave', function() {
					self.onOpenSubmenu = 0;
					let lastHandler = jQuery(this);
					if (self.timer != null) clearTimeout(self.timer);
					self.timer = setTimeout(function() {
						if (self.onOpenMenu == 0 && self.onOpenSubmenu == 0) {
							closeMenu(lastHandler);
						}
					}, 100);
				})
	
				self.find(self.options.openBtn).on('mouseenter', function(e) {
					self.onOpenMenu = 1;
					self.onOpenSubmenu = 1;
					let lastHandler = jQuery(this);
					if (self.timer != null) clearTimeout(self.timer);
					self.timer = setTimeout(function() {
						if (self.onOpenMenu == 1 && !lastHandler.hasClass(self.options.currentClass)) {
							openMenu(lastHandler);
						}
					}, 100);
				}).on('mouseleave', function() {
					self.onOpenMenu = 0;
					self.onOpenSubmenu = 0;
					let lastHandler = jQuery(this);
					if (self.timer != null) clearTimeout(self.timer);
					self.timer = setTimeout(function() {
						if (self.onOpenMenu == 0 && self.onOpenSubmenu == 0) {
							closeMenu(lastHandler);
						}
					}, 100);
				})
			}
	
			self.find(self.options.closeBtn).on('click', function() {
				closeMenu(jQuery(this));
				return false;
			})
	
			jQuery('body').on('click', '*', function(e) {
				if (jQuery(e.target).closest(self.options.rootMenu)[0] != self[0]) {
					cancelMenu();
				}
			})

			if (self.options.debug) {
				console.log('lt_menu: Init complete');
			}
	
			return self;
		}
	
		let openMenu = function(openBtnHandler) {
			let root = openBtnHandler.closest(self.options.rootMenu);
			if (!openBtnHandler.data('submenu')) {
				openBtnHandler.data('submenu', openBtnHandler.attr('href'));
			}
			let submenu = jQuery(openBtnHandler.data('submenu'));
			let submenuLoader = root.find(self.options.submenuLoader);
			let submenuLoaderHeader = submenuLoader.find(self.options.submenuLoader+'--header');
			let submenuLoaderInner = submenuLoader.find(self.options.submenuLoader+'--inner');
			let otherBtn = root.find(self.options.openBtn);
			let currentSubmenu = submenuLoaderInner.find(self.options.submenu);
			if (currentSubmenu.length > 0) {
				self.lastMenu = '#'+jQuery(currentSubmenu[0]).attr('id');
			}
	
			otherBtn.removeClass(self.options.currentClass);
			openBtnHandler.addClass(self.options.currentClass);
			root.find(self.options.openBtn+'[data-submenu="'+openBtnHandler.data('submenu')+'"]').addClass(self.options.currentClass);
	
			$.each(otherBtn, function(_, btn) {
				if (jQuery(btn).parent().parent().find(self.options.openBtn+'[data-submenu="'+openBtnHandler.data('submenu')+'"]').length > 0 ) {
					jQuery(btn).addClass(self.options.currentSubmenuClass);
				}
				else {
					jQuery(btn).removeClass(self.options.currentSubmenuClass);
				}
			})
	
			submenuLoaderInner.empty().append(submenu.clone(true)).hide().fadeIn(self.options.openTime);
			let closeBtn = submenuLoaderInner.find(self.options.closeBtn);
			if (closeBtn.length > 0) closeBtn.data('submenu', openBtnHandler.data('submenu'));
			
			if (typeof(self.options.beforeMenuOpen) == 'function') {
				self.options.beforeMenuOpen(openBtnHandler, submenuLoader, root, self);
				if (self.options.debug) {
					console.log('lt_menu: beforeMenuOpen');
				}
			}
	
			submenuLoader.animate({height:submenuLoaderInner[0].scrollHeight+(submenuLoaderHeader.length>0?submenuLoaderHeader[0].scrollHeight:0)}, self.options.openTime);
			
			if (self.options.debug) {
				console.log('lt_menu: OpenSubMenu');
			}
	
			if (typeof(self.options.afterMenuOpen) == 'function') {
				self.options.afterMenuOpen(openBtnHandler, submenuLoader, root, self);
				if (self.options.debug) {
					console.log('lt_menu: afterMenuOpen');
				}
			}
		}
	
		let closeMenu = function(closeBtnHandler) {
			let root = closeBtnHandler.closest(self.options.rootMenu);
			if (!closeBtnHandler.data('submenu')) {
				closeBtnHandler.data('submenu', closeBtnHandler.attr('href'));
			}
			let openBtn = root.find(self.options.openBtn+'[data-submenu="'+closeBtnHandler.data('submenu')+'"]');
			let otherBtn = root.find(self.options.openBtn);
			let submenuLoader = root.find(self.options.submenuLoader);
			let submenuLoaderInner = submenuLoader.find(self.options.submenuLoader+'--inner');
			
			otherBtn.removeClass(self.options.currentClass);
			openBtn.removeClass(self.options.currentClass);
	
			$.each(otherBtn, function(_, btn) {
				if (jQuery(btn).parent().parent().find(self.options.openBtn+'[data-submenu="'+closeBtnHandler.data('submenu')+'"]').length > 0 ) {
					jQuery(btn).removeClass(self.options.currentSubmenuClass);
				}
			})
	
			if (typeof(self.options.beforeMenuClose) == 'function') {
				self.options.beforeMenuClose(closeBtnHandler, submenuLoader, root, self);
				if (self.options.debug) {
					console.log('lt_menu: beforeMenuClose');
				}
			}
	
			submenuLoaderInner.fadeOut(self.options.closeTime);
			submenuLoader.animate({height:0}, self.options.closeTime);
	
			if (self.options.debug) {
				console.log('lt_menu: CloseSubMenu');
			}
			
			if (typeof(self.options.afterMenuClose) == 'function') {
				self.options.afterMenuClose(closeBtnHandler, submenuLoader, root, self);
				if (self.options.debug) {
					console.log('lt_menu: afterMenuClose');
				}
			}
		}
	
		let cancelMenu = function() {
			let root = self;
			let openBtn = root.find(self.options.openBtn);
			let submenuLoader = root.find(self.options.submenuLoader);
			let submenuLoaderInner = submenuLoader.find(self.options.submenuLoader+'--inner');
			
			openBtn.removeClass(self.options.currentClass);
	
			submenuLoader.animate({height:0}, self.options.closeTime);
			submenuLoaderInner.empty();
		}
	
		self.UpdateMenuHeight = function() {
			let root = self;
			let submenuLoader = root.find(self.options.submenuLoader);
			let submenuLoaderHeader = submenuLoader.find(self.options.submenuLoader+'--header');
			let submenuLoaderInner = submenuLoader.find(self.options.submenuLoader+'--inner');
			submenuLoader.css({height:submenuLoaderInner[0].scrollHeight+(submenuLoaderHeader.length>0?submenuLoaderHeader[0].scrollHeight:0)});
		}
		return self.Init();
	}

	/** LT MODAL jQuery extension v2
	 * -----
	 * Quick setup:
	 * jQuery('body').lt_modal();
	 * a.lt_open_modal_btn[href="#content_1"] (*)
	 * a.lt_open_ytb_modal_btn[href="ytb_id_1"] (**)
	 * -----
     * Remark: *, ** class name is important required
	 */
	$.fn.lt_modal = function(options) {
		let self = jQuery(this);
		let root = jQuery('body');
		let modal = root.find('.lt_modal');
		options = options || {};
		self.options = {};

		self.Init = function() {
			if (modal.length <= 0) {
				modal = jQuery('<div class="lt_modal"><div class="lt_modal--dialog"><div class="lt_modal--content"><div class="lt_dialog"><div class="lt_dialog--header"><a class="lt_close_modal_btn" href="#">Close</a></div><div class="lt_dialog--inner"></div></div></div></div></div>');
				root.prepend(modal);
			}
			
			self.options.openBtn = options.openBtn || '.lt_open_modal_btn';
			self.options.openYtbBtn = options.openYtbBtn || '.lt_open_ytb_modal_btn';
			self.options.closeBtn = options.closeBtn || '.lt_close_modal_btn';
			self.options.openClass = options.openClass || 'lt_modal_open';
			self.options.openYtbClass = options.openYtbClass || 'lt_ytb_modal_open';
			self.options.openTime = options.openTime || 300;
			self.options.closeTime = options.closeTime || 200;
			self.options.beforeModalOpen = options.beforeModalOpen || null;
			self.options.beforeModalClose = options.beforeModalClose || null;
			self.options.afterModalOpen = options.afterModalOpen || null;
			self.options.afterModalClose = options.afterModalClose || null;
			self.options.debug = options.debug || false;
	
			root.find(self.options.openBtn).unbind();
			root.find(self.options.openYtbBtn).unbind();
			root.find(self.options.closeBtn).unbind();

			self.find(self.options.openBtn).on('click', function() {
				let source = jQuery(jQuery(this).attr('href'));
				self.OpenModal(source.clone(true), jQuery(this));
				return false;
			})

			self.find(self.options.openYtbBtn).on('click', function() {
				self.OpenYtbModal(jQuery(this).attr('href'), jQuery(this));
				return false;
			})

			jQuery(window).on('resize', function() {
				self.UpdateYtbRatio();
			})

			self.find(self.options.closeBtn).on('click', function() {
				self.CloseModal(jQuery(this));
				return false;
			})
			
			modal.on('click', function(e) { 
				if (jQuery(e.target).hasClass('lt_modal')) { 
				//if (jQuery(e.target) == self) { 
					self.CloseModal(); 
				} 
				//return false; 
			})

			modal.css({display: 'none'});

			if (self.options.debug) {
				console.log('lt_modal: Init complete');
			}

			return self;
		}

		self.OpenModal = function(source, openBtnHandler) {
			let dialog = root.find('.lt_dialog');
			let dialogInner = dialog.find('.lt_dialog--inner');
			dialogInner.empty();
			dialog.css({'max-width': '1000px'});
			dialogInner.append(source);
			modal.addClass(self.options.openClass);
			modal.fadeIn(self.options.openTime);
			root.addClass(self.options.openClass);

			if (self.options.debug) {
				console.log('lt_modal: OpenModal');
			}
		}

		self.OpenYtbModal = function(ytbId, openBtnHandler) {
			let dialog = root.find('.lt_dialog');
			let dialogInner = dialog.find('.lt_dialog--inner');
			let source = jQuery('<div class="lt_video_frame--outer"><iframe src="" id="lt_video_frame" class="lt_video_frame" allowscriptaccess="always" allow="autoplay"></iframe></div>');
			source.find('#lt_video_frame').attr('src', 'https://www.youtube.com/embed/'+ytbId+'?autoplay=1&amp;modestbranding=1&amp;showinfo=0');
			dialogInner.empty();
			dialog.css({'max-width': '1000px', width: 'auto'});
			dialogInner.append(source);
			modal.addClass(self.options.openClass);
			modal.addClass(self.options.openYtbClass);
			modal.fadeIn(self.options.openTime);
			root.addClass(self.options.openClass);
			root.addClass(self.options.openYtbClass);
			self.UpdateYtbRatio();

			if (self.options.debug) {
				console.log('lt_modal: OpenYtbModal');
			}
		}

		self.CloseModal = function() {
			let dialog = root.find('.lt_dialog');
			let dialogInner = dialog.find('.lt_dialog--inner');
			modal.fadeOut(self.options.closeTime);
			modal.removeClass(self.options.openClass);
			modal.removeClass(self.options.openYtbClass);
			root.removeClass(self.options.openClass);
			root.removeClass(self.options.openYtbClass);
			setTimeout(function() {
				dialogInner.empty();
			}, 300);

			if (self.options.debug) {
				console.log('lt_modal: CloseModal');
			}
		}

		self.UpdateYtbRatio = function() {
			let dialog = root.find('.lt_dialog');
			let ytbFrame = dialog.find('#lt_video_frame');
			let ytbFrameRatio = {
				1000:563,
				764:430,
				500:281,
				350:197,
				300:150,
			};
			let wW = jQuery(window).width();
			let fW = 764;
			if (wW > 1024) {
				fW = 1000;
			}
			else if (fW > 764 && wW <= 1024) {
				fW = 764;
			}
			else if (fW > 500 && wW <= 764) {
				fW = 500;
			}
			else if (fW > 350 && wW <= 500) {
				fW = 350;
			}
			else if (fW <= 350) {
				fW = 300;
			}
			let fH = ytbFrameRatio[fW];
			if (ytbFrame.length > 0) {
				if (jQuery(window).width() > 764) {
					ytbFrame.attr('height', fH);
				} else {
					ytbFrame.removeAttr('height');
				}
				ytbFrame.attr('width', fW);
				// Center window dialog
				dialog.css({top: (jQuery(window).innerHeight()/2)-(dialog.find('.lt_dialog--inner').height()/2)-dialog.find('.lt_dialog--header').height(), position: 'relative'});
			}
		}

		return self.Init();
	}


	/***** End jQuery Extension */

	/***** Start global function */
	/* modal init */
	let lt_modal = jQuery('body').lt_modal({debug: false});
	
	/* History slide */
	let g_historyItem = jQuery("#itemHistoryDetail .block-thumbnail-h li");
	jQuery("#itemHistoryDetail .block-thumbnail-h").css({width: (g_historyItem.length*(160+20))+"px"});
	let g_historyItem_maxHeight = 0;
	g_historyItem.each(function(i,v) { g_historyItem_maxHeight = Math.max(g_historyItem_maxHeight, jQuery(v).height()); });
	g_historyItem.css({height: g_historyItem_maxHeight});

	/***** End global function */

	/***** Start top page function */
	/* pick up layout */
	let pTop_pickupItemCount = jQuery('.page-top #block_of_event .block-thumbnail-t--goods').length;
	let pTop_pickupItemHolder = jQuery('<li></li>');
	let pTop_pickupParent = jQuery('.page-top #block_of_event .block-thumbnail-t--items1');
	let pTop_pickupParentClone = pTop_pickupParent.clone(true).empty().addClass('new-layout');
	if (pTop_pickupItemCount > 0) {
		let col = pTop_pickupItemHolder.clone(true);
		let tmp_item = jQuery('<div></div>');
		jQuery('.page-top #block_of_event .block-thumbnail-t--goods').each(function(i,v) {
			tmp_item = jQuery('<div></div>');
			tmp_item.attr('class', jQuery(v).attr('class'));
			tmp_item.append(jQuery(v).html());
			tmp_item.css({width: (pTop_pickupParent.width()/2) - 20});
			col.append(tmp_item);

			// Reset counter
			if (col.find('.block-thumbnail-t--goods').length >= 2) {
				pTop_pickupParentClone.append(col);
				col = pTop_pickupItemHolder.clone(true);
			}
		})
		pTop_pickupParentClone.insertAfter(jQuery('.page-top #block_of_event .block-thumbnail-t--items'));
		//pTop_pickupParentClone.css({width: tmp_item.width() * pTop_pickupParentClone.find('li').length + (10 * pTop_pickupParentClone.find('li').length) + 10});
		pTop_pickupParent.remove();

		/* set 2 cols item same height */
		let pTop_pickup_sameHeight = function() {
			let max_height = 0;
			//let row_list = [];
			jQuery('.page-top #block_of_event .block-thumbnail-t--goods-description').each(function(i,v) {
				max_height = Math.max(max_height, jQuery(v).height());
				// row_list.push(v);
				// if ((i % 2) != 0) {
				// 	jQuery(row_list).each(function(j,k) {
				// 		jQuery(k).css({height: max_height});
				// 	})
				// 	max_height = 0;
				// 	row_list = [];
				// }
			})
			jQuery('.page-top #block_of_event .block-thumbnail-t--goods-description').css({height: max_height + 0});
		}
		pTop_pickup_sameHeight();
		jQuery(window).on('resize', function() {
			pTop_pickup_sameHeight();
		})
	}	
	
	/* Notification */
	if (jQuery('.page-top .lt_notification ul li').length > 1) {
		jQuery('.page-top .lt_notification ul').slick({
			initialSlide: 0,
			dots: false,
			infinite: false,
			speed: 1000,
			easing: 'ease',
			arrows: true,
			autoplay: true,
			slidesToShow: 1,
			centerMode: true,
			variableWidth: true,
			prevArrow: '<a class="slick-prev" href="#"><img src="../img/usr/sb/icon_notification_prev.png" alt="prev slide"></a>',
			nextArrow: '<a class="slick-next" href="#"><img src="../img/usr/sb/icon_notification_next.png" alt="next slide"></a>',
		});
	}

	/* Instagram slide */
	let instagramSlides = jQuery(".block-top-free-2--instagram dl");
  	let instagramHandler = jQuery("<ul></ul>");
  	$.each(instagramSlides, function(i,e) {
		let newSlide = jQuery("<li></li>");
		instagramHandler.append(newSlide.append(instagramSlides[i]));
	})
  	jQuery(".block-top-free-2--instagram ul").replaceWith(instagramHandler);
  	jQuery(".block-top-free-2--instagram ul").slick({
		slidesToShow: 2,
		dots: false,
		infinite: true,
		speed: 1000,
		easing: 'ease',
		arrows: true,
		autoplay: true,
		centerMode: true,
		variableWidth: true,
		prevArrow: '<a class="slick-prev" href="#"><img src="../img/usr/sb/instagram_slider_prev.png" alt="prev slide"></a>',
		nextArrow: '<a class="slick-next" href="#"><img src="../img/usr/sb/instagram_slider_next.png" alt="next slide"></a>',
		customPaging: function(slick,index) {
			// スライダーのインデックス番号に対応した画像のsrcを取得
			var targetImage = slick.$slides.eq(index).find('img').attr('src');
			// slick-dots > li　の中に上記で取得した画像を設定
			return '<img src=" ' + targetImage + ' "/>';
		}

	});

	/* Video tabs */
	jQuery(".tab_title li a").unbind();
	jQuery(".tab_title li a").on("click", function() {
		let self = jQuery(this);
		let target = jQuery(self.attr('href'));
		self.closest("ul").find("li").removeClass("lt_active");
		self.closest("li").addClass("lt_active");
		target.closest(".tab_body").find(".tab_body--content").removeClass("lt_active");
		target.addClass("lt_active");
		return false;
	})
	jQuery("#tab_content_1 ul").slick({
		slidesToShow: 1,
    	slidesToScroll: 1,
		dots: true,
		infinite: true,
		speed: 1000,
		easing: 'ease',
		arrows: true,
		autoplay: true,
		centerMode: false,
		variableWidth: false,
		prevArrow: '<a class="slick-prev" href="#"><img src="../img/usr/sb/instagram_slider_prev.png" alt="prev slide"></a>',
		nextArrow: '<a class="slick-next" href="#"><img src="../img/usr/sb/instagram_slider_next.png" alt="next slide"></a>',
		customPaging: function(slick,index) {
			// スライダーのインデックス番号に対応した画像のsrcを取得
			var targetImage = slick.$slides.eq(index).find('img').attr('src');
			// slick-dots > li　の中に上記で取得した画像を設定
			return '<img src=" ' + targetImage + ' "/>';
		}
	});
  	jQuery("#tab_content_2 ul").slick({
		slidesToShow: 1,
    	slidesToScroll: 1,
		dots: true,
		infinite: true,
		speed: 1000,
		easing: 'ease',
		arrows: true,
		autoplay: true,
		centerMode: false,
		variableWidth: false,
		prevArrow: '<a class="slick-prev" href="#"><img src="../img/usr/sb/instagram_slider_prev.png" alt="prev slide"></a>',
		nextArrow: '<a class="slick-next" href="#"><img src="../img/usr/sb/instagram_slider_next.png" alt="next slide"></a>',
		customPaging: function(slick,index) {
			// スライダーのインデックス番号に対応した画像のsrcを取得
			var targetImage = slick.$slides.eq(index).find('img').attr('src');
			// slick-dots > li　の中に上記で取得した画像を設定
			return '<img src=" ' + targetImage + ' "/>';
		}
	});
  	jQuery("#tab_content_3 ul").slick({
		slidesToShow: 1,
    	slidesToScroll: 1,
		dots: true,
		infinite: true,
		speed: 1000,
		easing: 'ease',
		arrows: true,
		autoplay: true,
		centerMode: false,
		variableWidth: false,
		prevArrow: '<a class="slick-prev" href="#"><img src="../img/usr/sb/instagram_slider_prev.png" alt="prev slide"></a>',
		nextArrow: '<a class="slick-next" href="#"><img src="../img/usr/sb/instagram_slider_next.png" alt="next slide"></a>',
		customPaging: function(slick,index) {
			// スライダーのインデックス番号に対応した画像のsrcを取得
			var targetImage = slick.$slides.eq(index).find('img').attr('src');
			// slick-dots > li　の中に上記で取得した画像を設定
			return '<img src=" ' + targetImage + ' "/>';
		}
	});
  	jQuery("#tab_content_4 ul").slick({
		slidesToShow: 1,
    	slidesToScroll: 1,
		dots: true,
		infinite: true,
		speed: 1000,
		easing: 'ease',
		arrows: true,
		autoplay: true,
		centerMode: false,
		variableWidth: false,
		prevArrow: '<a class="slick-prev" href="#"><img src="../img/usr/sb/instagram_slider_prev.png" alt="prev slide"></a>',
		nextArrow: '<a class="slick-next" href="#"><img src="../img/usr/sb/instagram_slider_next.png" alt="next slide"></a>',
		customPaging: function(slick,index) {
			// スライダーのインデックス番号に対応した画像のsrcを取得
			var targetImage = slick.$slides.eq(index).find('img').attr('src');
			// slick-dots > li　の中に上記で取得した画像を設定
			return '<img src=" ' + targetImage + ' "/>';
		}
	});
  	jQuery("#tab_content_5 ul").slick({
		slidesToShow: 1,
    	slidesToScroll: 1,
		dots: true,
		infinite: true,
		speed: 1000,
		easing: 'ease',
		arrows: true,
		autoplay: true,
		centerMode: false,
		variableWidth: false,
		prevArrow: '<a class="slick-prev" href="#"><img src="../img/usr/sb/instagram_slider_prev.png" alt="prev slide"></a>',
		nextArrow: '<a class="slick-next" href="#"><img src="../img/usr/sb/instagram_slider_next.png" alt="next slide"></a>',
		customPaging: function(slick,index) {
			// スライダーのインデックス番号に対応した画像のsrcを取得
			var targetImage = slick.$slides.eq(index).find('img').attr('src');
			// slick-dots > li　の中に上記で取得した画像を設定
			return '<img src=" ' + targetImage + ' "/>';
		}
	});
  	jQuery("#tab_content_6 ul").slick({
		slidesToShow: 1,
    	slidesToScroll: 1,
		dots: true,
		infinite: true,
		speed: 1000,
		easing: 'ease',
		arrows: true,
		autoplay: true,
		centerMode: false,
		variableWidth: false,
		prevArrow: '<a class="slick-prev" href="#"><img src="../img/usr/sb/instagram_slider_prev.png" alt="prev slide"></a>',
		nextArrow: '<a class="slick-next" href="#"><img src="../img/usr/sb/instagram_slider_next.png" alt="next slide"></a>',
		customPaging: function(slick,index) {
			// スライダーのインデックス番号に対応した画像のsrcを取得
			var targetImage = slick.$slides.eq(index).find('img').attr('src');
			// slick-dots > li　の中に上記で取得した画像を設定
			return '<img src=" ' + targetImage + ' "/>';
		}
	});

    /* Change searchbox placeholder */
	jQuery("#header .js-search-box-placeholder").text("キーワード・品番・型番で検索する");

    /* sticky lt_global_nav */
    jQuery(window).on('scroll resize', function() {
        if (jQuery(window).scrollTop() >= jQuery('#header').offset().top) {
			if (!jQuery("#lt_global_nav").hasClass('lt_sticky')) {
				jQuery("#lt_global_nav").css({top: -200});
				jQuery("#lt_global_nav").addClass('lt_sticky');
				jQuery("#lt_global_nav").animate({top: 0}, 400);
			}
        } else {
			if (jQuery("#lt_global_nav").hasClass('lt_sticky')) {
				jQuery("#lt_global_nav").removeClass('lt_sticky');
				jQuery("#lt_global_nav").removeAttr('style');
			}
		}
	});

	/* pick up layout */
	let pickupCount = jQuery("#block_of_event dl").length;
	jQuery("#block_of_event li").css({
		width: (pickupCount*(jQuery("#block_of_event dl").width())+pickupCount*10)/2+"px",
	})

	/* Category show more */
	jQuery(".btn_show_more").on("click", function() {
		let self = jQuery(this);
		self.closest(".block-top-free-1--more").css({display: "none"});
		jQuery('.lt_more_hide').slideDown();
		return false;
	})

	/* Sticky button */
	jQuery(window).on("scroll load", function() {
		let scrollHeight = jQuery(document).height();
		let scrollPosition = jQuery(window).height() + jQuery(window).scrollTop();
		let footHeight = jQuery(".pane-footer").height();
		
		if (scrollHeight - scrollPosition  <= footHeight) {
			jQuery('.lt_sticky_button').fadeOut();
		} else if (jQuery(this).scrollTop() < 80){
			jQuery('.lt_sticky_button').fadeOut();
		} else {
			jQuery('.lt_sticky_button').fadeIn();
		}
	})

	jQuery(".lt_sticky_button a.lt_close").on("click", function() {
		let self = jQuery(this);
		self.closest('.lt_sticky_button').find("#onetime").css({display: "none"});
		return false;
	})
  
  	jQuery('#block_of_topi2c ul').slick({
		initialSlide: 1,
		dots: false,
		infinite: true,
		speed: 1000,
		easing: 'ease',
		arrows: true,
		autoplay: false,
		slidesToShow: 1,
		centerMode: true,
		variableWidth: true,
		prevArrow: '<a class="slick-prev" href="#"><img src="../img/usr/sb/main_slider_prev.png" alt="prev slide"></a>',
		nextArrow: '<a class="slick-next" href="#"><img src="../img/usr/sb/main_slider_next.png" alt="next slide"></a>',
	});

	/* menu init */
	jQuery('.lt_top').lt_menu({menuAction: 'click', debug: false});
	let lt_global_nav = jQuery('#lt_global_nav').lt_menu({
		menuAction: 'click', 
		debug: false,
		beforeMenuOpen: function(openBtnHandler, submenuLoader, root, self) {
			/* Update menu item width */
			let submenuBtn1 = root.find('#lt_global_nav_menu li');
			if (submenuBtn1.length > 0) {
				let menuW1 = submenuLoader.find('.lt_submenu_loader--inner').width();
				submenuBtn1.css({
					width: (menuW1/3),
					height: (menuW1/3),
				});
			}
			
			let submenuBtn2 = root.find('#lt_global_nav_menu .lt_submenu li');
			if (submenuBtn2.length > 0) {
				let menuW2 = submenuLoader.find('.lt_submenu_loader--inner').width();
				submenuBtn2.css({
					width: (menuW2/2),
					height: (menuW2/2),
				});
			}

			/* Go back button & title */
			let goBackBtn = submenuLoader.find('.lt_submenu_loader_goback_btn');
			let submenuTitle = submenuLoader.find('.lt_submenu_loader_title');
			jQuery("#lt_global_nav .lt_submenu_loader--header").css({display: 'block'});
			let submenuTitleLink = jQuery('<a href=""></a>');
			let originalLink = jQuery(root.find('.lt_open_submenu_btn[href="'+openBtnHandler.attr('href')+'"]:not(.lt_submenu_loader_goback_btn)')[0]);
			submenuTitleLink.text(originalLink.text());
			submenuTitleLink.attr('href', originalLink.attr('href'));
			submenuTitle.empty().append(submenuTitleLink);
			if (openBtnHandler.attr('href') == '#lt_global_nav_menu') {
				goBackBtn.addClass('lt_hide');
			} 
			else {
				goBackBtn.attr('href', self.lastMenu);
				goBackBtn.removeClass('lt_hide');
			}

			/* Add searchbox */
			submenuLoader.find('.lt_submenu_loader--header').prepend(jQuery("#block_of_searchbox"));
			
			submenuLoader.css({top: jQuery('#lt_global_nav').height()+6});
		},
		afterMenuOpen: function(openBtnHandler, submenuLoader, root, self) {
			if (openBtnHandler.hasClass('lt_submenu_loader_goback_btn')) {
				jQuery('a[href="'+openBtnHandler.attr('href')+'"]').addClass('lt_current_submenu');
			}
			let submenuLoaderInner = submenuLoader.find('.lt_submenu_loader--inner');
			submenuLoaderInner.css({'height': window.innerHeight-106-45});
			// if (jQuery('#lt_global_nav').hasClass('lt_sticky')) {
			// 	submenuLoaderInner.css({'height': window.innerHeight-106-45});
			// } else {
			// 	submenuLoaderInner.css({'height': submenuLoaderInner.innerHeight()});
			// }
		},
		beforeMenuClose: function(closeBtnHandler, submenuLoader, root, self) {
			jQuery("#lt_global_nav .lt_submenu_loader--header").css({display: 'none'});
			jQuery("#block_of_searchbox").insertAfter(jQuery("#lt_global_nav"));
		},
	});
	jQuery(window).on('scroll resize', function() {
		/* Update menu item width */
		let submenuBtn1 = jQuery('#lt_global_nav .lt_submenu_loader #lt_global_nav_menu li');
		if (submenuBtn1.length > 0) {
			let menuW1 = submenuBtn1.closest('.lt_submenu_loader--inner').width();
			submenuBtn1.css({
				width: (menuW1/3),
				height: (menuW1/3),
			});
		}

		let submenuBtn2 = jQuery('#lt_global_nav .lt_submenu_loader .lt_submenu:not(#lt_global_nav_menu) li');
		if (submenuBtn2.length > 0) {
			let menuW2 = submenuBtn2.closest('.lt_submenu_loader--inner').width();
			submenuBtn2.css({
				width: (menuW2/2),
				height: (menuW2/2),
			});
		}

		jQuery('#lt_global_nav .lt_submenu_loader').css({top: jQuery('#lt_global_nav').height()+6});
		if (submenuBtn1.length > 0) {
			lt_global_nav.UpdateMenuHeight();
		}

		let submenuLoaderInner = jQuery('#lt_global_nav').find('.lt_submenu_loader--inner');
		submenuLoaderInner.css({'height': window.innerHeight-106-45});
		// if (jQuery('#lt_global_nav').hasClass('lt_sticky')) {
		// 	submenuLoaderInner.css({'height': window.innerHeight-106-45});
		// } else {
		// 	submenuLoaderInner.css({'height': submenuLoaderInner.innerHeight()});
		// }
	})

	/***** Start .page-category function */
	/* new topic */
	let block_top_topic = jQuery('.page-category .block-top-topic--items');
	let block_top_topic_item = jQuery('.page-category .block-top-topic--items li');
	block_top_topic.css({width: (block_top_topic_item.width()*block_top_topic_item.length)+(5*(block_top_topic_item.length-1))});
	jQuery('.page-category .block-top-topic--body').prepend(jQuery('<div class="lt-scroll-x"></div>').html(block_top_topic));

	/* mod: .block-category-list--goods */
	let block_goods_filter_header = jQuery('<div class="block-category-list--goods-filter"></div>');
	jQuery('.page-category .block-category-list--goods').prepend(block_goods_filter_header);

	let block_goods_sort_order = jQuery('.page-category .block-goods-list--sort-order-items');
	block_goods_filter_header.append(block_goods_sort_order);

	/* create select 2 from lt_menu extension */
	let goods_select_2 = jQuery('<div class="lt-menu-root lt-select" id="goods_select_2"><div><a href="#goods_select_2_menu" data-submenu="#goods_select_2_menu" class="lt-open-submenu-btn"><span></span></a></div><div id="goods_select_2_menu" class="lt-submenu"></div><div class="lt-submenu-loader"><div class="lt-submenu-loader--inner"></div></div></div>');
	let goods_select_2_menu = goods_select_2.find("#goods_select_2_menu");
	block_goods_sort_order.find('option').each(function(i,v) {
		let select_option = jQuery('<dd class="lt-close-submenu-btn goods_select_2_'+i+' '+(jQuery(v).attr('selected') ? 'active' : '')+'"><a href="'+jQuery(v).attr('value')+'">'+jQuery(v).text()+'</a></dd>');
		goods_select_2_menu.append(select_option);
	})
	goods_select_2.insertBefore(block_goods_sort_order.find('.block-goods-list--sort-order-items-selectbox').hide());
	goods_select_2.find('.lt-open-submenu-btn').html(jQuery('<span></span>').append(goods_select_2_menu.find('.active').clone(true).removeClass('lt-close-submenu-btn').unbind()));
	goods_select_2.lt_menu({
		menuAction: 'click', 
		rootMenu: '.lt-menu-root',
		openBtn: '.lt-open-submenu-btn',
		closeBtn: '.lt-close-submenu-btn',
		submenu: '.lt-submenu',
		submenuLoader: '.lt-submenu-loader',
		currentClass: 'lt-current',
		currentSubmenuClass: 'lt-current-submenu',
		beforeMenuClose: function(btnHandler, submenuLoader, root, self) {
			let selected = btnHandler.clone(true).removeClass('lt-close-submenu-btn').unbind();
			if (!btnHandler.hasClass('lt-open-submenu-btn')) {
				self.find('.lt-open-submenu-btn').html(jQuery('<span></span>').append(selected));
			}
			if (selected.find('a').attr('href')) {
				window.location.replace(selected.find('a').attr('href'));
			}
		}
	});	
	
	let block_goods_display_style = jQuery('.page-category .block-goods-list--display-style-items');
	block_goods_filter_header.append(block_goods_display_style);
	
	/* create select 1 from lt_menu extension */
	let goods_select_1 = jQuery('<div class="lt-menu-root lt-select" id="goods_select_1"><div><a href="#goods_select_1_menu" data-submenu="#goods_select_1_menu" class="lt-open-submenu-btn"><span></span></a></div><div id="goods_select_1_menu" class="lt-submenu"></div><div class="lt-submenu-loader"><div class="lt-submenu-loader--inner"></div></div></div>');
	let goods_select_1_menu = goods_select_1.find("#goods_select_1_menu");
	block_goods_display_style.find('option').each(function(i,v) {
		let select_option = jQuery('<dd class="lt-close-submenu-btn goods_select_1_'+i+' '+(jQuery(v).attr('selected') ? 'active' : '')+'"><a href="'+jQuery(v).attr('value')+'">'+jQuery(v).text()+'</a></dd>');
		goods_select_1_menu.append(select_option);
	})
	goods_select_1.insertBefore(block_goods_display_style.find('.block-goods-list--display-style-items-selectbox').hide());
	goods_select_1.find('.lt-open-submenu-btn').html(jQuery('<span></span>').append(goods_select_1_menu.find('.active').clone(true).removeClass('lt-close-submenu-btn').unbind()));
	goods_select_1.lt_menu({
		menuAction: 'click', 
		rootMenu: '.lt-menu-root',
		openBtn: '.lt-open-submenu-btn',
		closeBtn: '.lt-close-submenu-btn',
		submenu: '.lt-submenu',
		submenuLoader: '.lt-submenu-loader',
		currentClass: 'lt-current',
		currentSubmenuClass: 'lt-current-submenu',
		beforeMenuClose: function(btnHandler, submenuLoader, root, self) {
			let selected = btnHandler.clone(true).removeClass('lt-close-submenu-btn').unbind();
			if (!btnHandler.hasClass('lt-open-submenu-btn')) {
				self.find('.lt-open-submenu-btn').html(jQuery('<span></span>').append(selected));
			}
			if (selected.find('a').attr('href')) {
				window.location.replace(selected.find('a').attr('href'));
			}
		}
	});	

	/* pager count */
	jQuery('.page-category .block-goods-list-naviframe--top').insertBefore(block_goods_filter_header);

	/* arrange goods item height */
	let pCategory_responsive_block_cat_list_item = function() {
		let max_height = 0;
		jQuery('.page-category .block-cat-list li').each(function(i,v) {
			max_height = Math.max(max_height, jQuery(v).innerHeight());
		})
		jQuery('.page-category .block-cat-list li').css({height: max_height});
	}
	pCategory_responsive_block_cat_list_item();
	jQuery(window).on('resize', function() {
		pCategory_responsive_block_cat_list_item();
	})

	/* set 2 cols item same height */
	let pCategory_pickup_sameHeight = function() {
		let max_height = 0;
		let row_list = [];
		jQuery('.page-category #goods_list_auto_load_area .block-thumbnail-t--goods-description').each(function(i,v) {
			max_height = Math.max(max_height, jQuery(v).height());
			row_list.push(v);
			if ((i % 2) != 0) {
				jQuery(row_list).each(function(j,k) {
					jQuery(k).css({height: max_height});
				})
				max_height = 0;
				row_list = [];
			}
		})
	}
	pCategory_pickup_sameHeight();
	jQuery(window).on('resize', function() {
		pCategory_pickup_sameHeight();
	})

	/* move .block-topic-path */
	let block_topic_path = jQuery('.page-category .block-topic-path');
	jQuery('.page-category #header').append(block_topic_path);
	let block_topic_path_width = 0;
	block_topic_path.find('li').each(function(i,v) {
		block_topic_path_width+=jQuery(v).innerWidth();
	})
	block_topic_path.find('ul').css({width: block_topic_path_width});
	/***** End .page-category function */

	/***** Start .page-goods function */
	/* 関連商品 */
	let pGoods_accessoryItem = jQuery(".page-goods .block-goods-detail-j--items .block-goods-detail-j--goods");
	jQuery(".page-goods .block-goods-detail-j--items li").css({width: (pGoods_accessoryItem.length*(165+10))+"px"});
	let pGoods_accessoryItem_maxHeight = 0;
	pGoods_accessoryItem.each(function(i, v) { pGoods_accessoryItem_maxHeight = Math.max(pGoods_accessoryItem_maxHeight, jQuery(v).height()); });
	pGoods_accessoryItem.css({height: pGoods_accessoryItem_maxHeight});
	
	/* Instagram */
	jQuery('.page-goods .block-goods-comment3 ul').slick({
		slidesToShow: 2,
		dots: false,
		pauseOnHover: true,
		infinite: true,
		pauseOnHover: true,
		speed: 1000,
		easing: 'ease',
		arrows: true,
		autoplay: true,
		centerMode: true,
		variableWidth: true,
		prevArrow: '<a class="slick-prev" href="#"><img src="../../img/usr/pc/main_slider_prev.png" alt="prev slide"></a>',
		nextArrow: '<a class="slick-next" href="#"><img src="../../img/usr/pc/main_slider_next.png" alt="next slide"></a>',
	});

	/* .block-add-cart-inner */
	let pGoods_blockAddCart = jQuery('<div class="block-add-cart-inner"></div>');
	if(jQuery('.page-goods .block-add-cart').length){
		pGoods_blockAddCart.insertBefore(jQuery('.page-goods .block-add-cart'));
		pGoods_blockAddCart.append(jQuery('.page-goods .block-goods-favorite'));
		pGoods_blockAddCart.append(jQuery('.page-goods .block-add-cart'));
	}
	if(jQuery('.page-goods .block-no-stock').length){
		pGoods_blockAddCart.insertBefore(jQuery('.page-goods .block-no-stock'));
		pGoods_blockAddCart.append(jQuery('.page-goods .block-goods-favorite'));
		pGoods_blockAddCart.append(jQuery('.page-goods .block-no-stock'));
	}
	
	
	//商品詳細の追従カート
    if(jQuery('.page-goods .block-goods-detail-cart-follow').length){
		if(jQuery('.page-goods .block-add-cart-inner').length){		
			jQuery(window).on('scroll resize', function () {
				var cartTop = jQuery('.page-goods .block-add-cart-inner').offset().top - 140;
				var scrollHeight = jQuery(document).height();
				var scrollPosition = jQuery(window).height() + jQuery(window).scrollTop();
				var footHeight = jQuery('footer').height();
				var scrollnow = jQuery(window).scrollTop();

				if (cartTop < scrollnow) {
					if(!jQuery('.block-goods-detail-cart-follow.close').length){
					   jQuery('.block-goods-detail-cart-follow').addClass('show');
					}
				}else if(cartTop > scrollnow){
					if(!jQuery('.block-goods-detail-cart-follow.close').length){
						jQuery('.block-goods-detail-cart-follow').removeClass('show');
					}
				}
				
				/* #footer_pagetop */
				if (jQuery(this).scrollTop() > 80 && scrollHeight - scrollPosition > footHeight) {
					jQuery('#footer_pagetop').addClass('show');
				} else if (jQuery(this).scrollTop() > 80 && scrollHeight - scrollPosition > footHeight) {
					jQuery('#footer_pagetop').addClass('show');
				} else if (jQuery(this).scrollTop() < 80 || scrollHeight - scrollPosition <= footHeight) {
					jQuery('#footer_pagetop').removeClass('show');
				}
			});
			jQuery('.block-goods-detail-cart-follow-link a[href]').unbind();
			jQuery('.block-goods-detail-cart-follow-link a[href]').click(function(e){
				var speed = 500;
				var href= jQuery(this).attr("href");
				var target = jQuery(href == "#" || href == "" ? 'html' : href);
				var position = target.offset().top - 40; //追従分の高さを調整
				jQuery("html, body").animate({scrollTop:position}, speed, "swing");
				return false;
			});
		}
	}
	
	if(jQuery('.page-goods .block-goods-detail-cart-follow').length){
		var goods_detail_cart_follow = jQuery('.block-goods-detail-cart-follow').outerHeight();
		jQuery('footer.pane-footer').css('margin-bottom', goods_detail_cart_follow);
	}
	
	/* リサイクル券 */
	jQuery('.page-goods .recycling-ticket--header').addClass('lt-open').on('click', function() {
		let self = jQuery(this);
		let target = self.closest('.recycling-ticket');

		if (self.hasClass('lt-open')) {
			self.removeClass('lt-open');
			target.removeClass('lt-open');
			target.animate({height: self.height() + 40}, 200);
		} 
		else {
			self.addClass('lt-open');
			target.addClass('lt-open');
			target.animate({height: target[0].scrollHeight + 2}, 300); //2 = border width top+ bottom
		}
	})

	/* 詳細情報 */
	jQuery('.page-goods .goods-detail-desc-ttl').addClass('lt-open').on('click', function() {
		let self = jQuery(this);
		let target = jQuery('.page-goods .goods-detail-desc-cont');

		if (self.hasClass('lt-open')) {
			self.removeClass('lt-open');
			target.removeClass('lt-open');
			target.animate({height: 0}, 200);
		} 
		else {
			self.addClass('lt-open');
			target.addClass('lt-open');
			target.animate({height: target[0].scrollHeight + 2}, 300);
		}
	})	
	
	/* 日立の洗濯乾燥機が生み出す「ハピネス」 */
	if (jQuery('.page-goods .block-goods-comment3--body > a').length > 1) {
		jQuery('.page-goods .block-goods-comment3--body.block-goods-video-slider').slick({
			slidesToShow: 1,
			dots: false,
			pauseOnHover: true,
			infinite: true,
			pauseOnHover: true,
			responsive: true,
			speed: 1000,
			easing: 'ease',
			arrows: true,
			autoplay: false,
			centerMode: true,
			variableWidth: true,
			prevArrow: '<a class="slick-prev" href="#"><img src="../../../img/usr/pc/main_slider_prev.png" alt="prev slide"></a>',
			nextArrow: '<a class="slick-next" href="#"><img src="../../../img/usr/pc/main_slider_next.png" alt="next slide"></a>',
		});
		let pGoods_updateInstaSlide = function() {
			jQuery('.page-goods .slick-slider').css({width: jQuery(window).innerWidth()});
			jQuery('.page-goods .slick-slider .slick-slide').css({width: jQuery(window).innerWidth()});
		}
		
		jQuery(window).on('resize', function() {
			pGoods_updateInstaSlide ();
		})
		pGoods_updateInstaSlide();
	}else{
		jQuery('.page-goods .block-goods-comment3--body.block-goods-video-slider').css('opacity', '1');
	}

	/* 初期化 */
	if (jQuery('.page-goods .block-goods-detail .js-goods-detail-goods-slider').length > 0) {
		var good_slider_img_num = jQuery('.js-goods-detail-goods-slider > div.js-goods-img-item').length;
		
		jQuery('.page-goods .block-goods-detail .js-goods-detail-gallery-slider li a').each(function (index) {
			jQuery(this).attr('data-slide-index', index);
		});
		let execBxSlider = function () {
			if (this) jQuery(this).off('load.bxSlider error.bxSlider');
			jQuery('.page-goods .block-goods-detail .js-goods-detail-goods-slider').bxSlider({
				mode: 'fade',
				speed: 200,
				auto: false,
				minSlides: 1,
				maxSlides: 1,
				pagerCustom: '.page-goods .block-goods-detail .js-goods-detail-gallery-slider',
				touchEnabled: false,
				preventDefaultSwipeX: true,
				preventDefaultSwipeY: false,
				controls: true,
				responsive: false,
				adaptiveHeight: true,
				onSliderLoad: function () {
					jQuery('.page-goods .block-goods-detail .js-goods-detail-goods-slider img.lazyload').each(function () {
						jQuery(this).attr("src", jQuery(this).attr("data-src")).removeClass("lazyload").addClass("lazyloaded");
					});
					if(good_slider_img_num == 1){
						jQuery('.page-goods .pane-goods-left-side .bx-controls-direction').hide();	
					}					
					
				},
			});
		};
		let firstViewImg = jQuery(".page-goods .block-goods-detail .js-goods-detail-goods-slider img").first();
		if (firstViewImg.hasClass("lazyload")) {
			firstViewImg.on('.page-goods load.bxSlider error.bxSlider', execBxSlider);
			firstViewImg.attr("src", firstViewImg.attr("data-src")).removeClass("lazyload").addClass("lazyloaded");
		} else {
			execBxSlider();
		};
	}
    
	/***** End .page-goods function */

	/***** Start .page-event function */
	/* mod: .block-category-list--goods */
	jQuery('.page-event .block-event-page--goods .block-goods-list-naviframe--top').insertBefore('.page-event .block-event-page--goods');
	
	let pEvent_block_goods_filter_header = jQuery('<div class="block-category-list--goods-filter"></div>');
	jQuery('.page-event .block-event-page--goods').prepend(pEvent_block_goods_filter_header);

	let pEvent_block_goods_sort_order = jQuery('.page-event .block-goods-list--sort-order-items');
	pEvent_block_goods_filter_header.append(pEvent_block_goods_sort_order);

	/* create select 2 from lt_menu extension */
	let pEvent_goods_select_2 = jQuery('<div class="lt-menu-root lt-select" id="goods_select_2"><div><a href="#goods_select_2_menu" data-submenu="#goods_select_2_menu" class="lt-open-submenu-btn"><span></span></a></div><div id="goods_select_2_menu" class="lt-submenu"></div><div class="lt-submenu-loader"><div class="lt-submenu-loader--inner"></div></div></div>');
	let pEvent_goods_select_2_menu = pEvent_goods_select_2.find("#goods_select_2_menu");
	pEvent_block_goods_sort_order.find('option').each(function(i,v) {
		let select_option = jQuery('<dd class="lt-close-submenu-btn goods_select_2_'+i+' '+(jQuery(v).attr('selected') ? 'active' : '')+'"><a href="'+jQuery(v).attr('value')+'">'+jQuery(v).text()+'</a></dd>');
		pEvent_goods_select_2_menu.append(select_option);
	})
	pEvent_goods_select_2.insertBefore(pEvent_block_goods_sort_order.find('.block-goods-list--sort-order-items-selectbox').hide());
	pEvent_goods_select_2.find('.lt-open-submenu-btn').html(jQuery('<span></span>').append(pEvent_goods_select_2_menu.find('.active').clone(true).removeClass('lt-close-submenu-btn').unbind()));
	pEvent_goods_select_2.lt_menu({
		menuAction: 'click', 
		rootMenu: '.lt-menu-root',
		openBtn: '.lt-open-submenu-btn',
		closeBtn: '.lt-close-submenu-btn',
		submenu: '.lt-submenu',
		submenuLoader: '.lt-submenu-loader',
		currentClass: 'lt-current',
		currentSubmenuClass: 'lt-current-submenu',
		beforeMenuClose: function(btnHandler, submenuLoader, root, self) {
			let selected = btnHandler.clone(true).removeClass('lt-close-submenu-btn').unbind();
			if (!btnHandler.hasClass('lt-open-submenu-btn')) {
				self.find('.lt-open-submenu-btn').html(jQuery('<span></span>').append(selected));
			}
			if (selected.find('a').attr('href')) {
				window.location.replace(selected.find('a').attr('href'));
			}
		}
	});	

	let pEvent_block_goods_display_style = jQuery('.page-event .block-goods-list--display-style-items');
	pEvent_block_goods_filter_header.append(pEvent_block_goods_display_style);

	/* create select 1 from lt_menu extension */
	let pEvent_goods_select_1 = jQuery('<div class="lt-menu-root lt-select" id="goods_select_1"><div><a href="#goods_select_1_menu" data-submenu="#goods_select_1_menu" class="lt-open-submenu-btn"><span></span></a></div><div id="goods_select_1_menu" class="lt-submenu"></div><div class="lt-submenu-loader"><div class="lt-submenu-loader--inner"></div></div></div>');
	let pEvent_goods_select_1_menu = pEvent_goods_select_1.find("#goods_select_1_menu");
	pEvent_block_goods_display_style.find('option').each(function(i,v) {
		let select_option = jQuery('<dd class="lt-close-submenu-btn goods_select_1_'+i+' '+(jQuery(v).attr('selected') ? 'active' : '')+'"><a href="'+jQuery(v).attr('value')+'">'+jQuery(v).text()+'</a></dd>');
		pEvent_goods_select_1_menu.append(select_option);
	})
	pEvent_goods_select_1.insertBefore(pEvent_block_goods_display_style.find('.block-goods-list--display-style-items-selectbox').hide());
	pEvent_goods_select_1.find('.lt-open-submenu-btn').html(jQuery('<span></span>').append(pEvent_goods_select_1_menu.find('.active').clone(true).removeClass('lt-close-submenu-btn').unbind()));
	pEvent_goods_select_1.lt_menu({
		menuAction: 'click', 
		rootMenu: '.lt-menu-root',
		openBtn: '.lt-open-submenu-btn',
		closeBtn: '.lt-close-submenu-btn',
		submenu: '.lt-submenu',
		submenuLoader: '.lt-submenu-loader',
		currentClass: 'lt-current',
		currentSubmenuClass: 'lt-current-submenu',
		beforeMenuClose: function(btnHandler, submenuLoader, root, self) {
			let selected = btnHandler.clone(true).removeClass('lt-close-submenu-btn').unbind();
			if (!btnHandler.hasClass('lt-open-submenu-btn')) {
				self.find('.lt-open-submenu-btn').html(jQuery('<span></span>').append(selected));
			}
			if (selected.find('a').attr('href')) {
				window.location.replace(selected.find('a').attr('href'));
			}
		}
	});
	
	/* arrange goods item height */
	let pEvent_responsive_block_cat_list_item = function() {
		let max_height = 0;
		jQuery('.page-event .block-thumbnail-t--items li').each(function(i,v) {
			max_height = Math.max(max_height, jQuery(v).innerHeight());
		})
		jQuery('.page-event .block-thumbnail-t--items li').css({height: max_height});
	}
	pEvent_responsive_block_cat_list_item();
	jQuery(window).on('resize', function() {
		pEvent_responsive_block_cat_list_item();
	})	
	/***** End .page-event function */

	/***** Start .page-search function */
	/* mod: .block-category-list--goods */
	let pSearch_block_goods_filter_header = jQuery('<div class="block-category-list--goods-filter"></div>');
	pSearch_block_goods_filter_header.insertBefore(jQuery('.page-search .block-thumbnail-d, .page-search .block-thumbnail-t'));

	let pSearch_block_goods_sort_order = jQuery('.page-search .block-goods-list--sort-order-items');
	pSearch_block_goods_filter_header.append(pSearch_block_goods_sort_order);

	/* create select 2 from lt_menu extension */
	let pSearch_goods_select_2 = jQuery('<div class="lt-menu-root lt-select" id="goods_select_2"><div><a href="#goods_select_2_menu" data-submenu="#goods_select_2_menu" class="lt-open-submenu-btn"><span></span></a></div><div id="goods_select_2_menu" class="lt-submenu"></div><div class="lt-submenu-loader"><div class="lt-submenu-loader--inner"></div></div></div>');
	let pSearch_goods_select_2_menu = pSearch_goods_select_2.find("#goods_select_2_menu");
	pSearch_block_goods_sort_order.find('option').each(function(i,v) {
		let select_option = jQuery('<dd class="lt-close-submenu-btn goods_select_2_'+i+' '+(jQuery(v).attr('selected') ? 'active' : '')+'"><a href="'+jQuery(v).attr('value')+'">'+jQuery(v).text()+'</a></dd>');
		pSearch_goods_select_2_menu.append(select_option);
	})
	pSearch_goods_select_2.insertBefore(pSearch_block_goods_sort_order.find('.block-goods-list--sort-order-items-selectbox').hide());
	pSearch_goods_select_2.find('.lt-open-submenu-btn').html(jQuery('<span></span>').append(pSearch_goods_select_2_menu.find('.active').clone(true).removeClass('lt-close-submenu-btn').unbind()));
	pSearch_goods_select_2.lt_menu({
		menuAction: 'click', 
		rootMenu: '.lt-menu-root',
		openBtn: '.lt-open-submenu-btn',
		closeBtn: '.lt-close-submenu-btn',
		submenu: '.lt-submenu',
		submenuLoader: '.lt-submenu-loader',
		currentClass: 'lt-current',
		currentSubmenuClass: 'lt-current-submenu',
		beforeMenuClose: function(btnHandler, submenuLoader, root, self) {
			let selected = btnHandler.clone(true).removeClass('lt-close-submenu-btn').unbind();
			if (!btnHandler.hasClass('lt-open-submenu-btn')) {
				self.find('.lt-open-submenu-btn').html(jQuery('<span></span>').append(selected));
			}
			if (selected.find('a').attr('href')) {
				window.location.replace(selected.find('a').attr('href'));
			}
		}
	});	

	let pSearch_block_goods_display_style = jQuery('.page-search .block-goods-list--display-style-items');
	pSearch_block_goods_filter_header.append(pSearch_block_goods_display_style);

	/* create select 1 from lt_menu extension */
	let pSearch_goods_select_1 = jQuery('<div class="lt-menu-root lt-select" id="goods_select_1"><div><a href="#goods_select_1_menu" data-submenu="#goods_select_1_menu" class="lt-open-submenu-btn"><span></span></a></div><div id="goods_select_1_menu" class="lt-submenu"></div><div class="lt-submenu-loader"><div class="lt-submenu-loader--inner"></div></div></div>');
	let pSearch_goods_select_1_menu = pSearch_goods_select_1.find("#goods_select_1_menu");
	pSearch_block_goods_display_style.find('option').each(function(i,v) {
		let select_option = jQuery('<dd class="lt-close-submenu-btn goods_select_1_'+i+' '+(jQuery(v).attr('selected') ? 'active' : '')+'"><a href="'+jQuery(v).attr('value')+'">'+jQuery(v).text()+'</a></dd>');
		pSearch_goods_select_1_menu.append(select_option);
	})
	pSearch_goods_select_1.insertBefore(pSearch_block_goods_display_style.find('.block-goods-list--display-style-items-selectbox').hide());
	pSearch_goods_select_1.find('.lt-open-submenu-btn').html(jQuery('<span></span>').append(pSearch_goods_select_1_menu.find('.active').clone(true).removeClass('lt-close-submenu-btn').unbind()));
	pSearch_goods_select_1.lt_menu({
		menuAction: 'click', 
		rootMenu: '.lt-menu-root',
		openBtn: '.lt-open-submenu-btn',
		closeBtn: '.lt-close-submenu-btn',
		submenu: '.lt-submenu',
		submenuLoader: '.lt-submenu-loader',
		currentClass: 'lt-current',
		currentSubmenuClass: 'lt-current-submenu',
		beforeMenuClose: function(btnHandler, submenuLoader, root, self) {
			let selected = btnHandler.clone(true).removeClass('lt-close-submenu-btn').unbind();
			if (!btnHandler.hasClass('lt-open-submenu-btn')) {
				self.find('.lt-open-submenu-btn').html(jQuery('<span></span>').append(selected));
			}
			if (selected.find('a').attr('href')) {
				window.location.replace(selected.find('a').attr('href'));
			}
		}
	});
	
	/* arrange goods item height */
	let pSearch_responsive_block_cat_list_item = function() {
		let max_height = 0;
		jQuery('.page-search .block-thumbnail-t--items li').each(function(i,v) {
			max_height = Math.max(max_height, jQuery(v).innerHeight());
		})
		jQuery('.page-search .block-thumbnail-t--items li').css({height: max_height});
	}
	pSearch_responsive_block_cat_list_item();
	jQuery(window).on('resize', function() {
		pSearch_responsive_block_cat_list_item();
	})	
	/***** End .page-search function */
});

/* ====================================
	配送日時連動
=====================================*/
jQuery(function () {
	var $dayElem = jQuery('.block-order-estimate--goods-spec-dt_parts');
	var $timeZoneElem = jQuery('.block-order-estimate--goods-spec-time_parts');
	var ind;
	var dayVal;
	var timeZoneVal;

	// 配送希望日
	if ($dayElem.length >= 2) {
		for (ind = 1; ind < $dayElem.length; ind++) {
			$dayElem.eq(ind).find('select').attr('readonly', true).css({'pointer-events': 'none', 'opacity': '.6'});
		}

		$dayElem.on('change', function () {
			dayVal = jQuery(this).find('option:selected').val();

			for (ind = 1; ind < $dayElem.length; ind++) {
				$dayElem.eq(ind).find('select option').each(function () {
					if (dayVal === jQuery(this).val()) {
						jQuery(this).prop('selected', true);
					}
				});
			}
		});
	}

	// 配送希望時間帯
	if ($timeZoneElem.length >= 2) {
		for (ind = 1; ind < $timeZoneElem.length; ind++) {
			$timeZoneElem.eq(ind).find('select').attr('readonly', true).css({'pointer-events': 'none', 'opacity': '.6'});
		}

		$timeZoneElem.on('change', function () {
			timeZoneVal = jQuery(this).find('option:selected').val();

			for (ind = 1; ind < $timeZoneElem.length; ind++) {
				$timeZoneElem.eq(ind).find('select option').each(function () {
					if (timeZoneVal === jQuery(this).val()) {
						jQuery(this).prop('selected', true);
					}
				});
			}
		});
	}
});

/* ====================================
	iPhone判定
=====================================*/
jQuery(function () {
	var iphone = navigator.userAgent.indexOf('iPhone') !== -1;
	if(iphone) {
		jQuery('html').addClass('is-iphone');
	}
});


/* ============================================================
					詳細検索アコーディオン
==============================================================*/
jQuery(function() {
	if(jQuery('.page-search').length){
		let search_ac_btn = jQuery('.block-search-goods--condition-items-ttl-tab');
		let search_ac_cont = jQuery('.block-search-goods--condition-items-tab-cont');
		search_ac_btn.on('click', function() {
			if(search_ac_btn.hasClass('block-search-goods-btn-on')){
				search_ac_btn.removeClass('block-search-goods-btn-on');
				search_ac_cont.slideUp();
			}else{
				search_ac_btn.addClass('block-search-goods-btn-on');   
				search_ac_cont.slideDown();
			}
		});
	}
});


// モーダル
jQuery(function(){
	var $modalItem = jQuery('[id^=js-modal]');
	var $modalItemLength = $modalItem.length;

	if ($modalItemLength <= 0) {
		return;
	}

	var $win = jQuery(window);
	var $doc = jQuery(document);
	var $body = jQuery('body');
	var modalOpenClass = 'is-modalOpen';
	var hiddenClass = 'is-hidden';
	var $btnTrigger = jQuery('[data-modal^=js-modal]');
	var $dataModal;
	var $dataModalName;
	var $targetModalItem;
	var $targetModalItemInner;
	var $modalOverlay;
	var $modalId;
	var winHeight;
	var targetHeight;
	var clientWidth;
	var noScrollbarWidth;
	var difference;
	var scrollPosition;

	$modalItem.each(function () {
		jQuery(this)
		.attr({
			'role': 'dialog',
			'aria-modal': 'true'
		});
	});

	$modalOverlay = jQuery('\<div\>').attr({
		'id': 'js-modalOverlay',
		'class': 'c-modalOverlay'
	});

	$btnTrigger.on('click', function () {
		$dataModal = jQuery(this).data('modal');
		$dataModalName = '#' + $dataModal;
		$targetModalItem = jQuery($dataModalName);
		$targetModalItemInner = $targetModalItem.find('.c-modal-inner');
		clientWidth = $body[0].clientWidth;

		$targetModalItemInner.attr('tabindex', 0);
		$targetModalItem.removeClass(hiddenClass).wrap($modalOverlay);
		jQuery('.is-focusFirst').focus();
		// scrollPosition = $win.scrollTop();
		// $body.addClass(modalOpenClass).css('top', scrollPosition);
		$body.addClass(modalOpenClass);

		winHeight = $win.height();
		targetHeight = $targetModalItem.outerHeight();
		if(targetHeight > winHeight*.8) {
			$targetModalItem.addClass('is-contentsOver');
		}

		return false;
	});

	$doc.on('click', '#js-modalOverlay, .js-btn-modalClose', function() {
		closeModal();
	});

	$doc.on('click', '#js-modalContentsArea, [id^=js-modal]', function(e) {
		e.stopPropagation();
	});

	function closeModal() {
		$modalOverlay = jQuery('#js-modalOverlay');
		$targetModalItem = $modalOverlay.find($modalItem);
		$targetModalItemInner = $targetModalItem.find('.c-modal-inner');
		$modalId = $targetModalItem.attr('id');

		$targetModalItemInner.attr('tabindex', -1);
		$targetModalItem.addClass(hiddenClass).unwrap($modalOverlay);
		// $body.removeClass(modalOpenClass).css('top', '');
		$body.removeClass(modalOpenClass);
		$btnTrigger.each(function () {
			$this = jQuery(this);
			$dataModal = $this.data('modal');
			if($dataModal === $modalId) {
				$this.focus();
			}
		});
	}
});

/* ==============================
	カテゴリトピックスライダー
============================= */
jQuery(function(){
	if (jQuery('.page-category ul.block-top-topic--items li').length > 1) {
		jQuery('.page-category ul.block-top-topic--items').slick({
			initialSlide: 0,
			dots: false,
			infinite: false,
			speed: 1000,
			easing: 'ease',
			arrows: true,
			autoplay: true,
			slidesToShow: 1,
			centerMode: true,
			variableWidth: true,
			prevArrow: '<a class="slick-prev" href="#"><img src="/img/usr/sb/icon_notification_prev.png" alt="prev slide"></a>',
			nextArrow: '<a class="slick-next" href="#"><img src="/img/usr/sb/icon_notification_next.png" alt="next slide"></a>',
		});
	}
});

/* ============================================================
					エアコン関連修正
==============================================================*/
jQuery(function(){
	
	/* --------------------必須項目の数を取得---------------------- */
	
	if(jQuery('.page-estimate #js-modalContentsArea').length) {
		jQuery('.page-estimate #js-modalContentsArea').each(function() {
			
			//id取得
			var const_modal_id = jQuery(this).find('.c-modal').attr('id');
			var const_modal_posi = '.block-area-quecheck-inner a[data-modal="' + const_modal_id + '"]'; 
			
			//必須項目の数
			var item_required_num_list = jQuery(this).find('.frm-list-required-item').length;
			jQuery(this).find('.block-area-questionnaire').attr('data-required-num', item_required_num_list);
			
			jQuery(this).find('.block-area-questionnaire-nest').each(function() {
				jQuery(this).find('.frm-list-required-item').each(function() {
					if(jQuery(this).hasClass('frm-list-floor-number')){	
						if(jQuery(this).find('input[type="text"]').val() != ''){
							jQuery(this).addClass('frm-list-required-check-on');
						}
					}else if(jQuery(this).hasClass('frm-list-removal-number')){
						var item_required_radio_val = jQuery(this).find('input[type="radio"]:checked').val();
						var item_required_txt_val = jQuery(this).find('input[type="number"]').val();

						if(item_required_radio_val == '0' && item_required_txt_val != ''){
							jQuery(this).addClass('frm-list-required-check-on');
						}else if(item_required_radio_val == '9'){
							jQuery(this).addClass('frm-list-required-check-on');
						}					
					}else if(jQuery(this).hasClass('frm-list-required-item')){
						var item_required_radio_check = jQuery(this).find('input[type="radio"]:checked').length;
						if(item_required_radio_check > 0){
							jQuery(this).addClass('frm-list-required-check-on');
						}
					}
				});
			});
				
			//完了したチェック数
			var now_item_required_check = jQuery(this).find('.block-area-questionnaire .frm-list-required-check-on').length;

			if(now_item_required_check > 1){
				jQuery(this).find('.block-area-questionnaire').addClass('block-area-questionnaire-check-on');				
			}
			
			//チェック完了でdisabledはずす
			if(item_required_num_list == now_item_required_check){
				jQuery(this).find('.block-area-questionnaire .quecheck-btn-inner').prop('disabled', false);
				jQuery(this).find('.block-area-questionnaire .quecheck-btn-inner').addClass('quecheck-btn-inner-on');
				jQuery(const_modal_posi).parents('.block-area-quecheck-inner').find('.quecheck-checkbox-wrap input').prop('disabled', false);
			}else{
				jQuery(this).find('.block-area-questionnaire .quecheck-btn-inner').prop('disabled', true);		
				jQuery(this).find('.block-area-questionnaire .quecheck-btn-inner').removeClass('quecheck-btn-inner-on');
				//jQuery(const_modal_posi).parents('.block-area-quecheck-inner').find('.quecheck-checkbox-wrap input').removeAttr("checked").prop("checked", false).change();			
				jQuery(const_modal_posi).parents('.block-area-quecheck-inner').find('.quecheck-checkbox-wrap input').prop('disabled', true);
			}			
		});
	}
	
	/* --------------------工事内容のチェック---------------------- */	
	jQuery('.quecheck-checkbox-wrap input[type="checkbox"]').change(function() {
		if(jQuery(this).prop('checked')) {
			jQuery(this).parents('.block-area-questionnaire').addClass('block-area-questionnaire-check-on');
		}else{
			jQuery(this).parents('.block-area-questionnaire').removeClass('block-area-questionnaire-check-on');			
		}
	});
	
	/* --------------------必須項目のチェック（ラジオボタン）---------------------- */		
	jQuery('.block-area-questionnaire-nest .frm-list-required-item').not('.frm-list-removal-number').find('input[type="radio"]').change(function () {
		
		//id取得
		var const_modal_id = jQuery(this).parents('.c-modal').attr('id');
		var const_modal_posi = '.block-area-quecheck-inner a[data-modal="' + const_modal_id + '"]'; 
		
		//必須項目の数
		var item_required_num_list = jQuery(this).parents('.block-area-questionnaire').attr('data-required-num');
		
		//クリックでクラス追加
		jQuery(this).parents('.frm-list-required-item').addClass('frm-list-required-check-on');
		
		//完了したチェック数
		var now_item_required_check = jQuery(this).parents('.block-area-questionnaire').find('.frm-list-required-check-on').length;

		//チェック完了でdisabledはずす
		if(item_required_num_list == now_item_required_check){
			jQuery(this).parents('.block-area-questionnaire').find('.quecheck-btn-inner').prop('disabled', false);
			jQuery(this).parents('.block-area-questionnaire').find('.quecheck-btn-inner').addClass('quecheck-btn-inner-on');
			jQuery(const_modal_posi).parents('.block-area-quecheck-inner').find('.quecheck-checkbox-wrap input').prop('disabled', false);
		}else{
			jQuery(this).parents('.block-area-questionnaire').find('.quecheck-btn-inner').prop('disabled', true);		
			jQuery(this).parents('.block-area-questionnaire').find('.quecheck-btn-inner').removeClass('quecheck-btn-inner-on');
			//jQuery(const_modal_posi).parents('.block-area-quecheck-inner').find('.quecheck-checkbox-wrap input').removeAttr("checked").prop("checked", false).change();			
			jQuery(const_modal_posi).parents('.block-area-quecheck-inner').find('.quecheck-checkbox-wrap input').prop('disabled', true);
		}
	});

	/* --------------------既存のエアコン取外し ラジオボタン + テキストボックス---------------------- */
	jQuery('.block-area-questionnaire-nest .frm-list-required-item.frm-list-removal-number input').change(function () {

		//id取得
		var const_modal_id = jQuery(this).parents('.c-modal').attr('id');
		var const_modal_posi = '.block-area-quecheck-inner a[data-modal="' + const_modal_id + '"]'; 
		
		//必須項目の数
		var item_required_num_list = jQuery(this).parents('.block-area-questionnaire').attr('data-required-num');
		
		//ラジオボタンのvalueを取得
		var item_required_radio_val = jQuery(this).parents('.frm-list-required-item.frm-list-removal-number').find('input[type="radio"]:checked').val();
		
		//テキストボックスのvalueを取得
		var item_required_txt_val = jQuery(this).parents('.frm-list-required-item.frm-list-removal-number').find('input[type="text"]').val();
		
		//選択のチェック
		if(item_required_radio_val == 0){
			if(item_required_txt_val != ""){
				jQuery(this).parents('.frm-list-required-item').addClass('frm-list-required-check-on');			
			}else{
				jQuery(this).parents('.frm-list-required-item').removeClass('frm-list-required-check-on');				
			}
		}else if(item_required_radio_val == 9){
			jQuery(this).parents('.frm-list-required-item').addClass('frm-list-required-check-on');				 
		}else{
			jQuery(this).parents('.frm-list-required-item').removeClass('frm-list-required-check-on');			
		}
		
		//完了したチェック数
		var now_item_required_check = jQuery(this).parents('.block-area-questionnaire').find('.frm-list-required-check-on').length;

		//チェック完了でdisabledはずす
		if(item_required_num_list == now_item_required_check){
			jQuery(this).parents('.block-area-questionnaire').find('.quecheck-btn-inner').prop('disabled', false);
			jQuery(this).parents('.block-area-questionnaire').find('.quecheck-btn-inner').addClass('quecheck-btn-inner-on');
			jQuery(const_modal_posi).parents('.block-area-quecheck-inner').find('.quecheck-checkbox-wrap input').prop('disabled', false);
		}else{
			jQuery(this).parents('.block-area-questionnaire').find('.quecheck-btn-inner').prop('disabled', true);		
			jQuery(this).parents('.block-area-questionnaire').find('.quecheck-btn-inner').removeClass('quecheck-btn-inner-on');
			//jQuery(const_modal_posi).parents('.block-area-quecheck-inner').find('.quecheck-checkbox-wrap input').removeAttr("checked").prop("checked", false).change();			
			jQuery(const_modal_posi).parents('.block-area-quecheck-inner').find('.quecheck-checkbox-wrap input').prop('disabled', true);			
		}
	});
	
	/* --------------------取り付け階数 テキストボックス---------------------- */
	jQuery('.block-area-questionnaire-nest .frm-list-required-item.frm-list-floor-number input[type="text"]').change(function () {

		//id取得
		var const_modal_id = jQuery(this).parents('.c-modal').attr('id');
		var const_modal_posi = '.block-area-quecheck-inner a[data-modal="' + const_modal_id + '"]'; 
		
		//必須項目の数
		var item_required_num_list = jQuery(this).parents('.block-area-questionnaire').attr('data-required-num');
		
		//入力された値
		var item_required_textbox = jQuery(this).val();
		
		//入力されているか判定
		if (item_required_textbox != "") { 		
			jQuery(this).parents('.frm-list-required-item').addClass('frm-list-required-check-on');
		}else{
			jQuery(this).parents('.frm-list-required-item').removeClass('frm-list-required-check-on');			
		}
		
		//完了したチェック数
		var now_item_required_check = jQuery(this).parents('.block-area-questionnaire').find('.frm-list-required-check-on').length;
		
		//チェック完了でdisabledはずす
		if(item_required_num_list == now_item_required_check){
			jQuery(this).parents('.block-area-questionnaire').find('.quecheck-btn-inner').prop('disabled', false);
			jQuery(this).parents('.block-area-questionnaire').find('.quecheck-btn-inner').addClass('quecheck-btn-inner-on');
			jQuery(const_modal_posi).parents('.block-area-quecheck-inner').find('.quecheck-checkbox-wrap input').prop('disabled', false);
		}else{
			jQuery(this).parents('.block-area-questionnaire').find('.quecheck-btn-inner').prop('disabled', true);		
			jQuery(this).parents('.block-area-questionnaire').find('.quecheck-btn-inner').removeClass('quecheck-btn-inner-on');
			//jQuery(const_modal_posi).parents('.block-area-quecheck-inner').find('.quecheck-checkbox-wrap input').removeAttr("checked").prop("checked", false).change();			
			jQuery(const_modal_posi).parents('.block-area-quecheck-inner').find('.quecheck-checkbox-wrap input').prop('disabled', true);			
		}
	});
});

/* 20220916 */
jQuery(function () {
		jQuery('.block-top-free1-category').slick({
			slidesToShow: 3,
			slidesToScroll:3,
			dots: false,
			pauseOnHover: true,
			infinite: true,
			speed: 1000,
			arrows: true,
			autoplay: false,
			variableWidth: true,
			prevArrow: '<a class="slick-prev" href="#"><img src="../img/usr/pc/slider_prev.png" alt="prev slide"></a>',
			nextArrow: '<a class="slick-next" href="#"><img src="../img/usr/pc/slider_next.png" alt="next slide"></a>',
		});
});

/* ====================================
	Group Global Header / Footer
=====================================*/
jQuery.extend({
    // 画面サイズ
    isSM : function(){
        return (window.innerWidth || document.documentElement.clientWidth) < 768
    }
});

// コピーライト
jQuery(function(){
    const year1 = parseInt(jQuery("#Copyright span").text());
    const year2 = (new Date()).getFullYear();
    if (isNaN(year1)) return;
    if (year1 == year2) return;
    if (year1 < year2) jQuery("#Copyright span").text(year1 + ", " + year2);
});

// サポートメニュー
jQuery(function(){
    if (jQuery(".SupportNaviIconText").length == 0) {
        return;
    }

    const $search = jQuery("#SupportNaviSearch");
    const alt = $search.find("img").attr("alt");

    jQuery(".SupportNaviIconText>a, .SupportNaviIconText>button").each(function(){
        if (!jQuery(this).is($search)) {
            jQuery(this).find("img").attr("alt", null);
        }
    });

    jQuery(window).on("resize.SupportNavi", function(){
        if (jQuery.isSM()) {
            $search.find("img").attr("alt", alt);
        } else {
            $search.find("img").attr("alt", null);
        }
    }).triggerHandler("resize.SupportNavi");
});

// 検索
jQuery(function(){
    const $form = jQuery("#SearchFormArea");
    const $header = jQuery("#HeaderArea1");
    const $btn = jQuery("button#SupportNaviSearch");

    if ($form.length == 0 || $btn.length == 0) {
        return;
    }

    // 検索を開く
    function open() {
        jQuery("button#SupportNaviLang.is-open").triggerHandler("click");
        jQuery("#SpMenuBtn.is-open").triggerHandler("click");

        if (!jQuery.isSM() || $header.find(".ContainerFix").length) {
            $form.stop(true, true).slideDown({progress:function(){
                $header.css("margin-bottom", $form.outerHeight());
            }});
        } else {
            jQuery("html").css("overflow", "hidden");
            jQuery("body").addClass("spsearch-open");
            $backdrop.appendTo("body").ready(function(){
                $backdrop.addClass("show");
            });
            $form.show().ready(function(){
                $form.addClass("show");
            });
        }

        $btn.addClass("is-open").attr("aria-expanded", "true");
    }

    // 検索を閉じる
    function close() {
        if (!jQuery.isSM() || $header.find(".ContainerFix").length) {
            $form.stop(true, true).slideUp({progress:function(){
                $header.css("margin-bottom", $form.outerHeight());
            }});
        }
        jQuery("html").css("overflow", "");
        jQuery("body").removeClass("spsearch-open");
        $form.removeClass("show");
        $backdrop.removeClass("show");
        $btn.removeClass("is-open").attr("aria-expanded", "false");
    }

    $form.on("transitionend webkitTransitionEnd", function() {
        if (!$form.hasClass("show")) {
            $form.hide();
        }
    });


    // サポートメニューの検索ボタン
    jQuery("button#SupportNaviSearch").on("click", function(){
        if (jQuery(this).hasClass("is-open")) {
            close();
        } else {
            open();
        }
        return false;
    });

    // 検索エリアの閉じるボタン
    jQuery("#SearchFormArea .BtnClose").on("click", function(){
        jQuery("button#SupportNaviSearch.is-open").triggerHandler("click");
        return false;
    });

    // backdrop
    const $backdrop = jQuery('<div id="SpSearchBackdrop"></div>');
    $backdrop.on("transitionend webkitTransitionEnd", function() {
        if (!$backdrop.hasClass("show")) {
            $backdrop.detach();
        }
    });
    $backdrop.on("click", function(e) {
        close();
    });
    
    jQuery(window).on("resize.SearchFormArea", function(){
        $form.css("top", $header.height());
        
        if ($header.find(".Container").length) {
            if (jQuery.isSM()) {
                $header.css("margin-bottom", "");
                if ($form.is(":visible") && !$form.hasClass("show")) {
                    close();
                }
            } else {
                if ($form.is(":visible")) {
                    if ($form.hasClass("show")) close();
                    $header.css("margin-bottom", $form.outerHeight());
                }
            }
        }
        return false;
    }).triggerHandler("resize.SearchFormArea");
});

// スマホメニュー
jQuery(function(){
    const $spMenuBtn = jQuery("#SpMenuBtn");
    const $pcSupNavi = jQuery("#SupportNavi").clone();
    const $pcLangMenu = jQuery("#LangMenu").clone();
    const $pcGlobalMenu = jQuery("#GlobalNaviMenu").clone();
    const $pcMegaMenu = jQuery("#MegaMenu").clone();
    const $pcLocalMenu = jQuery("#HorizontalLocalNavi").clone();
    const $spGlobalMenu = ($pcGlobalMenu.length == 1 ? $pcGlobalMenu : jQuery('<ul id="SpGlobalNavi"></ul>'));
    const $spSupNavi = jQuery('<ul id="SpSupportNavi"></ul>');
    const $spModal = jQuery('<div id="SpMenuModal" tabindex="-1"><div id="SpMenuModalDialog"><div id="SpMenuModalContent"><div id="SpMenuModalBody"></div></div></div></div>');

    if (jQuery("#HeaderArea1>.ContainerFix").length > 0) return;
    if ($spMenuBtn.length == 0) return;

    $spMenuBtn.attr("aria-expanded", "false");
    $spMenuBtn.attr("aria-controls", "SpMenuModalDialog");

    // backdrop
    const $backdrop = jQuery('<div id="SpMenuModalBackdrop"></div>');
    $backdrop.on("transitionend webkitTransitionEnd", function() {
        if (!$backdrop.hasClass("show")) {
            $backdrop.detach();
        }
    });

    // メニューを開く
    function menuOpen() {
        jQuery("button#SupportNaviSearch.is-open").triggerHandler("click");
        jQuery("html").css("overflow", "hidden");
        jQuery("body").addClass("menu-open");
        $spMenuBtn.addClass("is-open").attr("aria-expanded", "true");
        $backdrop.appendTo("body").ready(function(){
            $backdrop.addClass("show");
        });
        $spModal.show().ready(function(){
            $spModal.addClass("show");
        });
    }

    // メニューを閉じる
    function menuClose() {
        jQuery("body").removeClass("menu-open");
        jQuery("html").css("overflow", "");
        $backdrop.removeClass("show");
        $spModal.removeClass("show");
        $spMenuBtn.removeClass("is-open").attr("aria-expanded", "false");
    }

    // メニューボタンのクリック
    $spMenuBtn.on("click", function(){
        if (jQuery(this).hasClass("is-open")) {
            menuClose();
        } else {
            menuOpen();
        }
        return false
    });

    // リサイズ
    jQuery(window).on("resize.SpMenu", function(){
        if (!jQuery.isSM()) {
            menuClose();
        }
    });

    // メニュー項目の開閉
    jQuery(document).on("click", "#SpGlobalNavi button,#SpSupportNavi button", function(){
        if (jQuery(this).hasClass("is-open")) {
            jQuery(this).removeClass("is-open").attr("aria-expanded", "false");
            jQuery(this).next("ul").stop(true, true).slideUp();
        } else {
            jQuery(this).addClass("is-open").attr("aria-expanded", "true");
            jQuery(this).next("ul").stop(true, true).slideDown();
        }
        return false;
    });

    $spModal.on("click", function(e) {
        if (e.target === e.currentTarget) {
            menuClose();
        }
    });

    // メニューの構築
    // グローバルナビ
    if ($spGlobalMenu.length == 1) {
        $spGlobalMenu.attr("id", "SpGlobalNavi");
        $spGlobalMenu.find(".DropDownMenu").removeClass("DropDownMenu");
        $spGlobalMenu.find(".is-open").removeClass("is-open").next("ul").hide();
        $spGlobalMenu.find("button").each(function(){
            const aria = jQuery(this).attr("aria-controls");
            const $ul = jQuery(this).next("ul");
            const id = $ul.attr("id");
            if (aria) {
                jQuery(this).attr("aria-controls", "__SpMenu"+aria);
                $ul.attr("id", "__SpMenu"+$ul.attr("ids"));
            }
            if (id) {
                jQuery(this).attr("aria-controls", "__SpMenu"+aria);
                $ul.attr("id", "__SpMenu"+id);
            }
        });
    }

    // 横型ローカルナビ
    $pcLocalMenu.attr("id", "");
    if ($pcLocalMenu.length) {
        $spGlobalMenu.find(">.Current").each(function(){
            jQuery(this).append($pcLocalMenu.clone().css("display", "block"));
        });
    }

    // メガメニュー
    $pcMegaMenu.find(".MMGlobalNaviStyle").each(function(){
        const $li = jQuery("<li></li>");
        if (jQuery(this).hasClass("Current")) {
            $li.addClass("Current");
        }
        $li.append(jQuery(this).find("a"));
        $spGlobalMenu.append($li);
    });

    // サポートメニュー
    $pcSupNavi.find(">a:not(#SupportNaviSearch),>button:not(#SupportNaviSearch)").each(function(){
        const $li = jQuery("<li></li>");
        if (jQuery(this).prop("tagName").toLowerCase() == "button" && jQuery(this).attr("id") == "SupportNaviLang") {
            const $ul = jQuery("<ul></ul>");
            const $btn = jQuery("<button><span></span></button>");
            const aria = jQuery(this).attr("aria-controls");
            $pcLangMenu.find("a").each(function(){
                $ul.append(jQuery('<li></li>').append(jQuery(this)));
            });
            if (jQuery(this).find("img").length) {
                jQuery(this).find("img").attr("alt", null);
                $btn.find(">span").append(jQuery("<span class='Icon'></span>").append(jQuery(this).find("img")));
            }
            $btn.find(">span").append(jQuery(this).find(">span>span"));
            if (aria) {
                $ul.attr("id", "__SpMenu"+aria);
                $btn.attr("aria-controls" , "__SpMenu"+aria);
                $btn.attr("aria-expanded" , "false");
            }
            $li.append($btn).append($ul);
            $spSupNavi.append($li);
        } else if (jQuery(this).prop("tagName").toLowerCase() == "a") {
            const $item = jQuery(this).clone();
            if ($item.find("img").length) {
                $item.find("img").attr("alt", null);
                $item.prepend("<span class='Icon'></span>");
                $item.find("span.Icon").append($item.find("img"));
            }
            $li.append($item);
            $spSupNavi.append($li);
        }
    });

    // メニューを追加
    $spModal.find("#SpMenuModalBody").append($spGlobalMenu); 
    $spModal.find("#SpMenuModalBody").append($spSupNavi);
    jQuery("#HeaderArea1").after($spModal);

    $spModal.on("transitionend webkitTransitionEnd", function() {
        if (!$spModal.hasClass("show")) {
            $spModal.hide();
        }
    });
});

// global nav Rental Page
jQuery(function(){
    const targetPath = '/store/pages/rental.aspx';
    const linkCurrentClass = 'Current';
    let rentalTxt;
    let oldCurrentTxt;
    let $thisLink;

    if(location.pathname.indexOf(targetPath) >= 0) {
        jQuery('#SpGlobalNavi').find('a').each(function() {
            $thisLink = jQuery(this);

            if($thisLink.attr('href') === targetPath) {
                rentalTxt = $thisLink.text();
                oldCurrentTxt = $thisLink.closest('li').prev().find('strong').text();
                $thisLink.closest('li').addClass(linkCurrentClass).prev().removeClass(linkCurrentClass).find('a').html(oldCurrentTxt);
                $thisLink.html('<strong>' + rentalTxt + '</strong>');
            }
        });

        // Rental Page error
        if(jQuery('.block-common-alert').length) {
            let getName = jQuery('#lt_global_nav .lt_gnavi_link').text();
            jQuery('.block-common-alert--message').html(getName + 'では現在レンタル商品をお取り扱いしておりません。<br>詳しくは日立の家電品オンラインストア事務局までお問い合わせください。');
        }
    }
});

/* ====================================
	レンタル契約商品一覧
=====================================*/
jQuery(function(){
    if(location.pathname.indexOf('/store/customer/rentalhistory.aspx') >= 0) {
        const targetElemClassName = '.block-regular-purcharse-list--info-other-thick';
        jQuery('.block-regular-purcharse-list--list').each(function() {
            let decisionTxt = jQuery(this).find('.block-regular-purcharse-list--detail-item-list-nolink').text();
            let changeElem = jQuery(this).find('.block-regular-purcharse-list--info-other-thin');

            // txt = 【レンタル・
            if(decisionTxt.indexOf('\u3010\u30EC\u30F3\u30BF\u30EB\u30FB') >= 0) {
                for(let rentalI = 0; rentalI < changeElem.length; changeElem++) {
                    // txt = 契約プラン
                    if(changeElem.eq(rentalI).text() === '\u5951\u7D04\u30D7\u30E9\u30F3') {
                        let textSaving = changeElem.eq(rentalI).next(targetElemClassName).text();
                        // txt = レンタル・
                        changeElem.eq(rentalI).next(targetElemClassName).text('\u30EC\u30F3\u30BF\u30EB\u30FB' + textSaving);
                    }
                }
            }
        });
    }
});

/* ====================================
	レンタルご注文前に
=====================================*/
jQuery(function(){
    if((location.pathname.indexOf('/store/cart/goodsagree.aspx') >= 0) && (jQuery('#js-beforeRentalOrder').length)) {
        const $stickyButton = jQuery('.lt_sticky_button');
        let $this;

        if($stickyButton.length) {
            $stickyButton.find('.lt_sticky_linktxt').each(function() {
                $this = jQuery(this);

                if($this.attr('href') === '/store/pages/guide.aspx') {
                    $this.attr('href', '/store/pages/rental_guide.aspx');
                } else if($this.attr('href') === '/store/pages/faq.aspx') {
                    $this.attr('href', '/store/pages/rental_faq.aspx');
                }
            });
        }
    }
});

/* ====================================
	トップページ本文 会員ランク出し分け
=====================================*/
jQuery(function () {
    const $mvList = jQuery('.js-mv-list');
    const $bnrList = jQuery('.js-bnr-list');
    const $topFeaturesBtn = jQuery('.top-features-list-more-btn');
    const rankGroup = jQuery('[data-rank-group]').data('rank-group');
    const rankCompany = jQuery('[data-rank-company]').data('rank-company');

    applyCommonAction($mvList, rankGroup, rankCompany);
    applyCommonAction($bnrList, rankGroup, rankCompany);

    // MV
    jQuery('.js-mv-list.slick-initialized').slick('unslick');
    $mvList.slick({
        initialSlide: 1,
        dots: true,
        infinite: true,
        speed: 1000,
        easing: 'ease',
        arrows: true,
        autoplay: true,
        slidesToShow: 1,
        prevArrow: '<a class="slick-prev" href="#"><img src="../img/usr/sb/main_slider_prev.png" alt="prev slide"></a>',
        nextArrow: '<a class="slick-next" href="#"><img src="../img/usr/sb/main_slider_next.png" alt="next slide"></a>',
    });
    $mvList.css('opacity', '1');
    jQuery('#top-slider-warp').append(jQuery('#top-slider-warp .slick-dots'));

    // Banner
    $bnrList.find('li').each(function (i) {
        if (i >= 4){
            jQuery(this).addClass('hidden');
        }
    });
    if ($bnrList.find('li').length <= 4) {
        $topFeaturesBtn.remove();
    }
    $topFeaturesBtn.on('click', function () {
        $bnrList.find('li.hidden').slideDown();
        jQuery(this).remove();
    });

    function applyCommonAction($targetList, rankGroup, rankCompany) {
        if ($targetList) {
            // data-rank-group属性値に一致するdata属性を持つ要素を絞り込む
            const $listItems = $targetList.find('li').filter("[data-" + rankGroup + "]");

            // 数値属性の値で昇順に並び替え
            $listItems.sort(function(a, b) {
                return jQuery(a).data(rankGroup) - jQuery(b).data(rankGroup);
            });
            $targetList.empty().append($listItems);

            // data-hide属性がある場合、該当する要素をリストから削除
            $listItems.each(function() {
                const $hideItem = jQuery(this);
                const hideAttr = $hideItem.data('hide');

                if (hideAttr) {
                    const hiddenCompanies = hideAttr.split(' ');
                    if (hiddenCompanies.includes(rankCompany)) {
                        $hideItem.remove();
                    }
                }
            });
        }
    }
});
