var ecblib = ecblib || {};
ecblib.customize = ecblib.customize || {};
ecblib.customize.user = ecblib.customize.user || {};

jQuery(function () {
	var _user = ecblib.customize.user;

	//-- トップページへ戻る初期値
	jQuery('#footer_pagetop').hide();

	//--- スムーススクロール
	jQuery('a[href="#header"], a[href="#toppage"], .block-goods-detail-cart-follow-link a').click(function () {
		var speed = 500;
		var headerH;
		if (jQuery('#header').height() > 200) {
			headerH = (jQuery('#header').height() + jQuery('#header_pickup_banner').height()) + 30;
		} else {
			headerH = jQuery('#header').height();
		};
		var href = jQuery(this).attr("href");
		var target = jQuery(href == "#" || href == "" ? 'html' : href);
		var position = target.offset().top - headerH;
		jQuery('body,html').animate({ scrollTop: position }, speed, 'swing');
		return false;
	});
	
	//ピックアップ
	if(jQuery('.block-category-list--sub').length) {
		jQuery('.block-category-list--sub .block-category-style-d').each(function() {
			jQuery(this).find('.block-category-style-d--item a').tile();
			jQuery(this).find('.block-category-style-d--item h3').tile();
			jQuery(this).find('.block-category-style-d--item').tile();
		});	
	}
	
	//商品詳細の追従カート
    if(jQuery('.page-goods .block-goods-detail-cart-follow').length){
        jQuery(window).on('scroll resize', function () {
            //var scrollHeight = jQuery(document).height();
            //var scrollPosition = jQuery(window).height() + jQuery(window).scrollTop();
			var cartTop = jQuery('.block-add-cart-inner').offset().top;
			var scrollnow = jQuery(window).scrollTop();
            //var footHeight = jQuery('footer').height();

            if (cartTop < scrollnow) {
				jQuery('.block-goods-detail-cart-follow').removeClass('top-hidden');
				if(!jQuery('.block-goods-detail-cart-follow.close').length){
				   jQuery('.block-goods-detail-cart-follow').addClass('show');
				}
            }else if(cartTop > scrollnow){
				if(!jQuery('.block-goods-detail-cart-follow.close').length){
					jQuery('.block-goods-detail-cart-follow').removeClass('show');
				}
				jQuery('.block-goods-detail-cart-follow').addClass('top-hidden');
			}			
        });
		
		jQuery('.block-goods-detail-cart-follow').on('click', function() {
			if(jQuery('.block-goods-detail-cart-follow.close').length){
				jQuery('.block-goods-detail-cart-follow').removeClass('close');
				jQuery('.block-goods-detail-cart-follow').addClass('show');
			}else if(jQuery('.block-goods-detail-cart-follow.show').length){
				jQuery('.block-goods-detail-cart-follow').addClass('close');
				jQuery('.block-goods-detail-cart-follow').removeClass('show');
			}
		});
    }
	
	//ログイン画面分割
	if(jQuery('.page-login').length){
		var now_search_para = location.href;
		if(now_search_para.match(/make_estimate.aspx|estimate.aspx/)){
			jQuery('.block-login--body').addClass('block-login--body-2col');
		}else{
		}
	}
	
	//リサイクル券のチェックボックス処理
	if(jQuery('.page-goods .recycling-ticket').length) {
		jQuery('.recycling-ticket .block-filter input[type=checkbox]').change(function() {
			if(jQuery(this).prop('checked')){
				var goods_page_url = jQuery('.block-goods-detail-cart-follow-cart-btn').children('a').attr('href');
				var checked_on_set = '&' + jQuery(this).attr('name') + '=' + jQuery(this).val(); 
				var recycling_check_set = goods_page_url + checked_on_set;
				jQuery('.block-goods-detail-cart-follow-cart-btn').children('a').attr('href', recycling_check_set);
			}else{
				var goods_page_url = jQuery('.block-goods-detail-cart-follow-cart-btn').children('a').attr('href');
				var checked_on_set = '&' + jQuery(this).attr('name') + '=' + jQuery(this).val();
				var checked_off_set = goods_page_url.replace(checked_on_set, '');
				jQuery('.block-goods-detail-cart-follow-cart-btn').children('a').attr('href', checked_off_set);
			}
		});
	}
	
	//新規会員登録のチェックボックス処理
	if(jQuery('.page-entry #agree_checkbox').length){
		jQuery('.page-entry .block-member-info--items-use-spoofing-protection input[type=checkbox]').change(function(){
			let terms_input_num = jQuery('.page-entry .block-member-info--items-use-spoofing-protection input[type=checkbox]').length;
			let terms_input_checked_num = jQuery('.page-entry .block-member-info--items-use-spoofing-protection input[type=checkbox]:checked').length;
			if(terms_input_num == terms_input_checked_num){
				jQuery('.page-entry .action-buttons .block-member-info--forward').prop('disabled', false);
			}else{
				jQuery('.page-entry .action-buttons .block-member-info--forward').prop('disabled', true);
			}
		});
	}
	
	//同意画面のスクロール処理
	if(jQuery('.page-agree .block-member-terms').length){
		jQuery('.block-member-terms--body').scroll(function(){
			//スクロールを含めた高さ
			var agree_textarea_scroll = jQuery(this).get(0).scrollHeight;

			//表示されている高さ
			var agree_textarea_ht = jQuery(this).get(0).offsetHeight;
			var agree_textarea_move = jQuery(this).scrollTop();
			var agree_scroll_diff = agree_textarea_move + agree_textarea_ht;			
			
			if(agree_textarea_scroll <= agree_scroll_diff){
				jQuery('input.block-member-terms--agree').prop('disabled', false);
			}			
		});
	}
	
	/* ゲスト注文 */
	if(jQuery('.page-estimate .block-order-estimate--agreebody').length){
		jQuery('.block-order-estimate--commit p input[type=checkbox]').change(function(){
		/*
			var agree_order_input_num = jQuery('.block-order-estimate--commit p input[type=checkbox]').length;
			var agree_order_check_num = jQuery('.block-order-estimate--commit p input[type=checkbox]:checked').length;
			console.log(agree_order_input_num);
			console.log(agree_order_check_num);
			if(agree_order_input_num == agree_order_check_num){
				jQuery('input.block-order-estimate--commit-btn').prop('disabled', false);
			}
		*/
			if (_user.checkOrderEstimateCommit()) {
				if (typeof ecblib.order_ajax_id_file_upload === 'undefined') {
					jQuery('input.block-order-estimate--commit-btn').prop('disabled', false);
				} else {
					if ( ecblib.order_ajax_id_file_upload.checkEnableEstimateCommitBtn() ) {
						jQuery('input.block-order-estimate--commit-btn').prop('disabled', false);
					} else {
						jQuery('input.block-order-estimate--commit-btn').prop('disabled', true);
					}
				}
			} else {
				jQuery('input.block-order-estimate--commit-btn').prop('disabled', true);
			}
 		});
	}
	_user.checkOrderEstimateCommit = function checkOrderEstimateCommit(){
		var agree_order_input_num = jQuery('.block-order-estimate--commit p input[type=checkbox]').length;
		var agree_order_check_num = jQuery('.block-order-estimate--commit p input[type=checkbox]:checked').length;
		console.log(agree_order_input_num);
		console.log(agree_order_check_num);
		if(agree_order_input_num == agree_order_check_num){
			return true;
		} else {
			return false;
		}
	}
});



jQuery(window).on('scroll resize', function () {
	var _user = ecblib.customize.user;

	var scrollHeight = jQuery(document).height();
	var scrollPosition = jQuery(window).height() + jQuery(window).scrollTop();
	var footHeight = jQuery('footer').height();

	if (jQuery(this).scrollTop() > 120) {
		jQuery('#footer_pagetop').show();
		jQuery('.block-page-top-follow').fadeIn(300);
	} else if (jQuery(this).scrollTop() < 80) {
		jQuery('#footer_pagetop').hide();
		jQuery('.block-page-top-follow').fadeOut(300);
	}

	if (scrollHeight - scrollPosition <= footHeight) {
		jQuery('#footer_pagetop').css({ 'opacity': '0.2' });
		jQuery('.block-page-top-follow').css({ 'opacity': '0.2' });
	} else {
		jQuery('#footer_pagetop').css({ 'opacity': '1' });
		jQuery('.block-page-top-follow').css({ 'opacity': '1' });
	}

});

window.lazySizesConfig = window.lazySizesConfig || {};
/* lazysizesの設定の変更はここから記述してください
  ・window.lazySizesConfig.expandは、大きな画像を早めに読み込み開始させたい場合などに使用してください
    正の値を指定すると読み込み開始スクロール位置が上に（早く）なります
    負の値を設定すると読み込み開始スクロール位置が下に（遅く）なります
    ※lazySizesConfig.expandを指定しない場合、画像の読み込み状況やブラウザのアイドリング状況に応じて動的に最適化されますが
      指定すると動的な最適化が無効になることに注意してください
*/


/* ============================================================
					load
==============================================================*/
jQuery(window).on('load',function(){
	
	var now_page_url = location.href;
	if(now_page_url.match('history.aspx|customer.aspx|custdest.aspx|withdrawal.aspx|contactlist.aspx')){
		if(jQuery('.block-login .block-login--member').length){
			jQuery('.block-login .block-login--member').css('margin-left', 'auto');
			jQuery('.block-login .block-login--member').css('margin-right', 'auto');
		}
	}
	
	//チェックした製品
	if(jQuery('#block_of_itemhistory').length) {
		jQuery('#block_of_itemhistory .block-thumbnail-h').each(function() {
			jQuery(this).find('dd .block-thumbnail-h--goods-name').tile();
			jQuery(this).find('li').tile();
		});	
	}	
	
	if(jQuery('.page-goods').length) {
		var cartTop = jQuery('.block-add-cart-inner').offset().top - 140;
		var scrollnow = jQuery(window).scrollTop();
		
		if(cartTop > scrollnow){
			if(!jQuery('.block-goods-detail-cart-follow.close').length){
				jQuery('.block-goods-detail-cart-follow').removeClass('show');
			}
			jQuery('.block-goods-detail-cart-follow').addClass('top-hidden');
		}
	}
	
	if(jQuery('.page-category').length) {
		if (jQuery('.page-category .block-top-topic--items li dl dd p')[0]){
			var count1 = 98;
			jQuery('.page-category .block-top-topic--items li dl dd p').each(function() {
				var thisText = jQuery(this).text();
				var textLength = thisText.length;
				if (textLength > count1) {
					var showText = thisText.substring(0, count1);
					var insertText = showText;
					insertText += '<span class="omit">...</span>';
					jQuery(this).html(insertText);
				}
			});
		}
	}

	if(jQuery('.page-top').length) {
		if(jQuery('.block-top-topic').length) {
			jQuery('.top-slider-parts3').parents('#top-slider-warp').prependTo('.pane-contents');
			jQuery('.block-top-topic').prependTo('.pane-contents');
			jQuery('.page-top .block-top-topic').css('opacity', '1');
		}
	}
	
	//4列一覧
	if(jQuery('.page-category .block-thumbnail-t, .page-search .block-thumbnail-t, .page-event .block-thumbnail-t').length) {
		jQuery('.block-thumbnail-t li').each(function() {
			jQuery(this).find('.block-thumbnail-t--goods-name').tile(4);
			jQuery(this).find('.variation-name').tile(4);
			jQuery(this).find('.block-thumbnail-t--price-infos').tile(4);			
		});
	}	
	
	/* 商品一覧デザイン適用　企画へ要確認
	if(jQuery('.page-category .block-category-tree #block_of_filter').length) {
		jQuery('.page-category .block-category-tree').insertBefore('.block-category-freespace4')	
	}
	*/
	
	if(jQuery('.page-category #block_of_filter').length) {
		jQuery('.page-category #block_of_filter').insertBefore('.block-category-freespace4')	
	}
	
	//新規会員登録のチェックボックス処理
	if(jQuery('.page-entry #agree_checkbox').length){
		let terms_input_num = jQuery('.page-entry .block-member-info--items-use-spoofing-protection input[type=checkbox]').length;
		let terms_input_checked_num = jQuery('.page-entry .block-member-info--items-use-spoofing-protection input[type=checkbox]:checked').length;
		if(terms_input_num == terms_input_checked_num){
			jQuery('.page-entry .action-buttons .block-member-info--forward').prop('disabled', false);
		}else{
			jQuery('.page-entry .action-buttons .block-member-info--forward').prop('disabled', true);
		}
	}	
	
	
	
});

jQuery(document).ready(function() {
	/***** Start jQuery Extension */
	/** LT MENU jQuery extension v5
	 * -----
	 * Quick setup:
	 * div.lt_menu_root (*)
	 * 	|- ul
	 * 	|	|- li
	 *	|	|	|- a.lt_open_submenu_btn[href="#sample_1"]{open menu 1} (**)
	 *	|	|	|- div.lt_submenu#sample_id1>p{menu1} (***)
	 * 	|	|		|- a.lt_close_submenu_btn[href="#sample_1"]{close menu 1}
	 *	|	|
	 *	|	|- li
	 *	|		|- a.lt_open_submenu_btn[href="#sample_2"]{open menu 2}
	 *	|		|- div.lt_submenu#sample_2>p{menu2}
	 *	|			|- a.lt_close_submenu_btn[href="#sample_2"]{close menu 2}
	 *	|
	 *	|- div.lt_submenu_loader>.lt_submenu_loader--inner (****)
	 * -----	
     * Remark: *, **, ***, **** class name is important required
	 */
	jQuery.fn.lt_menu = function(options) {
		let self = jQuery(this);
		options = options || {};
		self.options = {};
		self.onOpenMenu = 0;
		self.onOpenSubmenu = 0;
		self.timer = null;
		self.lastMenu = null;
	
		self.Init = function() {
			self.options.openBtn = options.openBtn || '.lt_open_submenu_btn';
			self.options.closeBtn = options.closeBtn || '.lt_close_submenu_btn';
			self.options.rootMenu = options.rootMenu || '.lt_menu_root';
			self.options.submenu = options.submenu || '.lt_submenu';
			self.options.submenuLoader = options.submenuLoader || '.lt_submenu_loader';
			self.options.openTime = options.openTime || 200;
			self.options.closeTime = options.closeTime || 100;
			self.options.currentClass = options.currentClass || 'lt_current';
			self.options.currentSubmenuClass = options.currentSubmenuClass || 'lt_current_submenu';
			self.options.menuAction = options.menuAction || 'click';
			self.options.beforeMenuOpen = options.beforeMenuOpen || null;
			self.options.beforeMenuClose = options.beforeMenuClose || null;
			self.options.afterMenuOpen = options.afterMenuOpen || null;
			self.options.afterMenuClose = options.afterMenuClose || null;
			self.options.debug = options.debug || false;
	
			if (self.options.menuAction == 'click') {
				self.find(self.options.openBtn).unbind();
				self.find(self.options.closeBtn).unbind();
	
				self.find(self.options.openBtn).on('click', function() {
					if (jQuery(this).hasClass(self.options.currentClass)) {
						closeMenu(jQuery(this));
					} 
					else {
						openMenu(jQuery(this));
					}
					return false;
				})
			}
			else 
			{
				self.find(self.options.submenuLoader).on('mouseenter', function() {
					self.onOpenSubmenu = 1;
				}).on('mouseleave', function() {
					self.onOpenSubmenu = 0;
					let lastHandler = jQuery(this);
					if (self.timer != null) clearTimeout(self.timer);
					self.timer = setTimeout(function() {
						if (self.onOpenMenu == 0 && self.onOpenSubmenu == 0) {
							closeMenu(lastHandler);
						}
					}, 100);
				})
	
				self.find(self.options.openBtn).on('mouseenter', function(e) {
					self.onOpenMenu = 1;
					self.onOpenSubmenu = 1;
					let lastHandler = jQuery(this);
					if (self.timer != null) clearTimeout(self.timer);
					self.timer = setTimeout(function() {
						if (self.onOpenMenu == 1 && !lastHandler.hasClass(self.options.currentClass)) {
							openMenu(lastHandler);
						}
					}, 100);
				}).on('mouseleave', function() {
					self.onOpenMenu = 0;
					self.onOpenSubmenu = 0;
					let lastHandler = jQuery(this);
					if (self.timer != null) clearTimeout(self.timer);
					self.timer = setTimeout(function() {
						if (self.onOpenMenu == 0 && self.onOpenSubmenu == 0) {
							closeMenu(lastHandler);
						}
					}, 100);
				})
			}
	
			self.find(self.options.closeBtn).on('click', function() {
				closeMenu(jQuery(this));
				return false;
			})
	
			jQuery('body').on('click', '*', function(e) {
				if (jQuery(e.target).closest(self.options.rootMenu)[0] != self[0]) {
					cancelMenu();
				}
			})
	
			if (self.options.debug) {
			}
	
			return self;
		}
	
		let openMenu = function(openBtnHandler) {
			let root = openBtnHandler.closest(self.options.rootMenu);
			if (!openBtnHandler.data('submenu')) {
				openBtnHandler.data('submenu', openBtnHandler.attr('href'));
			}
			let submenu = jQuery(openBtnHandler.data('submenu'));
			let submenuLoader = root.find(self.options.submenuLoader);
			let submenuLoaderHeader = submenuLoader.find(self.options.submenuLoader+'--header');
			let submenuLoaderInner = submenuLoader.find(self.options.submenuLoader+'--inner');
			let otherBtn = root.find(self.options.openBtn);
			let currentSubmenu = submenuLoaderInner.find(self.options.submenu);
			if (currentSubmenu.length > 0) {
				self.lastMenu = '#'+jQuery(currentSubmenu[0]).attr('id');
			}
	
			otherBtn.removeClass(self.options.currentClass);
			openBtnHandler.addClass(self.options.currentClass);
			root.find(self.options.openBtn+'[data-submenu="'+openBtnHandler.data('submenu')+'"]').addClass(self.options.currentClass);
	
			jQuery.each(otherBtn, function(_, btn) {
				if (jQuery(btn).parent().parent().find(self.options.openBtn+'[data-submenu="'+openBtnHandler.data('submenu')+'"]').length > 0 ) {
					jQuery(btn).addClass(self.options.currentSubmenuClass);
				}
				else {
					jQuery(btn).removeClass(self.options.currentSubmenuClass);
				}
			})
	
			submenuLoaderInner.empty().append(submenu.clone(true)).hide().fadeIn(self.options.openTime);
			let closeBtn = submenuLoaderInner.find(self.options.closeBtn);
			if (closeBtn.length > 0) closeBtn.data('submenu', openBtnHandler.data('submenu'));
			
			if (typeof(self.options.beforeMenuOpen) == 'function') {
				self.options.beforeMenuOpen(openBtnHandler, submenuLoader, root, self);
				if (self.options.debug) {
					console.log('lt_menu: beforeMenuOpen');
				}
			}
	
			// submenuLoader.animate({height:submenuLoaderInner[0].scrollHeight+(submenuLoaderHeader.length>0?submenuLoaderHeader[0].scrollHeight:0)}, self.options.openTime);
			submenuLoader.animate({height:'auto'}, self.options.openTime);
			submenuLoader.css({height:'auto'});
			
			if (self.options.debug) {
				console.log('lt_menu: OpenSubMenu');
			}
	
			if (typeof(self.options.afterMenuOpen) == 'function') {
				self.options.afterMenuOpen(openBtnHandler, submenuLoader, root, self);
				if (self.options.debug) {
					console.log('lt_menu: afterMenuOpen');
				}
			}
		}
	
		let closeMenu = function(closeBtnHandler) {
			let root = closeBtnHandler.closest(self.options.rootMenu);
			if (!closeBtnHandler.data('submenu')) {
				closeBtnHandler.data('submenu', closeBtnHandler.attr('href'));
			}
			let openBtn = root.find(self.options.openBtn+'[data-submenu="'+closeBtnHandler.data('submenu')+'"]');
			let otherBtn = root.find(self.options.openBtn);
			let submenuLoader = root.find(self.options.submenuLoader);
			let submenuLoaderInner = submenuLoader.find(self.options.submenuLoader+'--inner');
			
			otherBtn.removeClass(self.options.currentClass);
			openBtn.removeClass(self.options.currentClass);
	
			jQuery.each(otherBtn, function(_, btn) {
				if (jQuery(btn).parent().parent().find(self.options.openBtn+'[data-submenu="'+closeBtnHandler.data('submenu')+'"]').length > 0 ) {
					jQuery(btn).removeClass(self.options.currentSubmenuClass);
				}
			})
	
			if (typeof(self.options.beforeMenuClose) == 'function') {
				self.options.beforeMenuClose(closeBtnHandler, submenuLoader, root, self);
				if (self.options.debug) {
					console.log('lt_menu: beforeMenuClose');
				}
			}
	
			submenuLoaderInner.fadeOut(self.options.closeTime);
			submenuLoader.animate({height:0}, self.options.closeTime);
	
			if (self.options.debug) {
				console.log('lt_menu: CloseSubMenu');
			}
			
			if (typeof(self.options.afterMenuClose) == 'function') {
				self.options.afterMenuClose(closeBtnHandler, submenuLoader, root, self);
				if (self.options.debug) {
					console.log('lt_menu: afterMenuClose');
				}
			}
		}
	
		let cancelMenu = function() {
			let root = self;
			let openBtn = root.find(self.options.openBtn);
			let submenuLoader = root.find(self.options.submenuLoader);
			let submenuLoaderInner = submenuLoader.find(self.options.submenuLoader+'--inner');
			
			openBtn.removeClass(self.options.currentClass);
	
			submenuLoader.animate({height:0}, self.options.closeTime);
			submenuLoaderInner.empty();
		}
	
		self.UpdateMenuHeight = function() {
			let root = self;
			let submenuLoader = root.find(self.options.submenuLoader);
			// let submenuLoaderHeader = submenuLoader.find(self.options.submenuLoader+'--header');
			// let submenuLoaderInner = submenuLoader.find(self.options.submenuLoader+'--inner');
			// submenuLoader.css({height:submenuLoaderInner[0].scrollHeight+(submenuLoaderHeader.length>0?submenuLoaderHeader[0].scrollHeight:0)});
			submenuLoader.css({height:'auto'});
		}
	
		return self.Init();
	}

	/** LT MODAL jQuery extension v2
	 * -----
	 * Quick setup:
	 * jQuery('body').lt_modal();
	 * a.lt_open_modal_btn[href="#content_1"] (*)
	 * a.lt_open_ytb_modal_btn[href="ytb_id_1"] (**)
	 * -----
     * Remark: *, ** class name is important required
	 */
	jQuery.fn.lt_modal = function(options) {
		let self = jQuery(this);
		let root = jQuery('body');
		let modal = root.find('.lt_modal');
		options = options || {};
		self.options = {};

		self.Init = function() {
			if (modal.length <= 0) {
				modal = jQuery('<div class="lt_modal"><div class="lt_modal--dialog"><div class="lt_modal--content"><div class="lt_dialog"><div class="lt_dialog--header"><a class="lt_close_modal_btn" href="#">Close</a></div><div class="lt_dialog--inner"></div></div></div></div></div>');
				root.prepend(modal);
			}
			
			self.options.openBtn = options.openBtn || '.lt_open_modal_btn';
			self.options.openYtbBtn = options.openYtbBtn || '.lt_open_ytb_modal_btn';
			self.options.closeBtn = options.closeBtn || '.lt_close_modal_btn';
			self.options.openClass = options.openClass || 'lt_modal_open';
			self.options.openYtbClass = options.openYtbClass || 'lt_ytb_modal_open';
			self.options.openTime = options.openTime || 300;
			self.options.closeTime = options.closeTime || 200;
			self.options.beforeModalOpen = options.beforeModalOpen || null;
			self.options.beforeModalClose = options.beforeModalClose || null;
			self.options.afterModalOpen = options.afterModalOpen || null;
			self.options.afterModalClose = options.afterModalClose || null;
			self.options.debug = options.debug || false;
	
			root.find(self.options.openBtn).unbind();
			root.find(self.options.openYtbBtn).unbind();
			root.find(self.options.closeBtn).unbind();

			self.find(self.options.openBtn).on('click', function() {
				let source = jQuery(jQuery(this).attr('href'));
				self.OpenModal(source.clone(true), jQuery(this));
				return false;
			})

			self.find(self.options.openYtbBtn).on('click', function() {
				self.OpenYtbModal(jQuery(this).attr('href'), jQuery(this));
				return false;
			})

			jQuery(window).on('resize', function() {
				self.UpdateYtbRatio();
			})

			self.find(self.options.closeBtn).on('click', function() {
				self.CloseModal(jQuery(this));
				return false;
			})
			
			modal.on('click', function(e) { 
				if (jQuery(e.target).hasClass('lt_modal')) { 
				//if (jQuery(e.target) == self) { 
					self.CloseModal(); 
				} 
				return false; 
			})

			modal.css({display: 'none'});

			if (self.options.debug) {
				console.log('lt_modal: Init complete');
			}

			return self;
		}

		self.OpenModal = function(source, openBtnHandler) {
			let dialog = root.find('.lt_dialog');
			let dialogInner = dialog.find('.lt_dialog--inner');
			dialogInner.empty();
			dialog.css({'max-width': '1000px'});
			dialogInner.append(source);
			modal.addClass(self.options.openClass);
			modal.fadeIn(self.options.openTime);
			root.addClass(self.options.openClass);

			if (self.options.debug) {
				console.log('lt_modal: OpenModal');
			}
		}

		self.OpenYtbModal = function(ytbId, openBtnHandler) {
			let dialog = root.find('.lt_dialog');
			let dialogInner = dialog.find('.lt_dialog--inner');
			let source = jQuery('<div class="lt_video_frame--outer"><iframe src="" id="lt_video_frame" class="lt_video_frame" allowscriptaccess="always" allow="autoplay"></iframe></div>');
			source.find('#lt_video_frame').attr('src', 'https://www.youtube.com/embed/'+ytbId+'?autoplay=1&amp;modestbranding=1&amp;showinfo=0');
			dialogInner.empty();
			dialog.css({'max-width': '1000px', width: 'auto'});
			dialogInner.append(source);
			modal.addClass(self.options.openClass);
			modal.addClass(self.options.openYtbClass);
			modal.fadeIn(self.options.openTime);
			root.addClass(self.options.openClass);
			root.addClass(self.options.openYtbClass);
			self.UpdateYtbRatio();

			if (self.options.debug) {
				console.log('lt_modal: OpenYtbModal');
			}
		}

		self.CloseModal = function() {
			let dialog = root.find('.lt_dialog');
			let dialogInner = dialog.find('.lt_dialog--inner');
			modal.fadeOut(self.options.closeTime);
			modal.removeClass(self.options.openClass);
			modal.removeClass(self.options.openYtbClass);
			root.removeClass(self.options.openClass);
			root.removeClass(self.options.openYtbClass);
			setTimeout(function() {
				dialogInner.empty();
			}, 300);

			if (self.options.debug) {
				console.log('lt_modal: CloseModal');
			}
		}

		self.UpdateYtbRatio = function() {
			let dialog = root.find('.lt_dialog');
			let ytbFrame = dialog.find('#lt_video_frame');
			let ytbFrameRatio = {
				1000:563,
				764:430,
				500:281,
				350:197,
				300:150,
			};
			let wW = jQuery(window).width();
			let fW = 764;
			if (wW > 1024) {
				fW = 1000;
			}
			else if (fW > 764 && wW <= 1024) {
				fW = 764;
			}
			else if (fW > 500 && wW <= 764) {
				fW = 500;
			}
			else if (fW > 350 && wW <= 500) {
				fW = 350;
			}
			else if (fW <= 350) {
				fW = 300;
			}
			let fH = ytbFrameRatio[fW];
			if (ytbFrame.length > 0) {
				if (jQuery(window).width() > 764) {
					ytbFrame.attr('height', fH);
				} else {
					ytbFrame.removeAttr('height');
				}
				ytbFrame.attr('width', fW);
				// Center window dialog
				dialog.css({top: (jQuery(window).innerHeight()/2)-(dialog.find('.lt_dialog--inner').height()/2)-dialog.find('.lt_dialog--header').height(), position: 'relative'});
			}
		}

		return self.Init();
	}
	/***** End jQuery Extension */

	/***** Start global function */
	/* modal init */
	let lt_modal = jQuery('body').lt_modal({debug: false});

	/***** End global function */

	/***** Start .page-category function */
	/* .block-category-list--goods */
	let category_list_goods_header = jQuery('<div class="block-category-list--goods-header"></div>');
	jQuery('.page-category .block-category-list--goods').prepend(category_list_goods_header);

	/* create select 2 from lt_menu extension */
	category_list_goods_header.append(jQuery('.page-category .block-category-list--goods .block-goods-list--sort-order-items'));
	let goods_select_2 = jQuery('<div class="lt-menu-root lt-select" id="goods_select_2"><div><a href="#goods_select_2_menu" data-submenu="#goods_select_2_menu" class="lt-open-submenu-btn"><span></span></a></div><div id="goods_select_2_menu" class="lt-submenu"></div><div class="lt-submenu-loader"><div class="lt-submenu-loader--inner"></div></div></div>');
	let goods_select_2_menu = goods_select_2.find("#goods_select_2_menu");
	jQuery('.page-category .block-goods-list--sort-order-items dd').each(function(i,v) {
		goods_select_2_menu.append(jQuery(v).addClass('goods_select_2_'+i));
	})
	goods_select_2.find('.lt-open-submenu-btn').html(jQuery('<span></span>').append(goods_select_2_menu.find('dd.active').clone(true).removeClass('lt-close-submenu-btn').unbind()));
	goods_select_2_menu.find('dd').addClass('lt-close-submenu-btn');
	jQuery('.page-category .block-goods-list--sort-order-items').append(goods_select_2);
	goods_select_2.lt_menu({
		menuAction: 'click', 
		rootMenu: '.lt-menu-root',
		openBtn: '.lt-open-submenu-btn',
		closeBtn: '.lt-close-submenu-btn',
		submenu: '.lt-submenu',
		submenuLoader: '.lt-submenu-loader',
		currentClass: 'lt-current',
		currentSubmenuClass: 'lt-current-submenu',
		beforeMenuClose: function(btnHandler, submenuLoader, root, self) {
			let selected = btnHandler.clone(true).removeClass('lt-close-submenu-btn').unbind();
			if (!btnHandler.hasClass('lt-open-submenu-btn')) {
				self.find('.lt-open-submenu-btn').html(jQuery('<span></span>').append(selected));
			}
			if (selected.find('a').attr('href')) {
				window.location.replace(selected.find('a').attr('href'));
			}
		}
	});

	/* create select 1 from lt_menu extension */
	category_list_goods_header.append(jQuery('.page-category .block-category-list--goods .block-goods-list--display-style-items'));
	let goods_select_1 = jQuery('<div class="lt-menu-root lt-select" id="goods_select_1"><div><a href="#goods_select_1_menu" data-submenu="#goods_select_1_menu" class="lt-open-submenu-btn"><span></span></a></div><div id="goods_select_1_menu" class="lt-submenu"></div><div class="lt-submenu-loader"><div class="lt-submenu-loader--inner"></div></div></div>');
	let goods_select_1_menu = goods_select_1.find("#goods_select_1_menu");
	jQuery('.page-category .block-goods-list--display-style-items dd').each(function(i,v) {
		goods_select_1_menu.append(jQuery(v).addClass('goods_select_1_'+i));
	})
	goods_select_1.find('.lt-open-submenu-btn').html(jQuery('<span></span>').append(goods_select_1_menu.find('dd.active').clone(true).removeClass('lt-close-submenu-btn').unbind()));
	goods_select_1_menu.find('dd').addClass('lt-close-submenu-btn');
	jQuery('.page-category .block-goods-list--display-style-items').append(goods_select_1);
	goods_select_1.lt_menu({
		menuAction: 'click', 
		rootMenu: '.lt-menu-root',
		openBtn: '.lt-open-submenu-btn',
		closeBtn: '.lt-close-submenu-btn',
		submenu: '.lt-submenu',
		submenuLoader: '.lt-submenu-loader',
		currentClass: 'lt-current',
		currentSubmenuClass: 'lt-current-submenu',
		beforeMenuClose: function(btnHandler, submenuLoader, root, self) {
			let selected = btnHandler.clone(true).removeClass('lt-close-submenu-btn').unbind();
			if (!btnHandler.hasClass('lt-open-submenu-btn')) {
				self.find('.lt-open-submenu-btn').html(jQuery('<span></span>').append(selected));
			}
			if (selected.find('a').attr('href')) {
				window.location.replace(selected.find('a').attr('href'));
			}
		}
	});

	/* pager count */
	category_list_goods_header.append(jQuery('.page-category .block-category-list--goods .block-goods-list--pager-top'));
	
	/* destroy sclick */
	//jQuery('.page-category .block-thumbnail-t li').slick('unslick');

	/* change btn construct */
	jQuery('.page-category .block-goods-list-d--add-cart .block-list-add-cart-btn').each(function(i, v) {
		jQuery(v).html('<span>'+jQuery(v).text()+'</span>')
	})

	/* change d template */
	jQuery('.page-category .block-goods-list-d--items li').each(function(i, v) {
		let self = jQuery(v).find('.block-goods-list-d--item-description');
		self.append(self.find('.block-icon'));
		self.append(self.find('.block-model-num'));
		self.append(self.find('.block-goods-list-d--goods-name'));
		self.append(self.find('.block-goods-list-d--goods-code'));
		self.append(self.find('.block-goods-list-d--comment'));
		self.append(self.find('.block-goods-list-d--goods-comment'));
		self.append(self.find('.block-goods-list-d--item-details'));
	})
	/***** End .page-category function */


	/***** Start .page-goods function */
	if(jQuery('.page-goods #block_of_recommend').length){
		let block_of_recommend_item_height = 0;
		var block_of_recommend_num = jQuery('.block-goods-detail-j .block-goods-detail-j--items li dl').length;
		console.log(block_of_recommend_num);
		if(block_of_recommend_num > 4){
			jQuery('.page-goods #block_of_recommend li').slick({
				slidesToShow: 3,
				dots: false,
				pauseOnHover: true,
				infinite: true,
				pauseOnHover: true,
				speed: 1000,
				easing: 'ease',
				arrows: true,
				autoplay: true,
				centerMode: true,
				variableWidth: true,
				prevArrow: '<a class="slick-prev" href="#"><img src="../../../img/usr/pc/main_slider_prev.png" alt="prev slide"></a>',
				nextArrow: '<a class="slick-next" href="#"><img src="../../../img/usr/pc/main_slider_next.png" alt="next slide"></a>',
			})
			.find('.block-goods-detail-j--goods').each(function(i, v) {
				block_of_recommend_item_height = Math.max(block_of_recommend_item_height, jQuery(v).height());
			})
			.css({height: block_of_recommend_item_height});
		}
	}

	/* リサイクル券 */
	jQuery('.page-goods .recycling-ticket--header').addClass('lt-open').on('click', function() {
		let self = jQuery(this);
		let target = self.closest('.recycling-ticket');

		if (self.hasClass('lt-open')) {
			self.removeClass('lt-open');
			target.removeClass('lt-open');
			target.animate({height: self.height() + 40}, 200);
		} 
		else {
			self.addClass('lt-open');
			target.addClass('lt-open');
			target.animate({height: target[0].scrollHeight + 2}, 300); //2 = border width top+ bottom
		}
	})

	/* 詳細情報 */
	jQuery('.page-goods .goods-detail-desc-ttl').addClass('lt-open').on('click', function() {
		let self = jQuery(this);
		let target = jQuery('.page-goods .goods-detail-desc-cont');

		if (self.hasClass('lt-open')) {
			self.removeClass('lt-open');
			target.removeClass('lt-open');
			target.animate({height: 0}, 200);
		} 
		else {
			self.addClass('lt-open');
			target.addClass('lt-open');
			target.animate({height: target[0].scrollHeight + 2}, 300);
		}
	})

	/* Instagram */
	jQuery('.page-goods .block-goods-comment3 ul').slick({
		slidesToShow: 3,
		dots: false,
		pauseOnHover: true,
		infinite: true,
		pauseOnHover: true,
		speed: 1000,
		easing: 'ease',
		arrows: true,
		autoplay: true,
		centerMode: true,
		variableWidth: true,
		prevArrow: '<a class="slick-prev" href="#"><img src="../../../img/usr/pc/main_slider_prev.png" alt="prev slide"></a>',
		nextArrow: '<a class="slick-next" href="#"><img src="../../../img/usr/pc/main_slider_next.png" alt="next slide"></a>',
	});
	
	/* 商品詳細ページ */
	if(jQuery('.page-goods .goods-movie-slider').length){
		var goods_movie_slider_num = jQuery('.block-goods-comment4--body > a').length;
		if(goods_movie_slider_num > 1){
			jQuery('.page-goods .goods-movie-slider').slick({
				slidesToShow: 1,
				dots: false,
				pauseOnHover: true,
				infinite: true,
				pauseOnHover: true,
				speed: 1000,
				autoplaySpeed: 4500,
				easing: 'ease',
				arrows: true,
				autoplay: true,
				//centerMode: true,
				variableWidth: true,
				prevArrow: '<a class="slick-prev" href="#"><img src="../../../img/usr/pc/main_slider_prev.png" alt="prev slide"></a>',
				nextArrow: '<a class="slick-next" href="#"><img src="../../../img/usr/pc/main_slider_next.png" alt="next slide"></a>',
			});
		}else{
			jQuery('.page-goods .block-goods-comment4--body.goods-movie-slider').css('opacity', '1');
		}
	}
	/***** End .page-goods function */


	/***** Start .page-event function */
	/* filter block header */
	let pEvent_goods_header = jQuery('<div class="block-event-list--goods-header"></div>');
	jQuery('.page-event .block-event-page--goods').prepend(pEvent_goods_header);

	/* create select 1 from lt_menu extension */
	pEvent_goods_header.append(jQuery('.page-event .block-goods-list--sort-order-items'));
	let pEvent_goods_select_1 = jQuery('<div class="lt-menu-root lt-select" id="goods_select_1"><div><a href="#goods_select_1_menu" data-submenu="#goods_select_1_menu" class="lt-open-submenu-btn"><span></span></a></div><div id="goods_select_1_menu" class="lt-submenu"></div><div class="lt-submenu-loader"><div class="lt-submenu-loader--inner"></div></div></div>');
	let pEvent_goods_select_1_menu = pEvent_goods_select_1.find("#goods_select_1_menu");
	jQuery('.page-event .block-goods-list--display-style-items dd').each(function(i,v) {
		pEvent_goods_select_1_menu.append(jQuery(v).addClass('goods_select_1_'+i));
	})
	pEvent_goods_select_1.find('.lt-open-submenu-btn').html(jQuery('<span></span>').append(pEvent_goods_select_1_menu.find('dd.active').clone(true).removeClass('lt-close-submenu-btn').unbind()));
	pEvent_goods_select_1_menu.find('dd').addClass('lt-close-submenu-btn');
	jQuery('.page-event .block-goods-list--display-style-items').append(pEvent_goods_select_1);
	pEvent_goods_select_1.lt_menu({
		menuAction: 'click', 
		rootMenu: '.lt-menu-root',
		openBtn: '.lt-open-submenu-btn',
		closeBtn: '.lt-close-submenu-btn',
		submenu: '.lt-submenu',
		submenuLoader: '.lt-submenu-loader',
		currentClass: 'lt-current',
		currentSubmenuClass: 'lt-current-submenu',
		beforeMenuClose: function(btnHandler, submenuLoader, root, self) {
			let selected = btnHandler.clone(true).removeClass('lt-close-submenu-btn').unbind();
			if (!btnHandler.hasClass('lt-open-submenu-btn')) {
				self.find('.lt-open-submenu-btn').html(jQuery('<span></span>').append(selected));
			}
			if (selected.find('a').attr('href')) {
				window.location.replace(selected.find('a').attr('href'));
			}
		}
	});

	/* create select 2 from lt_menu extension */
	pEvent_goods_header.append(jQuery('.page-event .block-goods-list--display-style-items'));
	let pEvent_goods_select_2 = jQuery('<div class="lt-menu-root lt-select" id="goods_select_2"><div><a href="#goods_select_2_menu" data-submenu="#goods_select_2_menu" class="lt-open-submenu-btn"><span></span></a></div><div id="goods_select_2_menu" class="lt-submenu"></div><div class="lt-submenu-loader"><div class="lt-submenu-loader--inner"></div></div></div>');
	let pEvent_goods_select_2_menu = pEvent_goods_select_2.find("#goods_select_2_menu");
	jQuery('.page-event .block-goods-list--sort-order-items dd').each(function(i,v) {
		pEvent_goods_select_2_menu.append(jQuery(v).addClass('goods_select_2_'+i));
	})
	pEvent_goods_select_2.find('.lt-open-submenu-btn').html(jQuery('<span></span>').append(pEvent_goods_select_2_menu.find('dd.active').clone(true).removeClass('lt-close-submenu-btn').unbind()));
	pEvent_goods_select_2_menu.find('dd').addClass('lt-close-submenu-btn');
	jQuery('.page-event .block-goods-list--sort-order-items').append(pEvent_goods_select_2);
	pEvent_goods_select_2.lt_menu({
		menuAction: 'click', 
		rootMenu: '.lt-menu-root',
		openBtn: '.lt-open-submenu-btn',
		closeBtn: '.lt-close-submenu-btn',
		submenu: '.lt-submenu',
		submenuLoader: '.lt-submenu-loader',
		currentClass: 'lt-current',
		currentSubmenuClass: 'lt-current-submenu',
		beforeMenuClose: function(btnHandler, submenuLoader, root, self) {
			let selected = btnHandler.clone(true).removeClass('lt-close-submenu-btn').unbind();
			if (!btnHandler.hasClass('lt-open-submenu-btn')) {
				self.find('.lt-open-submenu-btn').html(jQuery('<span></span>').append(selected));
			}
			if (selected.find('a').attr('href')) {
				window.location.replace(selected.find('a').attr('href'));
			}
		}
	});
	
	/* pager count */
	pEvent_goods_header.append(jQuery('.page-event .block-event-page--goods .block-goods-list--pager-top'));
	/***** End .page-event function */

	/***** Start .page-search function */
	/* filter block header */
	let pSearch_goods_header = jQuery('<div class="block-search-list--goods-header"></div>');
	pSearch_goods_header.insertBefore(jQuery('.page-search .block-search-goods .block-goods-list-d, .page-search .block-search-goods .block-thumbnail-t'));

	/* create select 1 from lt_menu extension */
	pSearch_goods_header.append(jQuery('.page-search .block-goods-list--sort-order-items'));
	let pSearch_goods_select_1 = jQuery('<div class="lt-menu-root lt-select" id="goods_select_1"><div><a href="#goods_select_1_menu" data-submenu="#goods_select_1_menu" class="lt-open-submenu-btn"><span></span></a></div><div id="goods_select_1_menu" class="lt-submenu"></div><div class="lt-submenu-loader"><div class="lt-submenu-loader--inner"></div></div></div>');
	let pSearch_goods_select_1_menu = pSearch_goods_select_1.find("#goods_select_1_menu");
	jQuery('.page-search .block-goods-list--display-style-items dd').each(function(i,v) {
		pSearch_goods_select_1_menu.append(jQuery(v).addClass('goods_select_1_'+i));
	})
	pSearch_goods_select_1.find('.lt-open-submenu-btn').html(jQuery('<span></span>').append(pSearch_goods_select_1_menu.find('dd.active').clone(true).removeClass('lt-close-submenu-btn').unbind()));
	pSearch_goods_select_1_menu.find('dd').addClass('lt-close-submenu-btn');
	jQuery('.page-search .block-goods-list--display-style-items').append(pSearch_goods_select_1);
	pSearch_goods_select_1.lt_menu({
		menuAction: 'click', 
		rootMenu: '.lt-menu-root',
		openBtn: '.lt-open-submenu-btn',
		closeBtn: '.lt-close-submenu-btn',
		submenu: '.lt-submenu',
		submenuLoader: '.lt-submenu-loader',
		currentClass: 'lt-current',
		currentSubmenuClass: 'lt-current-submenu',
		beforeMenuClose: function(btnHandler, submenuLoader, root, self) {
			let selected = btnHandler.clone(true).removeClass('lt-close-submenu-btn').unbind();
			if (!btnHandler.hasClass('lt-open-submenu-btn')) {
				self.find('.lt-open-submenu-btn').html(jQuery('<span></span>').append(selected));
			}
			if (selected.find('a').attr('href')) {
				window.location.replace(selected.find('a').attr('href'));
			}
		}
	});

	/* create select 2 from lt_menu extension */
	pSearch_goods_header.append(jQuery('.page-search .block-goods-list--display-style-items'));
	let pSearch_goods_select_2 = jQuery('<div class="lt-menu-root lt-select" id="goods_select_2"><div><a href="#goods_select_2_menu" data-submenu="#goods_select_2_menu" class="lt-open-submenu-btn"><span></span></a></div><div id="goods_select_2_menu" class="lt-submenu"></div><div class="lt-submenu-loader"><div class="lt-submenu-loader--inner"></div></div></div>');
	let pSearch_goods_select_2_menu = pSearch_goods_select_2.find("#goods_select_2_menu");
	jQuery('.page-search .block-goods-list--sort-order-items dd').each(function(i,v) {
		pSearch_goods_select_2_menu.append(jQuery(v).addClass('goods_select_2_'+i));
	})
	pSearch_goods_select_2.find('.lt-open-submenu-btn').html(jQuery('<span></span>').append(pSearch_goods_select_2_menu.find('dd.active').clone(true).removeClass('lt-close-submenu-btn').unbind()));
	pSearch_goods_select_2_menu.find('dd').addClass('lt-close-submenu-btn');
	jQuery('.page-search .block-goods-list--sort-order-items').append(pSearch_goods_select_2);
	pSearch_goods_select_2.lt_menu({
		menuAction: 'click', 
		rootMenu: '.lt-menu-root',
		openBtn: '.lt-open-submenu-btn',
		closeBtn: '.lt-close-submenu-btn',
		submenu: '.lt-submenu',
		submenuLoader: '.lt-submenu-loader',
		currentClass: 'lt-current',
		currentSubmenuClass: 'lt-current-submenu',
		beforeMenuClose: function(btnHandler, submenuLoader, root, self) {
			let selected = btnHandler.clone(true).removeClass('lt-close-submenu-btn').unbind();
			if (!btnHandler.hasClass('lt-open-submenu-btn')) {
				self.find('.lt-open-submenu-btn').html(jQuery('<span></span>').append(selected));
			}
			if (selected.find('a').attr('href')) {
				window.location.replace(selected.find('a').attr('href'));
			}
		}
	});
	
	/* pager count */
	pSearch_goods_header.append(jQuery('.page-search .block-search-goods .block-goods-list--pager-top'));
	/***** End .page-search function */
})

/* オンライン接客バナー */
jQuery(function(){
	var $targetCloseBtn = jQuery('#js-online_bnr_btn');

	if ($targetCloseBtn.length <= 0) {
		return;
	}

	$targetCloseBtn.on('click', function () {
		jQuery('#js-online_bnr').fadeOut();
	});
});

/* アウトレット在庫 */
jQuery(function(){
	if(document.URL.match(/outlet/)) {
		var numKeep = jQuery('.goods-detail-description.block-goods-stock dd').text();
		jQuery('.goods-detail-description.block-goods-stock dt').html('\u6B8B\u308A\u53F0\u6570'); //残り台数
		jQuery('.goods-detail-description.block-goods-stock dd').text('\u3042\u3068' + numKeep); //あと
		jQuery('.goods-detail-description.block-goods-stock').addClass('outlet');
	}
});
/* ====================================
	配送日時連動
=====================================*/
jQuery(function () {
	var $dayElem = jQuery('.block-order-estimate--goods-spec-dt_parts');
	var $timeZoneElem = jQuery('.block-order-estimate--goods-spec-time_parts');
	var ind;
	var dayVal;
	var timeZoneVal;

	// 配送希望日
	if ($dayElem.length >= 2) {
		for (ind = 1; ind < $dayElem.length; ind++) {
			$dayElem.eq(ind).find('select').attr('readonly', true).css({'pointer-events': 'none', 'opacity': '.6'});
		}

		$dayElem.on('change', function () {
			dayVal = jQuery(this).find('option:selected').val();

			for (ind = 1; ind < $dayElem.length; ind++) {
				$dayElem.eq(ind).find('select option').each(function () {
					if (dayVal === jQuery(this).val()) {
						jQuery(this).prop('selected', true);
					}
				});
			}
		});
	}

	// 配送希望時間帯
	if ($timeZoneElem.length >= 2) {
		for (ind = 1; ind < $timeZoneElem.length; ind++) {
			$timeZoneElem.eq(ind).find('select').attr('readonly', true).css({'pointer-events': 'none', 'opacity': '.6'});
		}

		$timeZoneElem.on('change', function () {
			timeZoneVal = jQuery(this).find('option:selected').val();

			for (ind = 1; ind < $timeZoneElem.length; ind++) {
				$timeZoneElem.eq(ind).find('select option').each(function () {
					if (timeZoneVal === jQuery(this).val()) {
						jQuery(this).prop('selected', true);
					}
				});
			}
		});
	}
});

jQuery(function () {
	var ua = window.navigator.userAgent.toLowerCase();
	if(ua.indexOf('ipad') > -1 
	|| ua.indexOf('macintosh') > -1 && 'ontouchend' in document) {
		jQuery('body').addClass('is-iPad');
	}
});

// 商品詳細：社販バナー
// jQuery(function () {
	
// 	var $targetElem = jQuery('#block-company-sales-area');
// 	var $targetParentElem = jQuery('.pane-goods-left-side');
// 	var $targetParentComment4 = $targetParentElem.find('.block-goods-comment4');
// 	var $txtCheckElem = jQuery('#header .block-header-logo--link');
// 	var txtCheck = $txtCheckElem.text();

// 	// txt = 社販
// 	if (txtCheck.indexOf('\u793E\u8CA9') >= 0) {
// 		$targetElem.addClass('is-active');

// 		if($targetParentComment4.length === 1) {
// 			$targetParentComment4.before($targetElem);
// 		} else {
// 			$targetParentElem.append($targetElem);
// 		}
		
// 		//ログイン画面の文言（社販）
// 		if(jQuery('.page-login').length) {
// 			jQuery('.block-login-company-sales').show();
// 		}
// 	}
// });

//20220414 社販対応変更
jQuery(function () {

	const productCode = ['g184113', 'g184114', 'g184876', 'g184877', 'g184112', 'g184874', 'g184875', 'g184878', 'g184115', 'g184116', 'g184879', 'g184880', 'g184883', 'g184884', 'g184881', 'g184882', 'g183457', 'g183458', 'g183459', 'g183460', 'g183847', 'g183848', 'g183849', 'g183850', 'g184871', 'g184872', 'g184873', 'g183839', 'g183840', 'g183841', 'g183842', 'g183843', 'g183844', 'g183845', 'g183846', 'g184526', 'g184527', 'g183838', 'g182181', 'g182182', 'g182184outlet', 'g181336outlet', 'g181340outlet', 'g181341outlet', 'g181416outlet', 'g181992outlet', 'g184112monitor', 'g184874monitor', 'g184875monitor', 'g184881monitor', 'g184882monitor', 'g182667gentei', 'g182668gentei', 'g182663gentei', 'g182664gentei', 'g183461gentei', 'g183462gentei'];
	const path = location.pathname.split('/')[3];
	
	var $targetElem = jQuery('#block-company-sales-area');
	var $targetParentElem = jQuery('.pane-goods-left-side');
	var $targetParentComment4 = $targetParentElem.find('.block-goods-comment4');
	var $txtCheckElem = jQuery('#header .block-header-logo--link');
	var txtCheck = $txtCheckElem.text();

	// txt = 社販
	if (txtCheck.indexOf('\u793E\u8CA9') >= 0 && productCode.indexOf(path) >= 0) {
		$targetElem.addClass('is-active');

		if($targetParentComment4.length === 1) {
			$targetParentComment4.before($targetElem);
		} else {
			$targetParentElem.append($targetElem);
		}
		
		//ログイン画面の文言（社販）
		if(jQuery('.page-login').length) {
			jQuery('.block-login-company-sales').show();
		}
	}
});

// 積水ハウス：IHCH非表示
jQuery(function() {
	var $targetElem = jQuery('.js-ihch-hide');
	var $txtCheckElem = jQuery('#header .block-header-logo--link');
	var txtCheck = $txtCheckElem.text();

	// txt = シャーメゾンライフCLUB様
	if (txtCheck.indexOf('\u30B7\u30E3\u30FC\u30E1\u30BE\u30F3\u30E9\u30A4\u30D5\u0043\u004C\u0055\u0042\u69D8') >= 0) {
		$targetElem.remove();
       	// txt = すまいーだPLUS様
	}else if(txtCheck.indexOf('\u3059\u307e\u3044\u30fc\u3060PLUS\u4f1a\u54e1\u69d8') >= 0) {
		$targetElem.remove();
	}
});

// すまいーだ：LED非表示
jQuery(function() {
	var $targetElem = jQuery('.js-led-hide');
	var $txtCheckElem = jQuery('#header .block-header-logo--link');
	var txtCheck = $txtCheckElem.text();

	// txt = すまいーだPLUS様
	if(txtCheck.indexOf('\u3059\u307e\u3044\u30fc\u3060PLUS\u4f1a\u54e1\u69d8') >= 0) {
		$targetElem.remove();
	}
});

/* ストア名称（Unicode変換） */
jQuery(function() {
	var $storeTxtNameElem = jQuery('#header .block-header-logo--link');
	var storeTxtNameCheck = $storeTxtNameElem.text();
	if(storeTxtNameCheck.indexOf('\u793e\u8ca9') >= 0) {
		//社販
		$storeTxtNameElem.addClass('block-header-logo--link-company-sales');
	}else if(storeTxtNameCheck.indexOf('\u65E5\u7ACB\u95A2\u9023\u4F1A\u793E\u004F\u0042\u30FB\u004F\u0047') >= 0){
		//日立関連会社OB・OG
		$storeTxtNameElem.addClass('block-header-logo--link-obog');	
	}else if(storeTxtNameCheck.indexOf('\u5927\u585a\u30b0\u30eb\u30fc\u30d7\u793e\u54e1\u69d8') >= 0){
		//大塚グループ社員様
		$storeTxtNameElem.addClass('block-header-logo--link-otsuka');	
	}else if(storeTxtNameCheck.indexOf('\u30b7\u30e3\u30fc\u30e1\u30be\u30f3\u30e9\u30a4\u30d5CLUB\u69d8') >= 0){
		//シャーメゾンライフCLUB様
		$storeTxtNameElem.addClass('block-header-logo--link-sekisui');	
	}else if(storeTxtNameCheck.indexOf('\u65e5\u7acb\u88fd\u54c1\u3054\u611b\u9867\u7d99\u7d9a\u304a\u5ba2\u69d8\u30b5\u30fc\u30d3\u30b9') >= 0){
		//日立製品ご愛顧継続お客様サービス
		$storeTxtNameElem.addClass('block-header-logo--link-sales-service');		
	}else if(storeTxtNameCheck.indexOf('\u30ea\u30b3\u30fc\u30b0\u30eb\u30fc\u30d7\u793e\u54e1\u69d8') >= 0){
		//リコーグループ社員様
		$storeTxtNameElem.addClass('block-header-logo--link-ricoh');		
	}else if(storeTxtNameCheck.indexOf('\u3059\u307e\u3044\u30fc\u3060PLUS\u4f1a\u54e1\u69d8') >= 0){
		//すまいーだPLUS会員様
		$storeTxtNameElem.addClass('block-header-logo--link-iid-hd');	
	}else if(storeTxtNameCheck.indexOf('SCSK\u793e\u54e1\u69d8') >= 0){
		//SCSK社員様
		$storeTxtNameElem.addClass('block-header-logo--link-scsk');
	}else if(storeTxtNameCheck.indexOf('ANA\u30b0\u30eb\u30fc\u30d7\u793e\u54e1\u69d8') >= 0){
		//ANAグループ社員様
		$storeTxtNameElem.addClass('block-header-logo--link-ana');
	}else if(storeTxtNameCheck.indexOf('\u30b5\u30f3\u30c8\u30ea\u30fc\u30b0\u30eb\u30fc\u30d7\u793e\u54e1\u69d8') >= 0){
		//サントリーグループ社員様
		$storeTxtNameElem.addClass('block-header-logo--link-suntry');
	}else if(storeTxtNameCheck.indexOf('NID-Net\u52a0\u76df\u793e\u5f93\u696d\u54e1\u69d8') >= 0){
		//NID-Net加盟社従業員様
		$storeTxtNameElem.addClass('block-header-logo--link-nid');
	}else if(storeTxtNameCheck.indexOf('\u307f\u3069\u308a\u4f1a\u30e1\u30f3\u30d0\u30fc\u4f1a\u793e\u5f93\u696d\u54e1\u69d8') >= 0){
		//みどり会メンバー会社従業員様
		$storeTxtNameElem.addClass('block-header-logo--link-midori');
	}else if(storeTxtNameCheck.indexOf('\u7279\u7d04\u5e97\u5f93\u696d\u54e1\u69d8') >= 0){
		//特約店従業員様
		$storeTxtNameElem.addClass('block-header-logo--link-tokuyaku');
	}else if(storeTxtNameCheck.indexOf('NICS PORT\u4f1a\u54e1\u3055\u307e') >= 0){
		//NICS PORT会員さま
		$storeTxtNameElem.addClass('block-header-logo--link-nissan');
	}else if(storeTxtNameCheck.indexOf('ENEOS\u30b0\u30eb\u30fc\u30d7\u5f93\u696d\u54e1\u69d8') >= 0){
		//ENEOSグループ従業員様
		$storeTxtNameElem.addClass('block-header-logo--link-eneos');
	}else if(storeTxtNameCheck.indexOf('\u4e00\u6761\u5de5\u52d9\u5e97\u30b0\u30eb\u30fc\u30d7\u5f93\u696d\u54e1\u69d8') >= 0){
		//一条工務店グループ従業員様
		$storeTxtNameElem.addClass('block-header-logo--link-ichizyo');
	}else if(storeTxtNameCheck.indexOf('\u30ea\u30f3\u30ca\u30a4\u30b0\u30eb\u30fc\u30d7\u5f93\u696d\u54e1\u69d8') >= 0){
		//リンナイグループ従業員様
		$storeTxtNameElem.addClass('block-header-logo--link-rinnai');
	}else if(storeTxtNameCheck.indexOf('\uff2a\uff34\u30b0\u30eb\u30fc\u30d7\u5f93\u696d\u54e1\u69d8') >= 0){
		//ＪＴグループ従業員様
		$storeTxtNameElem.addClass('block-header-logo--link-jt');
	}else if(storeTxtNameCheck.indexOf('\u30d5\u30af\u30c0\u96fb\u5b50\u30b0\u30eb\u30fc\u30d7\u5f93\u696d\u54e1\u69d8') >= 0){
		//フクダ電子グループ従業員様
		$storeTxtNameElem.addClass('block-header-logo--link-fukuda');
	}else if(storeTxtNameCheck.indexOf('\u30c8\u30e9\u30b9\u30b3\u4e2d\u5c71(\u682a)\u5f93\u696d\u54e1\u69d8') >= 0){
		//トラスコ中山(株)従業員様
		$storeTxtNameElem.addClass('block-header-logo--link-trusco');
	}else if(storeTxtNameCheck.indexOf('\u30e6\u30cb\u30fb\u30c1\u30e3\u30fc\u30e0\u30b0\u30eb\u30fc\u30d7') >= 0){
		//ユニチャームグループ従業員様
		$storeTxtNameElem.addClass('block-header-logo--link-uni');
	}else if(storeTxtNameCheck.indexOf('JAL\u30b0\u30eb\u30fc\u30d7') >= 0){
		//JALグループ従業員様
		$storeTxtNameElem.addClass('block-header-logo--link-jal');
	}else if(storeTxtNameCheck.indexOf('\u30AA\u30EA\u30A8\u30F3\u30BF\u30EB\u30E9\u30F3\u30C9\u5171\u6E08\u4F1A') >= 0){
		//オリエンタルランド共済会従業員様
		$storeTxtNameElem.addClass('block-header-logo--link-olc');
	}else if(storeTxtNameCheck.indexOf('\u4E2D\u592E\u65E5\u571F\u5730') >= 0){
		//中央日土地ソリューションズ従業員様
		$storeTxtNameElem.addClass('block-header-logo--link-cns');
	}else if(storeTxtNameCheck.indexOf('HK net service') >= 0){
		//ホンダ開発従業員様
		$storeTxtNameElem.addClass('block-header-logo--link-hondakaihatsu');
	}else if(storeTxtNameCheck.indexOf('NTT\u30B3\u30DF\u30E5\u30CB\u30B1\u30FC\u30B7\u30E7\u30F3\u30BA') >= 0){
		//NTTコミュニケーションズ従業員様
		$storeTxtNameElem.addClass('block-header-logo--link-nttcom');
	}else if(storeTxtNameCheck.indexOf('\u4E09\u4FE1\u96FB\u6C17') >= 0){
		//三信電気従業員様
		$storeTxtNameElem.addClass('block-header-logo--link-sanshin');
	}else if(storeTxtNameCheck.indexOf('\u304D\u3093\u3067\u3093') >= 0){
		//きんでん従業員様
		$storeTxtNameElem.addClass('block-header-logo--link-kinden');
	}else if(storeTxtNameCheck.indexOf('\u5357\u6771\u5317\u30B0\u30EB\u30FC\u30D7') >= 0){
		//脳神経疾患研究所(南東北グループ)従業員様
		$storeTxtNameElem.addClass('block-header-logo--link-minamitohoku');
	}else if(storeTxtNameCheck.indexOf('\u3042\u3044\u304A\u3044\u30CB\u30C3\u30BB\u30A4\u540C\u548C') >= 0){
		//あいおいニッセイ同和損害保険従業員様
		$storeTxtNameElem.addClass('block-header-logo--link-aioinissaydowa');
	}else if(storeTxtNameCheck.indexOf('\u30ED\u30FC\u30E0') >= 0){
		//ローム従業員様
		$storeTxtNameElem.addClass('block-header-logo--link-rohm');
	}else if(storeTxtNameCheck.indexOf('\u30A4\u30EF\u30BF\u30CB\u30B0\u30EB\u30FC\u30D7') >= 0){
		//岩谷産業従業員様
		$storeTxtNameElem.addClass('block-header-logo--link-iwatani');
	}else if(storeTxtNameCheck.indexOf('\u307F\u305A\u307B\u8A3C\u5238') >= 0){
		//みずほ証券従業員様
		$storeTxtNameElem.addClass('block-header-logo--link-mizuhosc');
	}
});

/* ============================================================
					詳細検索アコーディオン
==============================================================*/
jQuery(function() {
	if(jQuery('.page-search').length){
		let search_ac_btn = jQuery('.block-search-goods--condition-items-ttl-tab');
		let search_ac_cont = jQuery('.block-search-goods--condition-items-tab-cont');
		search_ac_btn.on('click', function() {
			if(search_ac_btn.hasClass('block-search-goods-btn-on')){
				search_ac_btn.removeClass('block-search-goods-btn-on');
				search_ac_cont.slideUp();
			}else{
				search_ac_btn.addClass('block-search-goods-btn-on');   
				search_ac_cont.slideDown();
			}
		});
	}
});

// モーダル
jQuery(function(){
	var $modalItem = jQuery('[id^=js-modal]');
	var $modalItemLength = $modalItem.length;

	if ($modalItemLength <= 0) {
		return;
	}

	var $win = jQuery(window);
	var $doc = jQuery(document);
	var $body = jQuery('body');
	var modalOpenClass = 'is-modalOpen';
	var hiddenClass = 'is-hidden';
	var $btnTrigger = jQuery('[data-modal^=js-modal]');
	var $dataModal;
	var $dataModalName;
	var $targetModalItem;
	var $targetModalItemInner;
	var $modalOverlay;
	var $modalId;
	var winHeight;
	var targetHeight;
	var clientWidth;
	var noScrollbarWidth;
	var difference;
	var scrollPosition;

	$modalItem.each(function () {
		jQuery(this)
		.attr({
			'role': 'dialog',
			'aria-modal': 'true'
		});
	});

	$modalOverlay = jQuery('\<div\>').attr({
		'id': 'js-modalOverlay',
		'class': 'c-modalOverlay'
	});

	$btnTrigger.on('click', function () {
		$dataModal = jQuery(this).data('modal');
		$dataModalName = '#' + $dataModal;
		$targetModalItem = jQuery($dataModalName);
		$targetModalItemInner = $targetModalItem.find('.c-modal-inner');
		clientWidth = $body[0].clientWidth;

		$targetModalItemInner.attr('tabindex', 0);
		$targetModalItem.removeClass(hiddenClass).focusLoop().wrap($modalOverlay);
		jQuery('.is-focusFirst').focus();
		// scrollPosition = $win.scrollTop();
		// $body.addClass(modalOpenClass).css('top', scrollPosition);
		$body.addClass(modalOpenClass);

		winHeight = $win.height();
		targetHeight = $targetModalItem.outerHeight();
		if(targetHeight > winHeight*.8) {
			$targetModalItem.addClass('is-contentsOver');
		}

		noScrollbarWidth = $body[0].clientWidth;
		difference = noScrollbarWidth - clientWidth;
		if (difference > 0) {
			$body.css('padding-right', difference + 'px');
		}

		return false;
	});

	$doc.on('click', '#js-modalOverlay, .js-btn-modalClose', function() {
		closeModal();
	});

	$doc.on('click', '#js-modalContentsArea, [id^=js-modal]', function(e) {
		e.stopPropagation();
	});

	function closeModal() {
		$modalOverlay = jQuery('#js-modalOverlay');
		$targetModalItem = $modalOverlay.find($modalItem);
		$targetModalItemInner = $targetModalItem.find('.c-modal-inner');
		$modalId = $targetModalItem.attr('id');

		$targetModalItemInner.attr('tabindex', -1);
		$targetModalItem.addClass(hiddenClass).unwrap($modalOverlay);
		// $body.removeClass(modalOpenClass).css('top', '');
		$body.removeClass(modalOpenClass);
		$btnTrigger.each(function () {
			$this = jQuery(this);
			$dataModal = $this.data('modal');
			if($dataModal === $modalId) {
				$this.focus();
			}
		});
		resetFocusLoop();

		$body.css('padding-right', '');
	}

	// Key
	$doc.on('keydown', function (e) {
		//27:Esc
		if(($body.hasClass(modalOpenClass)) && (e.keyCode === 27)) {
			closeModal();
		}
	});

	// Focus Loop, Tab & Shift+Tab Key
	var focusFirstClass = 'is-focusFirst';
	var focusLastClass = 'is-focusLast';
	jQuery.fn.focusLoop = function(options) {
		var focusableSelectors = ['a[href]', 'area[href]', 'input:not([disabled])', 'select:not([disabled])', 'textarea:not([disabled])', 'button:not([disabled])', 'iframe', 'object', 'embed', '[contenteditable]', '[tabindex]:not([tabindex^="-"])'];
		var focusableElements = focusableSelectors.join();
		let option = jQuery.extend({
			'area' : 'body',
		}, options);
		let $focus = jQuery();

		this.find(focusableElements).eq(0).addClass(focusFirstClass);
		this.find(focusableElements).eq(-1).addClass(focusLastClass);

		return this.each(function () {
			jQuery(option.area).on('keydown', function (e) {
				$focus = jQuery(':focus');

				if(pushKeyIsTab(e)) {
					if($focus.hasClass(focusLastClass)) {
						lastToFirst();
					};
				};

				if(pushKeyIsTabAndShift(e)){
					if($focus.hasClass(focusFirstClass)) {
						firstToLast();
					};
				};
			});

			var pushKeyIsTab = function (e) {
				return e.keyCode === 9 && !e.shiftKey;
			};

			var pushKeyIsTabAndShift = function (e) {
				return e.keyCode === 9 && e.shiftKey;
			};

			var lastToFirst = function () {
				event.preventDefault();
				jQuery('.' + focusFirstClass, this).focus();
			};

			var firstToLast = function () {
				event.preventDefault();
				jQuery('.' + focusLastClass, this).focus();
			};
		});
	};
	function resetFocusLoop() {
		jQuery('.' + focusFirstClass).removeClass(focusFirstClass);
		jQuery('.' + focusLastClass).removeClass(focusLastClass);
	}
});

// モーダル
jQuery(function(){
	var $modalItem = jQuery('[id^=js-modal]');
	var $modalItemLength = $modalItem.length;

	if ($modalItemLength <= 0) {
		return;
	}

	var $win = jQuery(window);
	var $doc = jQuery(document);
	var $body = jQuery('body');
	var modalOpenClass = 'is-modalOpen';
	var hiddenClass = 'is-hidden';
	var $btnTrigger = jQuery('[data-modal^=js-modal]');
	var $dataModal;
	var $dataModalName;
	var $targetModalItem;
	var $targetModalItemInner;
	var $modalOverlay;
	var $modalId;
	var winHeight;
	var targetHeight;
	var clientWidth;
	var noScrollbarWidth;
	var difference;
	var scrollPosition;

	$modalItem.each(function () {
		jQuery(this)
		.attr({
			'role': 'dialog',
			'aria-modal': 'true'
		});
	});

	$modalOverlay = jQuery('\<div\>').attr({
		'id': 'js-modalOverlay',
		'class': 'c-modalOverlay'
	});

	$btnTrigger.on('click', function () {
		$dataModal = jQuery(this).data('modal');
		$dataModalName = '#' + $dataModal;
		$targetModalItem = jQuery($dataModalName);
		$targetModalItemInner = $targetModalItem.find('.c-modal-inner');
		clientWidth = $body[0].clientWidth;

		$targetModalItemInner.attr('tabindex', 0);
		$targetModalItem.removeClass(hiddenClass).wrap($modalOverlay);
		jQuery('.is-focusFirst').focus();
		// scrollPosition = $win.scrollTop();
		// $body.addClass(modalOpenClass).css('top', scrollPosition);
		$body.addClass(modalOpenClass);

		winHeight = $win.height();
		targetHeight = $targetModalItem.outerHeight();
		if(targetHeight > winHeight*.8) {
			$targetModalItem.addClass('is-contentsOver');
		}

		return false;
	});

	$doc.on('click', '#js-modalOverlay, .js-btn-modalClose', function() {
		closeModal();
	});

	$doc.on('click', '#js-modalContentsArea, [id^=js-modal]', function(e) {
		e.stopPropagation();
	});

	function closeModal() {
		$modalOverlay = jQuery('#js-modalOverlay');
		$targetModalItem = $modalOverlay.find($modalItem);
		$targetModalItemInner = $targetModalItem.find('.c-modal-inner');
		$modalId = $targetModalItem.attr('id');

		$targetModalItemInner.attr('tabindex', -1);
		$targetModalItem.addClass(hiddenClass).unwrap($modalOverlay);
		// $body.removeClass(modalOpenClass).css('top', '');
		$body.removeClass(modalOpenClass);
		$btnTrigger.each(function () {
			$this = jQuery(this);
			$dataModal = $this.data('modal');
			if($dataModal === $modalId) {
				$this.focus();
			}
		});
	}
});

/* ====================================
	202203 社販対応
=====================================*/
jQuery(function() {
	var $txtCheckElem = jQuery('#header .block-header-logo--link');
	var txtCheck = $txtCheckElem.text();

	// txt = 社販、OB・OG
	if ((txtCheck.indexOf('\u793E\u8CA9') >= 0) || (txtCheck.indexOf('\u004F\u0042\u30FB\u004F\u0047') >= 0)) {
		if(jQuery('.page-top').length){
			//「購入前に知っておきたいこと」のエアコン
			jQuery('.block-top-free-2--howto > ul > li dl#howto_7').css('display', 'table-cell');
			//「製品カテゴリから探す」のエアコン
			jQuery('.block-top-free1-category--item.block-top-free1-category--item-ac').show();			
		}
		
		if(jQuery('.block-dynamic-category--row-ac').length){
			//ナビゲーション
			jQuery('.block-dynamic-category--row-ac').css('display', 'block');
		}
	}
});

/* ====================================
	202209 社販MV・おすすめ特集対応
=====================================*/
jQuery(function () {
  // 社販用バナー制御
  var $targetElem = jQuery('.js-company-sales');
  var $targetParentElem = jQuery('.js-company-sales-wrapper > #top-slider').find('li');
  var $txtCheckElem = jQuery('#header .block-header-logo--link');
  var txtCheck = $txtCheckElem.text();

  // txt = 社販
  if (txtCheck.indexOf('\u793E\u8CA9') >= 0) {
    jQuery('#top-slider-warp:not(.js-rank-c)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-c)').remove();
    jQuery('.js-rank-c').css('display', 'block');
    $targetParentElem.each(function () {
      if (jQuery(this).hasClass('js-company-sales')) {
        jQuery(this).css('display', 'block');
      }
    });
    if($txtCheckElem.find('.huid-none').length === 1) {
      jQuery('[data-huid]').each(function () {
        if(jQuery(this).data('huid') === 'yes') {
          jQuery(this).remove();
        }
      });
    } else {
      jQuery('[data-huid]').each(function () {
        if(jQuery(this).data('huid') === 'no') {
          jQuery(this).remove();
        }
      });
    }
  }else if(txtCheck.indexOf('\u004F\u0042\u30FB\u004F\u0047') >= 0){
    // txt = OB・OG
    jQuery('#top-slider-warp:not(.js-rank-ob)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-ob)').remove();
    jQuery('.js-rank-ob').css('display', 'block');
  }else if(txtCheck.indexOf('\u5927\u585A') >= 0){
    // txt = 大塚
    jQuery('#top-slider-warp:not(.js-rank-o)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-o)').remove();
    jQuery('.js-rank-o').css('display', 'block');
  }else if(txtCheck.indexOf('\u30b7\u30e3\u30fc\u30e1\u30be\u30f3\u30e9\u30a4\u30d5CLUB\u69d8') >= 0){
    // txt = シャーメゾン
    jQuery('#top-slider-warp:not(.js-rank-s)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-s)').remove();
    jQuery('.js-rank-s').css('display', 'block');
  }else if(txtCheck.indexOf('\u30ea\u30b3\u30fc\u30b0\u30eb\u30fc\u30d7\u793e\u54e1\u69d8') >= 0){
    // txt = リコー
    jQuery('#top-slider-warp:not(.js-rank-r)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-r)').remove();
    jQuery('.js-rank-r').css('display', 'block');
  }else if(txtCheck.indexOf('\u65e5\u7acb\u88fd\u54c1\u3054\u611b\u9867\u7d99\u7d9a\u304a\u5ba2\u69d8\u30b5\u30fc\u30d3\u30b9') >= 0){
    // txt = 日立製品
    jQuery('#top-slider-warp:not(.js-rank-h)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-h)').remove();
    jQuery('.js-rank-h').css('display', 'block');
  }else if(txtCheck.indexOf('\u3059\u307e\u3044\u30fc\u3060PLUS\u4f1a\u54e1\u69d8') >= 0){
    // txt = すまいーだ
    jQuery('#top-slider-warp:not(.js-rank-i)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-i)').remove();
    jQuery('.js-rank-i').css('display', 'block');
  }else if(txtCheck.indexOf('\u30b5\u30f3\u30c8\u30ea\u30fc') >= 0){
    // txt = サントリー
    jQuery('#top-slider-warp:not(.js-rank-u)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-u)').remove();
    jQuery('.js-rank-u').css('display', 'block');
  }else if(txtCheck.indexOf('SCSK\u793e\u54e1') >= 0){
    // txt = SCSK
    jQuery('#top-slider-warp:not(.js-rank-k)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-k)').remove();
    jQuery('.js-rank-k').css('display', 'block');
  }else if(txtCheck.indexOf('ANA\u30b0\u30eb\u30fc\u30d7') >= 0){
    // txt = ANA
    jQuery('#top-slider-warp:not(.js-rank-a)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-a)').remove();
    jQuery('.js-rank-a').css('display', 'block');
  }else if(txtCheck.indexOf('NID-Net\u52a0\u76df\u793e') >= 0){
    // txt = NID
    jQuery('#top-slider-warp:not(.js-rank-n)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-n)').remove();
    jQuery('.js-rank-n').css('display', 'block');
  }else if(txtCheck.indexOf('\u307f\u3069\u308a\u4f1a') >= 0){
    // txt = みどり会
    jQuery('#top-slider-warp:not(.js-rank-m)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-m)').remove();
    jQuery('.js-rank-m').css('display', 'block');
  }else if(txtCheck.indexOf('\u7279\u7d04\u5e97\u5f93\u696d\u54e1\u69d8') >= 0){
    // txt = 特約店
    jQuery('#top-slider-warp:not(.js-rank-t)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-t)').remove();
    jQuery('.js-rank-t').css('display', 'block');
  }else if(txtCheck.indexOf('NICS PORT\u4f1a\u54e1\u3055\u307e') >= 0){
    // txt = 日産
    jQuery('#top-slider-warp:not(.js-rank-ns)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-ns)').remove();
    jQuery('.js-rank-ns').css('display', 'block');
  }else if(txtCheck.indexOf('ENEOS\u30b0\u30eb\u30fc\u30d7\u5f93\u696d\u54e1\u69d8') >= 0){
    // txt = ENEOS
    jQuery('#top-slider-warp:not(.js-rank-en)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-en)').remove();
    jQuery('.js-rank-en').css('display', 'block');
  }else if(txtCheck.indexOf('\u4e00\u6761\u5de5\u52d9\u5e97\u30b0\u30eb\u30fc\u30d7\u5f93\u696d\u54e1\u69d8') >= 0){
    // txt = 一条工務店
    jQuery('#top-slider-warp:not(.js-rank-ic)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-ic)').remove();
    jQuery('.js-rank-ic').css('display', 'block');
  }else if(txtCheck.indexOf('\u30ea\u30f3\u30ca\u30a4\u30b0\u30eb\u30fc\u30d7\u5f93\u696d\u54e1\u69d8') >= 0){
    // txt = リンナイ
    jQuery('#top-slider-warp:not(.js-rank-rn)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-rn)').remove();
    jQuery('.js-rank-rn').css('display', 'block');
  }else if(txtCheck.indexOf('\uff2a\uff34\u30b0\u30eb\u30fc\u30d7\u5f93\u696d\u54e1\u69d8') >= 0){
    // txt = JT
    jQuery('#top-slider-warp:not(.js-rank-jt)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-jt)').remove();
    jQuery('.js-rank-jt').css('display', 'block');
  }else if(txtCheck.indexOf('\u30d5\u30af\u30c0\u96fb\u5b50\u30b0\u30eb\u30fc\u30d7\u5f93\u696d\u54e1\u69d8') >= 0){
    // txt = フクダ電子
    jQuery('#top-slider-warp:not(.js-rank-fd)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-fd)').remove();
    jQuery('.js-rank-fd').css('display', 'block');
  }else if(txtCheck.indexOf('\u30c8\u30e9\u30b9\u30b3\u4e2d\u5c71(\u682a)\u5f93\u696d\u54e1\u69d8') >= 0){
    // txt = トラスコ中山
    jQuery('#top-slider-warp:not(.js-rank-tr)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-tr)').remove();
    jQuery('.js-rank-tr').css('display', 'block');
  }else if(txtCheck.indexOf('\u30e6\u30cb\u30fb\u30c1\u30e3\u30fc\u30e0\u30b0\u30eb\u30fc\u30d7') >= 0){
    // txt = ユニチャーム
    jQuery('#top-slider-warp:not(.js-rank-un)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-un)').remove();
    jQuery('.js-rank-un').css('display', 'block');
  }else if(txtCheck.indexOf('JAL\u30b0\u30eb\u30fc\u30d7') >= 0){
    // txt = JAL
    jQuery('#top-slider-warp:not(.js-rank-j)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-j)').remove();
    jQuery('.js-rank-j').css('display', 'block');
  }else if(txtCheck.indexOf('\u30AA\u30EA\u30A8\u30F3\u30BF\u30EB\u30E9\u30F3\u30C9\u5171\u6E08\u4F1A') >= 0){
    // txt = オリエンタルランド共済会
    jQuery('#top-slider-warp:not(.js-rank-ori)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-ori)').remove();
    jQuery('.js-rank-ori').css('display', 'block');
  }else if(txtCheck.indexOf('\u4E2D\u592E\u65E5\u571F\u5730') >= 0){
    // txt = 中央日土地
    jQuery('#top-slider-warp:not(.js-rank-chu)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-chu)').remove();
    jQuery('.js-rank-chu').css('display', 'block');
  }else if(txtCheck.indexOf('HK net service') >= 0){
    // txt = HK net service（ホンダ開発）
    jQuery('#top-slider-warp:not(.js-rank-hon)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-hon)').remove();
    jQuery('.js-rank-hon').css('display', 'block');
  }else if(txtCheck.indexOf('NTT\u30B3\u30DF\u30E5\u30CB\u30B1\u30FC\u30B7\u30E7\u30F3\u30BA') >= 0){
    // txt = NTTコミュニケーションズ
    jQuery('#top-slider-warp:not(.js-rank-ntt)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-ntt)').remove();
    jQuery('.js-rank-ntt').css('display', 'block');
  }else if(txtCheck.indexOf('\u4E09\u4FE1\u96FB\u6C17') >= 0){
    // txt = 三信電気
    jQuery('#top-slider-warp:not(.js-rank-san)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-san)').remove();
    jQuery('.js-rank-san').css('display', 'block');
  }else if(txtCheck.indexOf('\u304D\u3093\u3067\u3093') >= 0){
    // txt = きんでん
    jQuery('#top-slider-warp:not(.js-rank-kin)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-kin)').remove();
    jQuery('.js-rank-kin').css('display', 'block');
  }else if(txtCheck.indexOf('\u5357\u6771\u5317\u30B0\u30EB\u30FC\u30D7') >= 0){
    // txt = 南東北グループ（脳神経疾患研究所）
    jQuery('#top-slider-warp:not(.js-rank-min)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-min)').remove();
    jQuery('.js-rank-min').css('display', 'block');
  }else if(txtCheck.indexOf('\u3042\u3044\u304A\u3044\u30CB\u30C3\u30BB\u30A4\u540C\u548C') >= 0){
    // txt = あいおいニッセイ同和
    jQuery('#top-slider-warp:not(.js-rank-aioi)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-aioi)').remove();
    jQuery('.js-rank-aioi').css('display', 'block');
  }else if(txtCheck.indexOf('\u30ED\u30FC\u30E0') >= 0){
    // txt = ローム
    jQuery('#top-slider-warp:not(.js-rank-roh)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-roh)').remove();
    jQuery('.js-rank-roh').css('display', 'block');
  }else if(txtCheck.indexOf('\u30A4\u30EF\u30BF\u30CB\u30B0\u30EB\u30FC\u30D7') >= 0){
    // txt = イワタニグループ（岩谷産業）
    jQuery('#top-slider-warp:not(.js-rank-iwa)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-iwa)').remove();
    jQuery('.js-rank-iwa').css('display', 'block');
  }else if(txtCheck.indexOf('\u307F\u305A\u307B\u8A3C\u5238') >= 0){
    // txt = みずほ証券
    jQuery('#top-slider-warp:not(.js-rank-msh)').remove();
    jQuery('.top-features-list-wrap:not(.js-rank-msh)').remove();
    jQuery('.js-rank-msh').css('display', 'block');
  }else{
    jQuery('.js-company-sales-wrapper').remove();
    jQuery('.js-top-features-list-wrap').remove();
  }
});
/* ============================================================
					エアコン関連修正
==============================================================*/
jQuery(function(){
	
	/* --------------------必須項目の数を取得---------------------- */
	
	if(jQuery('.page-estimate #js-modalContentsArea').length) {
		jQuery('.page-estimate #js-modalContentsArea').each(function() {
			
			//id取得
			var const_modal_id = jQuery(this).find('.c-modal').attr('id');
			var const_modal_posi = '.block-area-quecheck-inner a[data-modal="' + const_modal_id + '"]'; 
			
			//必須項目の数
			var item_required_num_list = jQuery(this).find('.frm-list-required-item').length;
			jQuery(this).find('.block-area-questionnaire').attr('data-required-num', item_required_num_list);
			
			jQuery(this).find('.block-area-questionnaire-nest').each(function() {
				jQuery(this).find('.frm-list-required-item').each(function() {
					if(jQuery(this).hasClass('frm-list-floor-number')){	
						if(jQuery(this).find('input[type="text"]').val() != ''){
							jQuery(this).addClass('frm-list-required-check-on');
						}
					}else if(jQuery(this).hasClass('frm-list-removal-number')){
						var item_required_radio_val = jQuery(this).find('input[type="radio"]:checked').val();
						var item_required_txt_val = jQuery(this).find('input[type="text"]').val();

						if(item_required_radio_val == '0' && item_required_txt_val != ''){
							jQuery(this).addClass('frm-list-required-check-on');
						}else if(item_required_radio_val == '9'){
							jQuery(this).addClass('frm-list-required-check-on');
						}					
					}else if(jQuery(this).hasClass('frm-list-required-item')){
						var item_required_radio_check = jQuery(this).find('input[type="radio"]:checked').length;
						if(item_required_radio_check > 0){
							jQuery(this).addClass('frm-list-required-check-on');
						}
					}
				});
			});
				
			//完了したチェック数
			var now_item_required_check = jQuery(this).find('.block-area-questionnaire .frm-list-required-check-on').length;

			if(now_item_required_check > 1){
				jQuery(this).find('.block-area-questionnaire').addClass('block-area-questionnaire-check-on');				
			}
			
			//チェック完了でdisabledはずす
			if(item_required_num_list == now_item_required_check){
				jQuery(this).find('.block-area-questionnaire .quecheck-btn-inner').prop('disabled', false);
				jQuery(this).find('.block-area-questionnaire .quecheck-btn-inner').addClass('quecheck-btn-inner-on');
				jQuery(const_modal_posi).parents('.block-area-quecheck-inner').find('.quecheck-checkbox-wrap input').prop('disabled', false);
			}else{
				jQuery(this).find('.block-area-questionnaire .quecheck-btn-inner').prop('disabled', true);		
				jQuery(this).find('.block-area-questionnaire .quecheck-btn-inner').removeClass('quecheck-btn-inner-on');
				//jQuery(const_modal_posi).parents('.block-area-quecheck-inner').find('.quecheck-checkbox-wrap input').removeAttr("checked").prop("checked", false).change();			
				jQuery(const_modal_posi).parents('.block-area-quecheck-inner').find('.quecheck-checkbox-wrap input').prop('disabled', true);
			}			
		});
	}
	
	/* --------------------工事内容のチェック---------------------- */	
	jQuery('.quecheck-checkbox-wrap input[type="checkbox"]').change(function() {
		if(jQuery(this).prop('checked')) {
			jQuery(this).parents('.block-area-questionnaire').addClass('block-area-questionnaire-check-on');
		}else{
			jQuery(this).parents('.block-area-questionnaire').removeClass('block-area-questionnaire-check-on');			
		}
	});
	
	/* --------------------必須項目のチェック（ラジオボタン）---------------------- */		
	jQuery('.block-area-questionnaire-nest .frm-list-required-item').not('.frm-list-removal-number').find('input[type="radio"]').change(function () {
		
		//id取得
		var const_modal_id = jQuery(this).parents('.c-modal').attr('id');
		var const_modal_posi = '.block-area-quecheck-inner a[data-modal="' + const_modal_id + '"]'; 
		
		//必須項目の数
		var item_required_num_list = jQuery(this).parents('.block-area-questionnaire').attr('data-required-num');
		
		//クリックでクラス追加
		jQuery(this).parents('.frm-list-required-item').addClass('frm-list-required-check-on');
		
		//完了したチェック数
		var now_item_required_check = jQuery(this).parents('.block-area-questionnaire').find('.frm-list-required-check-on').length;

		//チェック完了でdisabledはずす
		if(item_required_num_list == now_item_required_check){
			jQuery(this).parents('.block-area-questionnaire').find('.quecheck-btn-inner').prop('disabled', false);
			jQuery(this).parents('.block-area-questionnaire').find('.quecheck-btn-inner').addClass('quecheck-btn-inner-on');
			jQuery(const_modal_posi).parents('.block-area-quecheck-inner').find('.quecheck-checkbox-wrap input').prop('disabled', false);
		}else{
			jQuery(this).parents('.block-area-questionnaire').find('.quecheck-btn-inner').prop('disabled', true);		
			jQuery(this).parents('.block-area-questionnaire').find('.quecheck-btn-inner').removeClass('quecheck-btn-inner-on');
			//jQuery(const_modal_posi).parents('.block-area-quecheck-inner').find('.quecheck-checkbox-wrap input').removeAttr("checked").prop("checked", false).change();			
			jQuery(const_modal_posi).parents('.block-area-quecheck-inner').find('.quecheck-checkbox-wrap input').prop('disabled', true);
		}
	});

	/* --------------------既存のエアコン取外し ラジオボタン + テキストボックス---------------------- */
	jQuery('.block-area-questionnaire-nest .frm-list-required-item.frm-list-removal-number input').change(function () {

		//id取得
		var const_modal_id = jQuery(this).parents('.c-modal').attr('id');
		var const_modal_posi = '.block-area-quecheck-inner a[data-modal="' + const_modal_id + '"]'; 
		
		//必須項目の数
		var item_required_num_list = jQuery(this).parents('.block-area-questionnaire').attr('data-required-num');
		
		//ラジオボタンのvalueを取得
		var item_required_radio_val = jQuery(this).parents('.frm-list-required-item.frm-list-removal-number').find('input[type="radio"]:checked').val();
		
		//テキストボックスのvalueを取得
		var item_required_txt_val = jQuery(this).parents('.frm-list-required-item.frm-list-removal-number').find('input[type="text"]').val();
		
		//選択のチェック
		if(item_required_radio_val == 0){
			if(item_required_txt_val != ""){
				jQuery(this).parents('.frm-list-required-item').addClass('frm-list-required-check-on');			
			}else{
				jQuery(this).parents('.frm-list-required-item').removeClass('frm-list-required-check-on');				
			}
		}else if(item_required_radio_val == 9){
			jQuery(this).parents('.frm-list-required-item').addClass('frm-list-required-check-on');				 
		}else{
			jQuery(this).parents('.frm-list-required-item').removeClass('frm-list-required-check-on');			
		}
		
		//完了したチェック数
		var now_item_required_check = jQuery(this).parents('.block-area-questionnaire').find('.frm-list-required-check-on').length;

		//チェック完了でdisabledはずす
		if(item_required_num_list == now_item_required_check){
			jQuery(this).parents('.block-area-questionnaire').find('.quecheck-btn-inner').prop('disabled', false);
			jQuery(this).parents('.block-area-questionnaire').find('.quecheck-btn-inner').addClass('quecheck-btn-inner-on');
			jQuery(const_modal_posi).parents('.block-area-quecheck-inner').find('.quecheck-checkbox-wrap input').prop('disabled', false);
		}else{
			jQuery(this).parents('.block-area-questionnaire').find('.quecheck-btn-inner').prop('disabled', true);		
			jQuery(this).parents('.block-area-questionnaire').find('.quecheck-btn-inner').removeClass('quecheck-btn-inner-on');
			//jQuery(const_modal_posi).parents('.block-area-quecheck-inner').find('.quecheck-checkbox-wrap input').removeAttr("checked").prop("checked", false).change();			
			jQuery(const_modal_posi).parents('.block-area-quecheck-inner').find('.quecheck-checkbox-wrap input').prop('disabled', true);			
		}
	});
	
	/* --------------------取り付け階数 テキストボックス---------------------- */
	jQuery('.block-area-questionnaire-nest .frm-list-required-item.frm-list-floor-number input[type="text"]').change(function () {

		//id取得
		var const_modal_id = jQuery(this).parents('.c-modal').attr('id');
		var const_modal_posi = '.block-area-quecheck-inner a[data-modal="' + const_modal_id + '"]'; 
		
		//必須項目の数
		var item_required_num_list = jQuery(this).parents('.block-area-questionnaire').attr('data-required-num');
		
		//入力された値
		var item_required_textbox = jQuery(this).val();
		
		//入力されているか判定
		if (item_required_textbox != "") { 		
			jQuery(this).parents('.frm-list-required-item').addClass('frm-list-required-check-on');
		}else{
			jQuery(this).parents('.frm-list-required-item').removeClass('frm-list-required-check-on');			
		}
		
		//完了したチェック数
		var now_item_required_check = jQuery(this).parents('.block-area-questionnaire').find('.frm-list-required-check-on').length;
		
		//チェック完了でdisabledはずす
		if(item_required_num_list == now_item_required_check){
			jQuery(this).parents('.block-area-questionnaire').find('.quecheck-btn-inner').prop('disabled', false);
			jQuery(this).parents('.block-area-questionnaire').find('.quecheck-btn-inner').addClass('quecheck-btn-inner-on');
			jQuery(const_modal_posi).parents('.block-area-quecheck-inner').find('.quecheck-checkbox-wrap input').prop('disabled', false);
		}else{
			jQuery(this).parents('.block-area-questionnaire').find('.quecheck-btn-inner').prop('disabled', true);		
			jQuery(this).parents('.block-area-questionnaire').find('.quecheck-btn-inner').removeClass('quecheck-btn-inner-on');
			//jQuery(const_modal_posi).parents('.block-area-quecheck-inner').find('.quecheck-checkbox-wrap input').removeAttr("checked").prop("checked", false).change();			
			jQuery(const_modal_posi).parents('.block-area-quecheck-inner').find('.quecheck-checkbox-wrap input').prop('disabled', true);			
		}
	});
});

/* ====================================
	Group Global Header / Footer
=====================================*/
jQuery.extend({
    // 画面サイズ
    isSM : function(){
        return (window.innerWidth || document.documentElement.clientWidth) < 768
    }
});

// サポートメニュー
jQuery(function(){
    if (jQuery(".SupportNaviIconText").length == 0) {
        return;
    }

    const $search = jQuery("#SupportNaviSearch");
    const alt = $search.find("img").attr("alt");

    jQuery(".SupportNaviIconText>a, .SupportNaviIconText>button").each(function(){
        if (!jQuery(this).is($search)) {
            jQuery(this).find("img").attr("alt", null);
        }
    });

    jQuery(window).on("resize.SupportNavi", function(){
        if (jQuery.isSM()) {
            $search.find("img").attr("alt", alt);
        } else {
            $search.find("img").attr("alt", null);
        }
    }).triggerHandler("resize.SupportNavi");
});

// 検索
jQuery(function(){

    const $form = jQuery("#SearchFormArea");
    const $header = jQuery("#HeaderArea1");
    const $btn = jQuery("button#SupportNaviSearch");

    if ($form.length == 0 || $btn.length == 0) {
        return;
    }

    // 検索を開く
    function open() {
        jQuery("button#SupportNaviLang.is-open").triggerHandler("click");
        jQuery("#SpMenuBtn.is-open").triggerHandler("click");

        if (!jQuery.isSM() || $header.find(".ContainerFix").length) {
            $form.stop(true, true).slideDown({progress:function(){
                $header.css("margin-bottom", $form.outerHeight());
            }});
        } else {
            jQuery("html").css("overflow", "hidden");
            jQuery("body").addClass("spsearch-open");
            $backdrop.appendTo("body").ready(function(){
                $backdrop.addClass("show");
            });
            $form.show().ready(function(){
                $form.addClass("show");
            });
        }

        $btn.addClass("is-open").attr("aria-expanded", "true");
    }

    // 検索を閉じる
    function close() {
        if (!jQuery.isSM() || $header.find(".ContainerFix").length) {
            $form.stop(true, true).slideUp({progress:function(){
                $header.css("margin-bottom", $form.outerHeight());
            }});
        }
        jQuery("html").css("overflow", "");
        jQuery("body").removeClass("spsearch-open");
        $form.removeClass("show");
        $backdrop.removeClass("show");
        $btn.removeClass("is-open").attr("aria-expanded", "false");
    }

    $form.on("transitionend webkitTransitionEnd", function() {
        if (!$form.hasClass("show")) {
            $form.hide();
        }
    });


    // サポートメニューの検索ボタン
    jQuery("button#SupportNaviSearch").on("click", function(){
        if (jQuery(this).hasClass("is-open")) {
            close();
        } else {
            open();
        }
        return false;
    });

    // 検索エリアの閉じるボタン
    jQuery("#SearchFormArea .BtnClose").on("click", function(){
        jQuery("button#SupportNaviSearch.is-open").triggerHandler("click");
        return false;
    });

    // backdrop
    const $backdrop = jQuery('<div id="SpSearchBackdrop"></div>');
    $backdrop.on("transitionend webkitTransitionEnd", function() {
        if (!$backdrop.hasClass("show")) {
            $backdrop.detach();
        }
    });
    $backdrop.on("click", function(e) {
        close();
    });
    
    jQuery(window).on("resize.SearchFormArea", function(){
        $form.css("top", $header.height());
        
        if ($header.find(".Container").length) {
            if (jQuery.isSM()) {
                $header.css("margin-bottom", "");
                if ($form.is(":visible") && !$form.hasClass("show")) {
                    close();
                }
            } else {
                if ($form.is(":visible")) {
                    if ($form.hasClass("show")) close();
                    $header.css("margin-bottom", $form.outerHeight());
                }
            }
        }

        return false;
    }).triggerHandler("resize.SearchFormArea");
});

// ドロップダウンメニュー
jQuery(function(){

    // 開く
    function open($btn) {
        
        // 開いているメニューがあれば閉じる
        jQuery(".DropDownMenu>button.is-open").not($btn).each(function(){
            jQuery(this).removeClass("is-open");
            jQuery(this).next("ul").stop(true, true).slideUp();
        });

        $btn.addClass("is-open").attr("aria-expand", "true");
        $btn.next("ul").stop(true, true).slideDown();
        $backdrop.appendTo("body");
        jQuery("#HeaderArea2").addClass("dropdown-open");
    }


    // 閉じる
    function close($btn) {
        if ($btn == null) {
            jQuery(".DropDownMenu>button.is-open").each(function(){
                jQuery(this).removeClass("is-open");
                jQuery(this).next("ul").stop(true, true).slideUp();
            });
        } else {
            $btn.removeClass("is-open").attr("aria-expand", "false");
            $btn.next("ul").stop(true, true).slideUp();
        }
        $backdrop.detach();

        jQuery("#HeaderArea2").removeClass("dropdown-open");      
    }


    // ドップダウンメニューの位置の調整
    function offset() {
        jQuery(".DropDownMenu>button.is-open").each(function(){
            const $btn = jQuery(this);
            const $menu = jQuery(this).next("ul");
            const $container = jQuery("#HeaderArea2>.Container ,#HeaderArea2>.ContainerFix");

            if ($btn.offset().left + $menu.width() > $container.offset().left + $container.width()) {
                $menu.offset({left: $btn.offset().left - $menu.width() + $btn.outerWidth()});
            } else {
                $menu.offset({left: $btn.offset().left});
            }
        });
    }

    
    // メニューのクリック
    jQuery(".DropDownMenu>button").on("click", function(){
        if (jQuery(this).hasClass("is-open")) {
            close(jQuery(this));
        } else {
            open(jQuery(this));
            offset();
        }

        return false;
    });

    // keydown（メニュー）
    jQuery(".DropDownMenu>button").on("keydown", function(e){
        if (e.keyCode == 13 || e.keyCode == 40) {
            if (jQuery(this).hasClass("is-open")) {
                close(jQuery(this));
            } else {
                open(jQuery(this));
                offset();
                jQuery(this).next().find(">li:first-child>*").focus();
            }
            return false;
        }
        return true;
    });

     // サブメニューの開閉
    jQuery(".DropDownMenu>ul button").on("click", function(){

        if (jQuery(this).hasClass("is-open")) {
            jQuery(this).removeClass("is-open").attr("aria-expanded", "false");
            jQuery(this).next("ul").stop(true, true).slideUp();    
        } else {
            jQuery(this).addClass("is-open").attr("aria-expanded", "true");
            jQuery(this).next("ul").stop(true, true).slideDown();
        }
        return false;
    });

    // keydown（メニュー内）
    jQuery(".DropDownMenu>ul a, .DropDownMenu>ul button").on("keydown", function(e){
        if (e.keyCode == 38) {
            const $list = jQuery(this).closest("ul").children();
            var $prev = jQuery(this).parent().prev();
            if ($prev.length == 0) {
                $prev = $list.last();
            }
            $prev.find(">a,>button").focus();
            return false;
        }
        if (e.keyCode == 40) {
            const $list = jQuery(this).closest("ul").children();
            var $next = jQuery(this).parent().next();
            if ($next.length == 0) {
                $next = $list.first();
            }
            $next.find(">a,>button").focus();
            return false;
        }
        if (e.keyCode == 39) {
            const $ul = jQuery(this).next("ul");
            if ($ul.length) {
                jQuery(this).addClass("is-open").attr("aria-expanded", "true");
                $ul.stop(true, true).slideDown();
                $ul.find(">li:first-child>*").focus();
            }
            return false;
        }
        if (e.keyCode == 37) {
            const $ul = jQuery(this).closest("ul");
            $ul.prev("button").focus().removeClass("is-open").attr("aria-expanded", "false");
            $ul.stop(true, true).slideUp();
            return false;
        }
        if (e.keyCode == 9) {
            return true;
        }
        return true;
    });
    
    
    // 選択中のメニューを開いた状態にする
    jQuery(".DropDownMenu>ul li.Current").each(function(){
        jQuery(this).parents("ul:not([id^=GlobalNaviMenu])").each(function(){
            if (!jQuery(this).parent().hasClass("DropDownMenu")) {
                jQuery(this).show();
                jQuery(this).prev("button").addClass("is-open").attr("aria-expanded", "true");
            }
        });
    });

    // フォーカス
    jQuery(".DropDownMenu>ul a, .DropDownMenu>ul button").on("blur", function(e){
        const $menu = jQuery(this).closest(".DropDownMenu").find(">ul");
        setTimeout(function(){
            if ($menu.find("a,button").index(jQuery(":focus")) == -1) {
                close();
            }
        },50);
    });

    // ウィンドウリサイズ
    jQuery(window).on("resize.DropDownMenu", function(){

        // ドロップダウンメニューの位置を調整
        offset();

        // SPモードになったらメニューを閉じる
        if (jQuery.isSM()) {
            close();
        }

    });

    // backdrop
    const $backdrop = jQuery('<div id="DropDownBackdrop"></div>');
    $backdrop.on("click", function(){
        close(null);
    });

});

// コピーライト
jQuery(function(){
    const year1 = parseInt(jQuery("#Copyright span").text());
    const year2 = (new Date()).getFullYear();
    if (isNaN(year1)) return;
    if (year1 == year2) return;
    if (year1 < year2) jQuery("#Copyright span").text(year1 + ", " + year2);
});

// ページトップへ
jQuery(function(){
    jQuery("#FooterPageTop").off("click");
    jQuery("#FooterPageTop").on("click", function(){
        var topID = (ua("safari")) ? "html,body" : "html";
        var link = jQuery(this).attr("href");
        if(link.charAt(0)=="#" && link.charAt(1)!="") {
            setTimeout(function() {
                jQuery(topID).stop().animate({scrollTop: 0}, 800, "easeInOutCubic", function() {
                    location.href = link;
                });
            }, 50);
            return false;
        }
        return false;
    });

    // FatMenuがある場合、位置の調整
    function offset() {
        var $prev = jQuery("#FooterArea").prev();
        var $target = null;
        while(true) {
            if (!($prev.hasClass("FatMenu") || $prev.hasClass("FatMenuWide") || $prev.hasClass("FatBanner"))) {
                break;
            }
            if ($prev.is(":visible")) {
                $target = $prev;
            }
            $prev = $prev.prev();
        }
        if ($target != null) {
            jQuery("#FooterPageTop").offset({top:$target.offset().top - jQuery("#FooterPageTop").height()});
        } else {
            jQuery("#FooterPageTop").css("top", "");
        }
    }

    if (jQuery("#FooterArea").prevAll(".FatMenu,.FatMenuWide,.FatBanner").length > 0) {
        jQuery(window).on("resize.FooterPageTop", offset);
        offset();
    }
});

// global nav Rental Page
jQuery(function(){
    const targetPath = '/store/pages/rental.aspx';
    const linkCurrentClass = 'Current';
    let rentalTxt;
    let oldCurrentTxt;
    let $thisLink;

    if(location.pathname.indexOf(targetPath) >= 0) {
        jQuery('#GlobalNaviMenu').find('a').each(function() {
            $thisLink = jQuery(this);

            if($thisLink.attr('href') === targetPath) {
                rentalTxt = $thisLink.text();
                oldCurrentTxt = $thisLink.closest('li').prev().find('strong').text();
                $thisLink.closest('li').addClass(linkCurrentClass).prev().removeClass(linkCurrentClass).find('a').html(oldCurrentTxt);
                $thisLink.html('<strong>' + rentalTxt + '</strong>');
            }
        });

        // Rental Page error
        if(jQuery('.block-common-alert').length) {
            let getName = jQuery('#header .block-header-logo--link').text();
            jQuery('.block-common-alert--message').html(getName + 'では現在レンタル商品をお取り扱いしておりません。<br>詳しくは日立の家電品オンラインストア事務局までお問い合わせください。');
        }
    }
});

/* ====================================
	レンタル契約商品一覧
=====================================*/
jQuery(function(){
    if(location.pathname.indexOf('/store/customer/rentalhistory.aspx') >= 0) {
        const targetElemClassName = '.block-regular-purcharse-list--info-other-thick';
        jQuery('.block-regular-purcharse-list--list').each(function() {
            let decisionTxt = jQuery(this).find('.block-regular-purcharse-list--detail-item-list-nolink').text();
            let changeElem = jQuery(this).find('.block-regular-purcharse-list--info-other-thin');

            // txt = 【レンタル・
            if(decisionTxt.indexOf('\u3010\u30EC\u30F3\u30BF\u30EB\u30FB') >= 0) {
                for(let rentalI = 0; rentalI < changeElem.length; changeElem++) {
                    // txt = 契約プラン
                    if(changeElem.eq(rentalI).text() === '\u5951\u7D04\u30D7\u30E9\u30F3') {
                        let textSaving = changeElem.eq(rentalI).next(targetElemClassName).text();
                        // txt = レンタル・
                        changeElem.eq(rentalI).next(targetElemClassName).text('\u30EC\u30F3\u30BF\u30EB\u30FB' + textSaving);
                    }
                }
            }
        });
    }
});

/* ====================================
	レンタルご注文前に
=====================================*/
jQuery(function(){
    if((location.pathname.indexOf('/store/cart/goodsagree.aspx') >= 0) && (jQuery('#js-beforeRentalOrder').length)) {
        const $stickyButton = jQuery('.lt_sticky_button');
        let $this;

        if($stickyButton.length) {
            $stickyButton.find('.lt_sticky_linktxt').each(function() {
                $this = jQuery(this);

                if($this.attr('href') === '/store/pages/guide.aspx') {
                    $this.attr('href', '/store/pages/rental_guide.aspx');
                } else if($this.attr('href') === '/store/pages/faq.aspx') {
                    $this.attr('href', '/store/pages/rental_faq.aspx');
                }
            });
        }
    }
});

/* ====================================
	トップページ本文 会員ランク出し分け
=====================================*/
jQuery(function () {
    const $mvList = jQuery('.js-mv-list');
    const $bnrList = jQuery('.js-bnr-list');
    const $topFeaturesBtn = jQuery('.top-features-list-more-btn');
    const rankGroup = jQuery('[data-rank-group]').data('rank-group');
    const rankCompany = jQuery('[data-rank-company]').data('rank-company');

    applyCommonAction($mvList, rankGroup, rankCompany);
    applyCommonAction($bnrList, rankGroup, rankCompany);

    // MV
    jQuery('.js-mv-list.slick-initialized').slick('unslick');
    $mvList.slick({
        initialSlide: 1,
        dots: true,
        pauseOnHover: true,
        infinite: true,
        speed: 1000,
        easing: 'ease',
        arrows: true,
        autoplay: true,
        slidesToShow: 1,
        centerMode: true,
        variableWidth: true,
        prevArrow: '<a class="slick-prev" href="#"><img src="../img/usr/pc/top_main_slider_prev.png" alt="prev slide"></a>',
        nextArrow: '<a class="slick-next" href="#"><img src="../img/usr/pc/top_main_slider_next.png" alt="next slide"></a>',
        customPaging: function(slick,index) {
            // スライダーのインデックス番号に対応した画像のsrcを取得
            var targetImage = slick.$slides.eq(index).find('img').attr('src');
            // slick-dots > li の中に上記で取得した画像を設定
            return '<img src=" ' + targetImage + ' "/>';
        }
    });
    $mvList.prepend('<div class="slide-btn-inner"><div></div></div>');
    $mvList.find('.slick-next').prependTo('.slide-btn-inner > div');
    $mvList.find('.slick-prev').prependTo('.slide-btn-inner > div');

    // Banner
    $bnrList.find('li').each(function (i) {
        if (i >= 6){
            jQuery(this).addClass('hidden');
        }
    });
    if ($bnrList.find('li').length <= 6) {
        $topFeaturesBtn.remove();
    }
    $topFeaturesBtn.on('click', function () {
        $bnrList.find('li.hidden').slideDown();
        jQuery(this).remove();
    });

    function applyCommonAction($targetList, rankGroup, rankCompany) {
        if ($targetList) {
            // data-rank-group属性値に一致するdata属性を持つ要素を絞り込む
            const $listItems = $targetList.find('li').filter("[data-" + rankGroup + "]");

            // 数値属性の値で昇順に並び替え
            $listItems.sort(function(a, b) {
                return jQuery(a).data(rankGroup) - jQuery(b).data(rankGroup);
            });
            $targetList.empty().append($listItems);

            // data-hide属性がある場合、該当する要素をリストから削除
            $listItems.each(function() {
                const $hideItem = jQuery(this);
                const hideAttr = $hideItem.data('hide');

                if (hideAttr) {
                    const hiddenCompanies = hideAttr.split(' ');
                    if (hiddenCompanies.includes(rankCompany)) {
                        $hideItem.remove();
                    }
                }
            });
        }
    }
});
