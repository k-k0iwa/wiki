'use strict';

(() => {
    const browseMode = document.querySelector('[data-browse-mode]');

    if (browseMode && browseMode.getAttribute('data-browse-mode') === 'P') {
        document.querySelectorAll('[href^="#anc-"]').forEach(anchor => {
            anchor.addEventListener('click', (e) => {
                e.preventDefault();

                let href = e.target.getAttribute('href');

                if(href === "#anc-top") {
                    window.scrollTo({
                        top: 0,
                        behavior: 'smooth'
                    });
                } else {
                    document.querySelector(href).scrollIntoView({
                        behavior: 'smooth'
                    });
                }

                return false;
            });
        });
    }
})();

jQuery(document).ready(function() {
    // 開催期間に応じた表示切替
    // Function to update countdown timer
    function updateCountdown(endTime) {
        const now = new Date(); // Use Date object to get current date and time
        const timeLeft = endTime - now.getTime(); // Get current time in milliseconds

        const hours = Math.floor(timeLeft / 1000 / 60 / 60 % 24);
        const minutes = Math.floor(timeLeft / 1000 / 60 % 60);
        const seconds = Math.floor(timeLeft / 1000 % 60);
console.log('hours:', hours);
console.log('minutes:', minutes);
console.log('seconds:', seconds);
        jQuery('.js-count-hour').text(String(hours).padStart(2, '0'));
        jQuery('.js-count-min').text(String(minutes).padStart(2, '0'));
        jQuery('.js-count-sec').text(String(seconds).padStart(2, '0'));

        if (timeLeft <= 0) {
            clearInterval(timerInterval);
            jQuery('#js-periodJustBefore').fadeOut();
            jQuery('#js-periodInSession').addClass('is-active');
            jQuery('.free-timeSale').addClass('is-periodInSession');
            jQuery('#js-periodInSession').text('終了しました');
        }
    }

    const startDate = new Date(jQuery('#js-dateAndTime').data('start-date'));
    startDate.setHours(0, 0, 0, 0); // Reset hours, minutes, seconds, and milliseconds to 0

    const endDate = new Date(jQuery('#js-dateAndTime').data('end-date')).getTime();

    // Get current date with reset hours, minutes, seconds, and milliseconds to 0
    const currentDate = new Date();
    currentDate.setHours(0, 0, 0, 0);

    // Case 1: Before start date
    if (startDate.getTime() > currentDate.getTime()) {
console.log('Case 1');
        const daysLeft = Math.floor((startDate.getTime() - currentDate.getTime()) / (1000 * 60 * 60 * 24));
        jQuery('#js-periodBefore').addClass('is-active');
        jQuery('.free-timeSale').addClass('is-periodBefore');
        jQuery('.js-count-num').text(daysLeft);
    }
    // Case 2: On start date
    else if (startDate.getTime() <= currentDate.getTime() && currentDate.getTime() < endDate) {
console.log('Case 2');
        jQuery('#js-periodJustBefore').addClass('is-active');
        jQuery('.free-timeSale').addClass('is-periodJustBefore');

        const timerInterval = setInterval(function () {
            updateCountdown(endDate);
        }, 1000);
    }
    // Case 3: During the session
    else if (endDate < currentDate.getTime() && currentDate.getTime() <= endDate) {
console.log('Case 3');
        jQuery('#js-periodInSession').addClass('is-active');
        jQuery('.free-timeSale').addClass('is-periodInSession');
    }
    // Case 4: After the session
    else {
console.log('Case 4');
        jQuery('#js-periodInSession').text('終了しました').addClass('is-active');
        jQuery('.free-timeSale').addClass('is-periodInSession');
    }

    // いち押し商品
    const $pickup = jQuery('#js-pickup');

    if ($pickup.length > 0) {
        let pickupCode = $pickup.data('pickup-code');
        getPickup(pickupCode, $pickup);

        function getPickup(pickupGoodsCode, target) {
            jQuery.ajax({
                type: 'GET',
                url: 'https://store.kadenfan.hitachi.co.jp/store/g/g' + pickupGoodsCode + '/',
                cache: false,
                timeout: 30000,
                dataType: 'html'
            })
            .done(function(results) {
                const $pickupResults = jQuery(results);
                if ($pickupResults) {
                    const resultImgSrc = $pickupResults.find('.block-src-L img').attr('data-src');
                    const pickupImg = jQuery('\<img\>').attr({
                        'src': 'https://store.kadenfan.hitachi.co.jp' + resultImgSrc,
                        'alt': ''
                    });
                    const pickupTtl = $pickupResults.find('.block-goods-name--text').text();
                    const pickupTxt = $pickupResults.find('.block-goods-comment1').html();
                    const pickupLink = '/store/g/g' + pickupGoodsCode + '/';
                    const $createPickupTax = jQuery('\<span\>').addClass('fs-sm').text('\uFF08\u7A0E\u8FBC\uFF09'); // （税込）
                    const pickupPriceHtml = $pickupResults.find('.block-goods-price--price.price.js-enhanced-ecommerce-goods-price').text();
                    const pickupPrice = pickupPriceHtml.replace(/[^,^0-9]/g,'');

                    target.find('.pickup-img').html(pickupImg);
                    target.find('.pickup-ttl').text(pickupTtl);
                    target.find('.pickup-txt').text(pickupTxt);
                    target.find('.pickup-link').attr('href', pickupLink);
                    target.find('.pickup-price').append(pickupPrice, $createPickupTax);
                }
            })
            .fail(function() {
                console.error('ajax error for Pickup Data');
            });
        }
    }

    // セール商品イベントAPI
    const $saleEventOutput = jQuery('#js-output-saleEvent');

    if ($saleEventOutput.length > 0) {
        const $createList = jQuery('\<ul\>').addClass('event-products');

        $saleEventOutput.append($createList);
        getEventProductDetail($createList, jQuery('#anc-sale'));

        function getEventProductDetail(target, priceTargetParent) {
            jQuery.ajax({
                type: 'GET',
                // url: '/api/goodslistapi.aspx?type=xml&charset=UTF-8&event=timesale',
                url: 'https://store.kadenfan.hitachi.co.jp/api/goodslistapi.aspx?type=xml&charset=UTF-8&event=OLcat2',
                cache: false,
                timeout: 30000,
                dataType: 'html'
            })
            .done(function(results) {
                const $eventProductApiResults = jQuery(results);
                if ($eventProductApiResults.find('item').length) {
                    $eventProductApiResults.find('item').each(function() {
                        const $thisResults = jQuery(this);
                        const apiTargetUrl = $thisResults.find('goods').text();
                        const $createDetailWrap = jQuery('\<div\>').addClass('event-products-area-detail');
                        const $createDetailBottom = jQuery('\<div\>').addClass('event-products-area-detail-bottom');
                        const $createImgWrap = jQuery('\<div\>').addClass('event-products-area-img');
                        // const stockMessage = $thisResults.find('stock_message').text();

                        // 画像
                        const $createImg = jQuery('\<span\>').addClass('event-products-img').append(
                            jQuery('\<img\>').attr({
                                'src': $thisResults.find('src_l').text(),
                                'alt': ''
                            })
                        );
                        const $createIcn = jQuery('\<span\>').addClass('event-products-icn').append(
                            jQuery('\<img\>').attr({
                                'src': 'https://store.kadenfan.hitachi.co.jp/img/icon/10000004.png',
                                'alt': 'OUTLET'
                            })
                        );
                        $createImgWrap.append($createImg, $createIcn);

                        // テキスト情報
                        const $createTtl = jQuery('\<p\>').addClass('event-products-ttl').text($thisResults.find('name').text());
                        const $createColor = jQuery('\<div\>').addClass('event-products-color').text('(' + $thisResults.find('variation_name2').text() + ')');
                        const $createLink = jQuery('\<a\>').addClass('event-products-link').attr('href', '/store/g/g' + apiTargetUrl + '/').text('\u5546\u54C1\u8A73\u7D30\u3092\u78BA\u8A8D');// 商品詳細を確認
                        const $createLinkWrap = jQuery('\<div\>').addClass('event-products-linkWrap').append($createLink);

                        // 価格は商品詳細から取得
                        const $createPrice = jQuery('\<div\>').addClass('event-products-price').attr('data-ajax-price', 'g' + apiTargetUrl);

                        $createDetailBottom.append($createColor, $createPrice, $createLinkWrap);
                        $createDetailWrap.append($createTtl, $createDetailBottom);

                        const $createListItem = jQuery('\<li\>').addClass('event-products-item').append($createImgWrap, $createDetailWrap);
                        target.append($createListItem);
                    });
                } else {
                    // 商品がAPIに1つもなければsectionごと削除
                    priceTargetParent.remove();
                }

                priceTargetParent.find('[data-ajax-price]').each(function() {
                    let $this = jQuery(this);
                    let targetUrl = $this.data('ajax-price');
                    getPrice($this, targetUrl);
                });
            })
            .fail(function() {
                console.error('ajax error for Event Products API');
            });
        }

        function getPrice(targetElem, url) {
            jQuery.ajax({
                type: 'GET',
                url: 'https://store.kadenfan.hitachi.co.jp/store/g/' + url + '/',
                cache: false,
                timeout: 30000,
                datatype: 'html'
            })
            .done(function(results){
                const $createTax = jQuery('\<span\>').addClass('fs-sm').text('\uFF08\u7A0E\u8FBC\uFF09'); // （税込）
                let priceHtml = jQuery(results).find('.block-goods-price--price.price.js-enhanced-ecommerce-goods-price').text();
                priceHtml = priceHtml.replace(/[^,^0-9]/g,'');
                targetElem.append(priceHtml, $createTax);
            })
            .fail(function(){
                console.log('ajax error for price', url);
                targetElem.closest('.event-products-item').hide();
            });
        }
    }
});

// jQuery(window).on('load', function() {
// });
