var ecblib = ecblib || {};
ecblib.customize = ecblib.customize || {};
ecblib.customize.user = ecblib.customize.user || {};

(function () {
    'use strict';
    // copyright
    document.getElementById('js-thisYear').textContent = new Date().getFullYear().toString();

    // カテゴリ生成
    // fetch('https://dev-2022-w01/brother-sales/shop/genre/genreapi.aspx?type=json&charset=utf8')
    fetch('https://s3.ap-northeast-1.amazonaws.com/kikakunin.ecbeing.work/hitachi/test/genreapi.json')
        .then(response => response.json())
        .then(jsonData => {
            generateHTML(jsonData);
        })
        .catch(error => console.error('Error fetching JSON:', error));

        function generateHTML(jsonData) {
            const headerCateList = document.getElementById('js-header-cate-list');
            const topCateList = document.getElementById('js-top-cate-list');

            const blockTopCateList = document.createElement('ul');
            blockTopCateList.classList.add('block-top-cate-list');

            jsonData.forEach(function (item) {
                // "tree"の値が2桁のものだけ生成
                if (/^\d{2}$/.test(item.tree) || item.tree.length === 2) {
                    const categoryItem = document.createElement('li');
                    categoryItem.classList.add('block-top-cate-list--item');

                    const categoryLink = document.createElement('a');
                    categoryLink.href = '/abc/' + item.tree + '/';
                    categoryLink.classList.add('block-top-cate-list--link', 'js-top-cate-tooltip');

                    const titleDiv = document.createElement('div');
                    titleDiv.classList.add('block-top-cate-list--ttl');
                    titleDiv.textContent = item.name;

                    const imgDiv = document.createElement('div');
                    imgDiv.classList.add('block-top-cate-list--img');
                    const img = document.createElement('img');
                    img.src = item.src2;
                    img.alt = '';
                    img.loading = 'lazy';
                    imgDiv.appendChild(img);

                    categoryLink.appendChild(titleDiv);
                    categoryLink.appendChild(imgDiv);
                    categoryItem.appendChild(categoryLink);

                    const tooltipList = document.createElement('ul');
                    tooltipList.classList.add('tooltip-contents-list');

                    jsonData.forEach(function (subItem) {
                        if (subItem.tree.length === 4 && subItem.tree.startsWith(item.tree)) {
                            const tooltipItem = document.createElement('li');
                            tooltipItem.setAttribute('data-tree', subItem.tree);
                            tooltipItem.textContent = subItem.name;
                            tooltipList.appendChild(tooltipItem);
                        }
                    });

                    if (tooltipList.children.length > 0) {
                        categoryItem.appendChild(tooltipList);
                    }

                    blockTopCateList.appendChild(categoryItem);
                }
            });

            headerCateList.appendChild(blockTopCateList.cloneNode(true));

            // TOP
            if (document.querySelector('.page-top')) {
                const repurchaseLi = document.createElement('li');
                repurchaseLi.classList.add('block-top-cate-list--item');
                const repurchaseLink = document.createElement('a');
                repurchaseLink.href = '';
                repurchaseLink.classList.add('block-top-cate-list--repurchase');
                const repurchaseMain = document.createElement('span');
                repurchaseMain.classList.add('repurchase-main');
                repurchaseMain.innerHTML = '<b>再購入</b>したい方はこちら！';
                const repurchaseSub = document.createElement('span');
                repurchaseSub.classList.add('repurchase-sub');
                repurchaseSub.textContent = 'マイページ：購入履歴';
                repurchaseLink.appendChild(repurchaseMain);
                repurchaseLink.appendChild(repurchaseSub);
                repurchaseLi.appendChild(repurchaseLink);

                blockTopCateList.appendChild(repurchaseLi);
                topCateList.appendChild(blockTopCateList);
            }
        }
}());

jQuery(function () {
    var _user = ecblib.customize.user;

    //-- トップページへ戻る初期値
    jQuery('#footer_pagetop').hide();

    //--- スムーススクロール
    jQuery('a[href="#header"], [href^="#anc-"]').click(function () {
        var speed = 500;
        var headerH = 0;
        // if (jQuery('#header').height() > 200) {
        //     headerH = (jQuery('#header').height() + jQuery('#header_pickup_banner').height()) + 30;
        // } else {
        //     headerH = jQuery('#header').height();
        // };
        var href = jQuery(this).attr("href");
        var target = jQuery(href == "#" || href == "" ? 'html' : href);
        var position = target.offset().top - headerH;
        jQuery('body,html').animate({ scrollTop: position }, speed, 'swing');
        return false;
    });

    //--- 表示方法・並び替えwrap
    if(jQuery(".block-goods-list--display-style-items").length || jQuery(".block-goods-list--sort-order-items").length) {
        if(jQuery(".block-goods-list--display-style-items").length) {
            jQuery(".block-goods-list--display-style-items").before("<div class='block-goods-list--items-wrap'></div>");
        } else {
            jQuery(".block-goods-list--sort-order-items").before("<div class='block-goods-list--items-wrap'></div>");
        }

        if(jQuery(".block-goods-list--display-style-items").length) {
            //表示方法
            jQuery(".block-goods-list--items-wrap").append(jQuery(".block-goods-list--display-style-items"));
        }
        if(jQuery(".block-goods-list--sort-order-items").length) {
            //並び替え
            jQuery(".block-goods-list--items-wrap").append(jQuery(".block-goods-list--sort-order-items"));
        }
    }

    //--- カテゴリツリー アコーディオン化
    jQuery(".pane-left-menu ul.block-category-tree--items > li > ul").each(function() {
        jQuery(this).closest("li").children("a").after("<div class='block-category-tree--item-opener'></div>");
    });
    jQuery(document).on("click", ".block-category-tree--item-opener", function() {
        jQuery(this).toggleClass("is-open");
        jQuery(this).closest("li").children("ul.block-category-tree--items").slideToggle();
    });
    jQuery(".pane-left-menu ul.block-category-tree--items li.block-category-tree--item__open").each(function() {
        jQuery(this).children(".block-category-tree--item-opener").addClass("is-open");
        jQuery(this).children(".block-category-tree--item-opener").next().show();
        jQuery(this).parents(".block-category-tree--items").each(function() {
            jQuery(this).closest("li").children("ul.block-category-tree--items").show();
            jQuery(this).prev(".block-category-tree--item-opener").addClass("is-open");
        })
    });

    //--- ジャンルツリー アコーディオン化
    jQuery(".pane-left-menu ul.ls-block-genre-tree--items > li > ul").each(function() {
        jQuery(this).closest("li").children("a").after("<div class='ls-block-genre-tree--item-opener'></div>");
    });
    jQuery(document).on("click", ".ls-block-genre-tree--item-opener", function() {
        jQuery(this).toggleClass("is-open");
        jQuery(this).closest("li").children("ul.ls-block-genre-tree--items").slideToggle();
    });

    jQuery(document).on("click", ".item-name", function() {
        jQuery(this).toggleClass("is-open");
        jQuery(this).parent().prev().toggleClass("is-open");
        jQuery(this).parent().prev().parent("div").children("[class^='ls-block-filter-tree-items']").slideToggle();
    });

    jQuery(document).on("click", ".block-filter-tree-opener", function() {
        jQuery(this).toggleClass("is-open");
        jQuery(this).parent("div").children("[class^='ls-block-filter-tree-items']").slideToggle();
    });
});
jQuery(window).on('scroll resize', function () {
    var _user = ecblib.customize.user;

    var scrollHeight = jQuery(document).height();
    var scrollPosition = jQuery(window).height() + jQuery(window).scrollTop();
    var footHeight = jQuery('footer').height();

    if (jQuery(this).scrollTop() > 120) {
        jQuery('#footer_pagetop').show();
    } else if (jQuery(this).scrollTop() < 80) {
        jQuery('#footer_pagetop').hide();
    }

    if (scrollHeight - scrollPosition <= footHeight) {
        jQuery('#footer_pagetop').css({ 'opacity': '0.2' });
    } else {
        jQuery('#footer_pagetop').css({ 'opacity': '1' });
    }

});


jQuery(document).ready(function() {
    // ヘッダーメニュー
    const $headerMenuCate = jQuery('#js-header-menu-cate');
    const $headerCateMenu = jQuery('#js-header-cate-menu');
    const $topCateList = $headerMenuCate.find('.block-top-cate-list');
    let isAnimating = false;

    function toggleHeaderNav(event) {
        event.stopPropagation();

        if (!isAnimating) {
            isAnimating = true;

            $headerCateMenu.slideToggle(300, function () {
                isAnimating = false;
            });

            $headerMenuCate.toggleClass('is-open');
        }
    }

    $headerMenuCate.on({
        'mouseenter': toggleHeaderNav,
        'mouseleave': toggleHeaderNav
    });

    $topCateList.on({
        'mouseenter': function (event) {
            event.stopPropagation();
        },
        'mouseleave': function (event) {
            event.stopPropagation();
        }
    });

    // カテゴリツールチップ（トップ、ヘッダー）
    const $cateTooltip = jQuery('.js-top-cate-tooltip');
    if ($cateTooltip.length) {
        $cateTooltip.each(function () {
            const $thisTooltip = jQuery(this);
            let tooltip = $thisTooltip.next('.tooltip-contents-list');
            let position = $thisTooltip.data('tooltip-position');
            let className;
            if (!position) {
                position = 'bottom';
            }

            if ($thisTooltip.closest('#js-header-cate-menu').length) {
                className = 'block-top-cate-balloontip nav-inner';
            } else {
                className = 'block-top-cate-balloontip';
            }

            $thisTooltip.on({
                'mouseenter': function () {
                    $thisTooltip.hideBalloon()
                        .showBalloon({
                            classname: className,
                            contents: tooltip,
                            position: position,
                            offsetY: '12',
                            html: true,
                            css: {
                                color: "#fff",
                                backgroundColor: "#555"
                            }
                        });
                },
                'mouseleave': function () {
                    $thisTooltip.hideBalloon();
                }
            });
        });
    }
});

window.lazySizesConfig = window.lazySizesConfig || {};
/* lazysizesの設定の変更はここから記述してください
  ・window.lazySizesConfig.expandは、大きな画像を早めに読み込み開始させたい場合などに使用してください
    正の値を指定すると読み込み開始スクロール位置が上に（早く）なります
    負の値を設定すると読み込み開始スクロール位置が下に（遅く）なります
    ※lazySizesConfig.expandを指定しない場合、画像の読み込み状況やブラウザのアイドリング状況に応じて動的に最適化されますが
      指定すると動的な最適化が無効になることに注意してください
*/
