'use strict';

// Fix監視
window.addEventListener('DOMContentLoaded', function() {
    const fixedElem = document.getElementById('js-fixChecked');
    const targetObservation = document.getElementById('js-orderArea');
    const observationOptions = {
        root : null,
        rootMargin : '-50% 0px',
        threshold: 0
    };
    const mainObserver = new IntersectionObserver(observationCheck, observationOptions);
    const fixedClass = 'is-fixed';

    function observationCheck(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                fixedElem.classList.add(fixedClass);
            } else {
                fixedElem.classList.remove(fixedClass);
            }
        });
    };
    mainObserver.observe(targetObservation);
});

// Slider
jQuery(function () {
    jQuery('[data-browse-mode="P"] #js-slideSecret').slick({
        slidesToShow: 2,
        slidesToScroll: 1,
        infinite: true,
        centerMode: true,
        variableWidth: true
    });
});

// Modal
jQuery(function () {
    let $modalItem = jQuery('[id^=js-modalItem]');

    if ($modalItem.length <= 0) {
        return;
    }

    const $doc = jQuery(document);
    const $body = jQuery('body');
    const modalOpenClass = 'is-modalOpen';
    const hiddenClass = 'is-hidden';
    let $btnTrigger = jQuery('[data-modal^=js-modalItem]');
    let $dataModal;
    let $dataModalName;
    let $targetModalItem;
    let $targetModalItemInner;
    let $modalOverlay;
    let $modalId;
    let winHeight;
    let targetHeight;
    let clientWidth;
    let noScrollbarWidth;
    let difference;


    $modalItem.each(function () {
        jQuery(this).attr({
            'role': 'dialog',
            'aria-modal': 'true'
        });
    });

    $modalOverlay = jQuery('\<div\>').attr({
        'id': 'js-modalOverlay',
        'class': 'dc23-modalOverlay'
    });

    $btnTrigger.on('click', function () {
        $dataModal = jQuery(this).data('modal');
        $dataModalName = '#' + $dataModal;
        $targetModalItem = jQuery($dataModalName);
        $targetModalItemInner = $targetModalItem.find('.dc23-modal-inner');
        clientWidth = $body[0].clientWidth;

        $targetModalItemInner.attr('tabindex', 0);
        $targetModalItem.removeClass(hiddenClass).wrap($modalOverlay);
        $body.addClass(modalOpenClass);

        // 中身が多い時スクロールできるように
        winHeight = jQuery(window).height();
        targetHeight = $targetModalItem.outerHeight();
        if(targetHeight > winHeight*.8) {
            $targetModalItem.addClass('is-contentsOver');
        }

        // スクロールバーのズレ対策
        if (jQuery('[data-browse-mode="P"]').length) {
            noScrollbarWidth = $body[0].clientWidth;
            difference = noScrollbarWidth - clientWidth;
            if (difference > 0) {
                $body.css('padding-right', difference + 'px');
            }
        }

        return false;
    });

    // close
    $doc.on('click', '#js-modalOverlay, .js-btn-modalClose', function() {
        closeModal();
    });

    $doc.on('click', '#js-modalContentsArea, [id^=js-modal]', function(e) {
        e.stopPropagation();
    });

    function closeModal() {
        $modalOverlay = jQuery('#js-modalOverlay');
        $targetModalItem = $modalOverlay.find($modalItem);
        $targetModalItemInner = $targetModalItem.find('.dc23-modal-inner');
        $modalId = $targetModalItem.attr('id');

        $targetModalItemInner.attr('tabindex', -1);
        $targetModalItem.addClass(hiddenClass).unwrap($modalOverlay);
        $body.removeClass(modalOpenClass);

        $btnTrigger.each(function () {
            $dataModal = jQuery(this).data('modal');
            if($dataModal === $modalId) {
                jQuery(this).focus();
            }
        });

        // スクロールバーのズレ対策
        if (jQuery('[data-browse-mode="P"]').length) {
            $body.css('padding-right', '');
        }
    }
});

// Color Order
jQuery(function () {
    const $btnComplete = jQuery('.js-btnComplete');
    const $compImg = jQuery('#js-compImg');
    const $step1Radio = jQuery('[name="radio-heel"]');
    const $step2Radio = jQuery('[name="radio-width"]');
    const $step3Radio = jQuery('[name="radio-color"]');
    let step1Val;
    let step2Val;
    let step3Val;

    $btnComplete.prop('disabled', true);
    jQuery('[type="radio"]').prop('checked', false);
    $compImg.removeClass('is-comp');

    // jQuery(window).on('load', function () {
    //     jQuery('[type="radio"]').prop('checked', false);
    // });

    // STEP1
    // 追従にヒール高を反映
    // 追従にヒール高画像を反映
    $step1Radio.on('change', function () {
        step1Val = jQuery(this).val();
        jQuery('#js-checkHeel').text(jQuery(this).next().find('.stepOrder-step1List-ttl img').attr('alt'));
        jQuery('#js-checkHeelImg').attr('src', './img/usr/freepage/deerskin_colororder_2023/imgFixHeel_' + step1Val + '.jpg');
        check();
    });

    // STEP2
    // 追従に幅を反映
    // 追従に幅画像を反映
    // 完成画像に関係ない※URLに関係するか確認
    $step2Radio.on('change', function () {
        step2Val = jQuery(this).val();
        jQuery('#js-checkWidth').text(jQuery(this).next().find('.stepOrder-step2List-ttl img').attr('alt'));
        jQuery('#js-checkWidthImg').attr('src', './img/usr/freepage/deerskin_colororder_2023/imgFixWidth_' + step2Val + '.jpg');
        check();
    });

    // STEP3
    // 追従にカラーを反映
    // 追従にカラー画像を反映
    $step3Radio.on('change', function () {
        step3Val = jQuery(this).val();
        jQuery('#js-checkColor').text(jQuery(this).next().find('.stepOrder-step3List-ttl').text());
        jQuery('#js-checkColorImg').attr('src', jQuery(this).next().find('.stepOrder-step3List-img img').attr('src'));
        check();
    });

    function check() {
        if((step1Val !== undefined) && (step2Val !== undefined) && (step3Val !== undefined)) {
            $btnComplete.prop('disabled', false);
        }
    }

    // 完成イメージを見る
    jQuery('.js-btnComplete').on('click', function () {
        let userSelectImg = step1Val + step3Val;

        $compImg.find('img').attr('src', './img/usr/freepage/deerskin_colororder_2023/products/' + userSelectImg + '.jpg');
        $compImg.addClass('is-comp');
    });

});
